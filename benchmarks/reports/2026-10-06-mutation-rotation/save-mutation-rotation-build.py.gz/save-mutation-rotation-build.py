"""Freeze the successfully built permanent rotation probe and its provenance."""
import json
import pathlib
import shutil
import subprocess
import sys

root = pathlib.Path('/tmp/mnos-ingest/casita')
evidence = pathlib.Path('/tmp/mnos-ingest/evidence')
sys.path.insert(0, str(root))
from benchmarks import build_manifest

messages = [json.loads(line) for line in (evidence / 'mutation-rotation-release-build.jsonl').read_text().splitlines() if line.startswith('{')]
assert any(item.get('reason') == 'build-finished' and item['success'] for item in messages)
binary = next(item['executable'] for item in reversed(messages)
              if item.get('executable') and item.get('target', {}).get('name') == 'casita'
              and item.get('profile', {}).get('test'))
output = evidence / 'mutation-rotation-probe'
assert not output.exists()
shutil.copy2(binary, output)
command = ['cargo', 'test', '--release', '-p', 'casita', '--no-default-features',
           '--features', 'native,git,experimental', '--lib', '--no-run', '--message-format=json']
build_manifest.write(root, output, command)
build_manifest.artifacts([('probe', output)])
for name in ['mutation.rs', 'mutation_rotation_tests.rs']:
    shutil.copy2(root / 'crates/casita/src/repository' / name, evidence / ('mutation-rotation-' + name))
(evidence / 'mutation-rotation-candidate.patch').write_bytes(subprocess.check_output(['git', 'diff', 'HEAD'], cwd=root))
shutil.copy2(root / 'benchmarks/suites/mutation_rotation.py', evidence / 'mutation-rotation-runner.py')
print(output)
