"""Audit every completed rotation process and report all workload medians."""
import hashlib
import json
import pathlib
import statistics
import sys

root = pathlib.Path('/tmp/mnos-ingest')
sys.path.insert(0, str(root / 'casita'))
from benchmarks.suites.mutation_rotation import parse_sample

path = root / 'evidence/mutation-rotation-comparison.json'
result = json.loads(path.read_text())
assert result['complete']
counts = result['configuration']['counts']
repetitions = result['configuration']['repetitions']
assert len(result['samples']) == len(result['processes']) == len(counts) * repetitions * 6
expected = {(count, mode, eligible, rep) for count in counts
            for mode in ('long', 'sessions', 'rotate') for eligible in (False, True)
            for rep in range(1, repetitions + 1)}
seen = set()
for process, sample in zip(result['processes'], result['samples']):
    key = (process['count'], process['mode'], process['eligible'], process['repetition'])
    assert key not in seen and process['exit_code'] == 0
    seen.add(key)
    parsed = parse_sample(process['stdout'], *key[:3])
    assert sample['wall_seconds'] == parsed['nanos'] / 1e9
    assert (sample['entries'], sample['mode'], sample['eligible'], sample['repetition']) == key
    assert sample['variant'] == f"{key[1]}/{'eligible' if key[2] else 'ineligible'}"
assert seen == expected
for artifact in result['artifacts']:
    with pathlib.Path(artifact['path']).open('rb') as source:
        assert hashlib.file_digest(source, 'sha256').hexdigest() == artifact['sha256']
rows = []
for count in counts:
    for eligible in (False, True):
        medians = {mode: statistics.median(s['wall_seconds'] for s in result['samples']
                   if s['entries'] == count and s['eligible'] == eligible and s['mode'] == mode)
                   for mode in ('long', 'sessions', 'rotate')}
        rows.append(dict(publications=count, eligible=eligible, medians_seconds=medians,
                         rotation_vs_long_percent=(medians['rotate'] / medians['long'] - 1) * 100,
                         rotation_vs_sessions_percent=(medians['rotate'] / medians['sessions'] - 1) * 100))
audit = dict(complete=True, processes_checked=len(seen),
             result_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), rows=rows,
             scope='Controlled memory-backed publication and maintenance eligibility. Counts, not bytes/RSS; no end-to-end ingestion claim.')
out = path.with_name('mutation-rotation-comparison-audit.json')
assert not out.exists()
out.write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit, indent=2))
