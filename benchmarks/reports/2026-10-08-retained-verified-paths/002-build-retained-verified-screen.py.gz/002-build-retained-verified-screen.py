"""Build permanent existing-path diagnostic; no runtime behavior change."""
import gzip, hashlib, json, os, signal, subprocess, sys, time, traceback
from pathlib import Path
R=Path('/tmp/mnos-ingest'); C=R/'casita'; E=R/'evidence'; M=R/'mnos-nix-xp'
sys.path.insert(0,str(C)); from benchmarks import build_manifest as bm
sys.path.insert(0,str(M/'docs/reports/probes/git-ingestion')); from pool_process import OwnedFamily
OUT=E/'retained-verified-screen-build'; OUT.mkdir(exist_ok=False)
old=R/'portable-target/release/deps/casita-5cbf508ed0047226'
preserved=E/'single-group-retained-unit.gz'
with gzip.open(preserved,'rb') as f: assert hashlib.file_digest(f,'sha256').hexdigest()==bm.digest(old)
env=dict(os.environ); env.update(CARGO_TARGET_DIR=str(R/'portable-target'),CARGO_PROFILE_RELEASE_DEBUG='1',CARGO_PROFILE_RELEASE_LTO='off',RUSTFLAGS='-C link-arg=-fuse-ld=mold')
command=['cargo','test','--locked','--offline','--release','-j2','-p','casita','--no-default-features','--features','native,git,experimental,cli','--lib','--no-run','--message-format=json']
source=bm.source_identity(C,env)
inputs={str(p):bm.digest(p) for p in [Path(__file__),preserved,M/'docs/reports/probes/git-ingestion/pool_process.py']}
(OUT/'tracked.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=C))
test=C/'crates/casita/src/repository/retained_verified_bench.rs'; (OUT/test.name).write_bytes(test.read_bytes())
def free():
 s=os.statvfs(E); return s.f_bavail*s.f_frsize
assert free()>=1024**3
protocol=dict(command=command,source=source,input_sha256=inputs,environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_LTO','RUSTFLAGS']},scope=__doc__,started_unix=time.time(),timeout_seconds=3600,rss_limit_bytes=8*1024**3,during_free_bytes=512*1024**2)
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
family=OwnedFamily(); child=None; ended=None; usage=None; errors=[]; stop=None; interrupted=False; forced=False; unexpected=[]; remaining=[]; samples=[]
def interrupt(sig,frame):
 global interrupted
 interrupted=True
signal.signal(signal.SIGINT,interrupt); signal.signal(signal.SIGTERM,interrupt)
def reap():
 global ended,usage
 if child is not None and child.returncode is None:
  pid,status,u=os.wait4(child.pid,os.WNOHANG)
  if pid:
   child.returncode=os.waitstatus_to_exitcode(status);ended=time.monotonic();usage=dict(user_seconds=u.ru_utime,system_seconds=u.ru_stime,peak_rss_bytes=u.ru_maxrss*1024)
start=time.monotonic(); next_sample=start
try:
 with (OUT/'cargo.jsonl').open('x') as out,(OUT/'stderr.log').open('x') as err:
  child=subprocess.Popen(command,cwd=C,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
  while True:
   reap()
   if child.returncode is not None:unexpected=family.scan();break
   now=time.monotonic()
   if now>=next_sample:
    rss=0
    for pid in family.scan():
     try:
      fields=dict(line.split(':',1) for line in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in line);rss+=int(fields.get('VmRSS','0 kB').split()[0])*1024
     except (FileNotFoundError,ProcessLookupError):pass
    disk=free();samples.append(dict(seconds=now-start,rss_bytes=rss,free_bytes=disk));next_sample=now+1
    if now-start>=3600:stop='wall watchdog'
    elif rss>8*1024**3:stop='RSS watchdog'
    elif disk<512*1024**2:stop='disk watchdog'
   if interrupted:stop='interrupted'
   if stop:raise RuntimeError(stop)
   time.sleep(.05)
except BaseException:errors.append(traceback.format_exc())
finally:
 if child is not None:
  try:forced=family.finish(reap,lambda:child.returncode is not None);remaining=family.members()
  except BaseException:errors.append(traceback.format_exc());remaining=family.members()
record=dict(success=False,exit_code=child.returncode if child else None,errors=errors,stop=stop,interrupted=interrupted,forced_cleanup=forced,unexpected=unexpected,remaining=remaining,adopted=family.reaped,usage=usage,samples=samples,completed_unix=time.time())
try:
 assert child is not None and child.returncode==0 and not any([errors,stop,interrupted,forced,unexpected,remaining,family.reaped])
 assert bm.source_identity(C,env)==source
 for p,h in inputs.items():assert bm.digest(p)==h
 messages=[json.loads(l) for l in (OUT/'cargo.jsonl').read_text().splitlines() if l.startswith('{')]
 artifacts=[m for m in messages if m.get('executable') and m['target']['name']=='casita' and m['target']['kind']==['lib'] and m['profile']['test']]
 assert len(artifacts)==1
 binary=Path(artifacts[0]['executable']); build=bm.write(C,binary,command,environment=env)
 build.update(cargo_artifact=artifacts[0],purpose=__doc__);bm.manifest_path(binary).write_text(json.dumps(build,indent=2)+'\n')
 record.update(success=True,executable=str(binary),executable_sha256=bm.digest(binary),build_manifest=str(bm.manifest_path(binary)),build_manifest_sha256=bm.digest(bm.manifest_path(binary)))
except BaseException:record['validation_error']=traceback.format_exc()
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='samples'}),flush=True)
raise SystemExit(0 if record['success'] else 1)
