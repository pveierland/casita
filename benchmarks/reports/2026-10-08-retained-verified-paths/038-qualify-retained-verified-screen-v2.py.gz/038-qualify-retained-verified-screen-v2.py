"""Requalify the cached Rust probe after benchmark-runner review fixes."""
import json, os, subprocess, sys, time
from pathlib import Path
R=Path('/tmp/mnos-ingest'); C=R/'casita'; E=R/'evidence'
sys.path.insert(0,str(C)); from benchmarks import build_manifest as bm
prior=E/'retained-verified-screen-build'; result=json.loads((E/'retained-verified-screen-compiler-check.json').read_text()); assert result['compiler_success'] and result['source_unchanged'] and not result['guard_success']
for p,h in result['input_sha256'].items():assert bm.digest(p)==h
protocol=json.loads((prior/'protocol.json').read_text()); binary=Path(result['executable'])
assert bm.digest(binary)==result['executable_sha256']
assert (prior/'retained_verified_bench.rs').read_bytes()==(C/'crates/casita/src/repository/retained_verified_bench.rs').read_bytes()
env=dict(os.environ);env.update(protocol['environment']); source=bm.source_identity(C,env)
command=protocol['command']; started=time.time()
sys.path.insert(0,str(R/'mnos-nix-xp/docs/reports/probes/git-ingestion'));from pool_process import OwnedFamily
family=OwnedFamily()
with (E/'retained-verified-screen-requalification.jsonl').open('x') as out,(E/'retained-verified-screen-requalification.log').open('x') as err:
 completed=subprocess.run(command,cwd=C,env=env,stdout=out,stderr=err,timeout=120)
unexpected=family.scan();forced=family.finish(lambda:None,lambda:True);remaining=family.members()
assert completed.returncode==0 and not any([unexpected,forced,remaining,family.reaped]) and bm.source_identity(C,env)==source
assert bm.digest(binary)==result['executable_sha256'],'Rust artifact changed during runner-only requalification'
messages=[json.loads(line) for line in (E/'retained-verified-screen-requalification.jsonl').read_text().splitlines() if line.startswith('{')]
artifacts=[m for m in messages if m.get('executable')==str(binary)];assert len(artifacts)==1 and artifacts[0]['fresh']
destination=E/'retained-verified-screen-bin';destination.mkdir(exist_ok=False)
saved=destination/'casita-lib-test';os.link(binary,saved)
build=bm.write(C,saved,command,environment=env);build.update(cargo_artifact=artifacts[0],purpose=__doc__)
bm.manifest_path(saved).write_text(json.dumps(build,indent=2)+'\n')
inputs={str(p):bm.digest(p) for p in [Path(__file__),prior/'result.json',prior/'protocol.json',E/'retained-verified-screen-compiler-check.json',prior/'retained_verified_bench.rs',E/'retained-verified-screen-requalification.jsonl',E/'retained-verified-screen-requalification.log',saved,bm.manifest_path(saved),C/'benchmarks/all.py',C/'benchmarks/manifest.json',C/'benchmarks/tests/test_all.py',C/'crates/casita/src/repository/retention.rs',C/'crates/casita/src/repository/retained_verified_bench.rs']}
record=dict(success=True,unexpected=unexpected,forced_cleanup=forced,remaining=remaining,adopted=family.reaped,source=source,executable=str(saved),executable_sha256=bm.digest(saved),input_sha256=inputs,started_unix=started,completed_unix=time.time(),scope=__doc__)
with (E/'retained-verified-screen-qualification.json').open('x') as f:f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
