"""Summarize one warmed existing-path screen without a production-speed claim."""
import hashlib,json,statistics
from pathlib import Path
E=Path('/tmp/mnos-ingest/evidence'); source=E/'retained-verified-screen-run/retained-verified-paths.json'
guard=E/'retained-verified-screen-guard/result.json';assert json.loads(guard.read_text())['success']
samples=json.loads(source.read_text())['samples']
expected=[(size,width,i,path) for size in [0,4096,16383,16384,16385,524289] for width in [1,64] for i,path in enumerate(['unscoped','scoped','scoped','unscoped','unscoped','scoped'])]
assert [(r['size'],r['concurrency'],r['sample'],r['path']) for r in samples]==expected
observations=[]
for size in [0,4096,16383,16384,16385,524289]:
 for width in [1,64]:
  rows=[r for r in samples if r['size']==size and r['concurrency']==width]
  a=[r['elapsed_ns'] for r in rows if r['path']=='unscoped']; b=[r['elapsed_ns'] for r in rows if r['path']=='scoped']
  meda=statistics.median(a);medb=statistics.median(b)
  observations.append(dict(size=size,concurrency=width,unscoped_ns=a,scoped_ns=b,unscoped_median_ns=meda,scoped_median_ns=medb,median_change_percent=100*(medb/meda-1),paired_change_percent=[100*(rows[j]['elapsed_ns']/rows[i]['elapsed_ns']-1) for i,j in [(0,1),(3,2),(4,5)]]))
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
result=dict(scope=__doc__,input_sha256={str(p):digest(p) for p in [source,guard,Path(__file__)]},observations=observations,limitations=['One process; three observations per path and shape; no confidence intervals or native ingestion confirmation.','Warmed protected catalog and per-pin resources; not cold admission.','Same existing authentication decoder; different opening, buffering, plan and proof paths.','No path-specific allocation or peak-memory measurement.'])
with (E/'retained-verified-screen-analysis.json').open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
