"""Reject changed order, membership, timing and fixture descriptions in benchmark output."""
import copy,hashlib,json,sys,tempfile
from pathlib import Path
C=Path('/tmp/mnos-ingest/casita');E=Path('/tmp/mnos-ingest/evidence');sys.path.insert(0,str(C))
from benchmarks import all as runner
rows=[]
for size in [0,4096,16383,16384,16385,524289]:
 for width in [1,64]:
  for sample,mode in enumerate(['unscoped','scoped','scoped','unscoped','unscoped','scoped']):
   rows.append(dict(size=size,concurrency=width,sample=sample,path=mode,reads=64,distinct_payloads=1 if size==0 else 64,layout='bare' if 0<size<=16385 else 'flat-manifest',chunk_counts=[0] if size==0 else [1] if size<=16385 else [2,3],elapsed_ns=100,correctness='passed'))
def check(value):
 with tempfile.TemporaryDirectory() as d:
  p=Path(d)/'output.log';p.write_text('test probe ... '+''.join('retained_verified_sample '+json.dumps(r)+'\n' for r in value))
  return runner.retained_verified_samples(p)
assert check(rows)==rows
cases={}
changed=copy.deepcopy(rows);changed[0],changed[1]=changed[1],changed[0];cases['reordered']=changed
cases['missing']=rows[:-1];cases['duplicate']=rows+[rows[0]]
for name,index,key,value in [('wrong-layout',12,'layout','flat-manifest'),('empty-aliasing',0,'distinct_payloads',64),('invalid-chunks',60,'chunk_counts',[1]),('duplicate-chunks',60,'chunk_counts',[2,2]),('unordered-chunks',60,'chunk_counts',[3,2]),('negative-chunks',0,'chunk_counts',[-1]),('no-chunks',0,'chunk_counts',[]),('zero-duration',0,'elapsed_ns',0),('boolean-duration',0,'elapsed_ns',True),('unchecked',0,'correctness','failed'),('short-read-set',0,'reads',63)]:
 changed=copy.deepcopy(rows);changed[index][key]=value;cases[name]=changed
for name,value in cases.items():
 try:check(value)
 except runner.common.BenchmarkError:pass
 else:raise AssertionError(name+' was accepted')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result=dict(success=True,valid_samples=72,rejected=list(cases),input_sha256={str(p):sha(p) for p in [Path(__file__),C/'benchmarks/all.py']})
with (E/'retained-verified-parser-checks.json').open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
