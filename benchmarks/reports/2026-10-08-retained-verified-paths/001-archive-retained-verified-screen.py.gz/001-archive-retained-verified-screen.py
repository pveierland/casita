"""Retain the bounded screen, its runner corrections and failed-build history."""
import gzip,hashlib,json
from pathlib import Path
R=Path('/tmp/mnos-ingest');E=R/'evidence';C=R/'casita'
OUT=C/'benchmarks/reports/2026-10-08-retained-verified-paths';OUT.mkdir(parents=True,exist_ok=False)
paths=[]
for directory in ['retained-verified-screen-build','retained-verified-screen-run','retained-verified-screen-guard','retained-verified-screen-bin']:
 paths.extend(p for p in (E/directory).rglob('*') if p.is_file())
paths.extend(E/name for name in ['retained-verified-screen-compiler-check.json','retained-verified-screen-requalification.jsonl','retained-verified-screen-requalification.log','retained-verified-screen-qualification.json','retained-verified-parser-checks.json','retained-verified-screen-analysis.json','retained-verified-python-baseline-checks.log','retained-verified-python-fixed-checks.log'])
paths.extend(R/name for name in ['build-retained-verified-screen.py','qualify-retained-verified-screen.py','qualify-retained-verified-screen-v2.py','run-retained-verified-screen.py','check-retained-verified-parser.py','analyze-retained-verified-screen.py','archive-retained-verified-screen.py','review101-scope-review.txt'])
paths.extend(C/name for name in ['benchmarks/all.py','benchmarks/manifest.json','benchmarks/tests/test_all.py','benchmarks/README.md','benchmarks/build_manifest.py','benchmarks/storage.py','crates/casita/src/repository/retention.rs','crates/casita/src/repository/retained_verified_bench.rs'])
paths.append(R/'mnos-nix-xp/docs/reports/probes/git-ingestion/pool_process.py')
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
# Follow recorded file identities, preserving large binaries as external inputs.
known=set(paths)
for p in list(paths):
 if p.suffix!='.json':continue
 try:value=json.loads(p.read_text())
 except (ValueError,UnicodeError):continue
 for field in ['input_sha256','artifact_sha256']:
  for name,expected in value.get(field,{}).items():
   candidate=Path(name)
   if not candidate.is_absolute():continue
   assert candidate.is_file() and digest(candidate)==expected,(name,expected)
   known.add(candidate)
records=[];external=[]
for p in sorted(known):
 identity=dict(original_path=str(p),sha256=digest(p),bytes=p.stat().st_size)
 if p.stat().st_size>2*1024**2:
  external.append(identity);continue
 name=f'{len(records):03d}-{p.name}.gz';data=p.read_bytes();packed=gzip.compress(data,compresslevel=9,mtime=0)
 (OUT/name).write_bytes(packed)
 records.append({**identity,'file':name,'compressed_sha256':hashlib.sha256(packed).hexdigest()})
(OUT/'artifacts.json').write_text(json.dumps(records,indent=2)+'\n')
(OUT/'external-inputs.json').write_text(json.dumps(external,indent=2)+'\n')
(OUT/'analysis.json').write_bytes((E/'retained-verified-screen-analysis.json').read_bytes())
print(json.dumps(dict(artifacts=len(records),external=len(external),raw_bytes=sum(r['bytes'] for r in records),compressed_bytes=sum((OUT/r['file']).stat().st_size for r in records))))
