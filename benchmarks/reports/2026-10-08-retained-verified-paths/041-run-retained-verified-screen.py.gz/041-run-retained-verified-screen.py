"""Guard one registered existing-path benchmark run; not native ingestion timing."""
import json, os, signal, subprocess, sys, time, traceback
from pathlib import Path
R=Path('/tmp/mnos-ingest'); C=R/'casita'; E=R/'evidence'; M=R/'mnos-nix-xp'
sys.path.insert(0,str(C)); from benchmarks import build_manifest as bm
sys.path.insert(0,str(M/'docs/reports/probes/git-ingestion')); from pool_process import OwnedFamily
qualification=E/'retained-verified-screen-qualification.json'; q=json.loads(qualification.read_text()); assert q['success']
checks=E/'retained-verified-parser-checks.json'; checked=json.loads(checks.read_text());assert checked['success'] and len(checked['rejected'])==14
for p,h in checked['input_sha256'].items():assert bm.digest(p)==h
for p,h in q['input_sha256'].items():assert bm.digest(p)==h
binary=Path(q['executable']); assert bm.digest(binary)==q['executable_sha256']
assert list(bm.source_identity(C,dict(os.environ)))==q['source']
OUT=E/'retained-verified-screen-guard'; OUT.mkdir(exist_ok=False)
command=[sys.executable,'-m','benchmarks.all','--suites','retained-verified-paths','--bin-dir',str(binary.parent),'--output',str(E/'retained-verified-screen-run'),'--repetitions','1','--timeout','300']
inputs={**q['input_sha256'],str(qualification):bm.digest(qualification),str(Path(__file__)):bm.digest(__file__),str(M/'docs/reports/probes/git-ingestion/pool_process.py'):bm.digest(M/'docs/reports/probes/git-ingestion/pool_process.py')}
inputs.update({**checked['input_sha256'],str(checks):bm.digest(checks)})
env=dict(os.environ)
def free():
 s=os.statvfs(E);return s.f_bavail*s.f_frsize
assert free()>=512*1024**2
protocol=dict(command=command,scope=__doc__,source=q['source'],input_sha256=inputs,started_unix=time.time(),timeout_seconds=360,rss_limit_bytes=2*1024**3,during_free_bytes=256*1024**2,affinity=sorted(os.sched_getaffinity(0)),load_start=os.getloadavg())
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
family=OwnedFamily();child=None;ended=None;usage=None;errors=[];stop=None;interrupted=False;forced=False;unexpected=[];remaining=[];samples=[]
def interrupt(sig,frame):
 global interrupted
 interrupted=True
signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
def reap():
 global ended,usage
 if child is not None and child.returncode is None:
  pid,status,u=os.wait4(child.pid,os.WNOHANG)
  if pid:
   child.returncode=os.waitstatus_to_exitcode(status);ended=time.monotonic();usage=dict(user_seconds=u.ru_utime,system_seconds=u.ru_stime,peak_rss_bytes=u.ru_maxrss*1024,voluntary_context_switches=u.ru_nvcsw,involuntary_context_switches=u.ru_nivcsw)
start=time.monotonic();next_sample=start
try:
 with (OUT/'stdout.log').open('x') as out,(OUT/'stderr.log').open('x') as err:
  child=subprocess.Popen(command,cwd=C,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
  while True:
   reap()
   if child.returncode is not None:unexpected=family.scan();break
   now=time.monotonic()
   if now>=next_sample:
    rss=0
    for pid in family.scan():
     try:
      fields=dict(line.split(':',1) for line in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in line);rss+=int(fields.get('VmRSS','0 kB').split()[0])*1024
     except (FileNotFoundError,ProcessLookupError):pass
    disk=free();samples.append(dict(seconds=now-start,rss_bytes=rss,free_bytes=disk));next_sample=now+.25
    if now-start>=360:stop='wall watchdog'
    elif rss>2*1024**3:stop='RSS watchdog'
    elif disk<256*1024**2:stop='disk watchdog'
   if interrupted:stop='interrupted'
   if stop:raise RuntimeError(stop)
   time.sleep(.01)
except BaseException:errors.append(traceback.format_exc())
finally:
 if child is not None:
  try:forced=family.finish(reap,lambda:child.returncode is not None);remaining=family.members()
  except BaseException:errors.append(traceback.format_exc());remaining=family.members()
record=dict(success=False,exit_code=child.returncode if child else None,errors=errors,stop=stop,interrupted=interrupted,forced_cleanup=forced,unexpected=unexpected,remaining=remaining,adopted=family.reaped,usage=usage,usage_scope='Whole benchmark process family including fixture setup and all-suite bookkeeping; not per-path ownership or steady-state peak memory.',samples=samples,completed_unix=time.time())
try:
 assert child is not None and child.returncode==0 and not any([errors,stop,interrupted,forced,unexpected,remaining,family.reaped])
 assert list(bm.source_identity(C,env))==q['source']
 for p,h in inputs.items():assert bm.digest(p)==h
 execution=json.loads((E/'retained-verified-screen-run/execution.json').read_text());assert execution['complete'] and execution['artifacts_unchanged']
 record['success']=True
except BaseException:record['validation_error']=traceback.format_exc()
record['artifact_sha256']={str(p):bm.digest(p) for parent in [OUT,E/'retained-verified-screen-run'] for p in parent.rglob('*') if p.is_file()}
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['samples','artifact_sha256']}),flush=True)
raise SystemExit(0 if record['success'] else 1)
