"""Matched release ingestion with ordinary pressure collection enabled."""
import json
import os
import pathlib
import signal
import subprocess
import sys
import threading
import time

sys.path.insert(0, '/tmp/mnos-ingest/casita')
from benchmarks import build_manifest

evidence = pathlib.Path('/tmp/mnos-ingest/evidence')
repo = pathlib.Path('/tmp/mnos-ingest/mnos-nix-xp')
binaries = [('control', evidence / 'native-git-rotation-mnos-control-probe'),
            ('candidate', evidence / 'native-git-rotation-mnos-candidate-probe')]
builds = build_manifest.artifacts(binaries, fixture=True)
assert builds[0]['build']['fixture_sha256'] == builds[1]['build']['fixture_sha256']
assert builds[0]['build']['lockfile_sha256'] == builds[1]['build']['lockfile_sha256']
scenarios = json.loads((evidence / 'ingestion-scenarios.json').read_text())
scenario = sys.argv[1]
assert scenario in ('near', 'week', 'release')
case = scenarios['cases'][scenario]
reference = {}
for name in ('2026-10-06-wider-updates.json', '2026-10-06-object-reader-nar-batches.json'):
    rows = json.loads((repo / 'docs/reports/evidence/git-ingestion' / name).read_text())['identities']
    for revision, identity in rows.items():
        if revision in reference:
            assert all(reference[revision][key] == identity[key] for key in ('revision', 'git_tree', 'root', 'nar_hash', 'nar_bytes'))
        reference[revision] = identity
required = {scenarios['cases'][name][phase]['commit'] for name in ('near', 'week', 'release') for phase in ('from', 'to')}
assert required <= reference.keys(), required - reference.keys()
attempt = sys.argv[2] if len(sys.argv) > 2 else ''
assert not attempt or attempt.isalnum()
name_prefix = f'native-git-rotation-wide-{scenario}' + (f'-{attempt}' if attempt else '')
output = evidence / f'{name_prefix}.json'
assert not output.exists()
stop = False
def stop_between_runs(*_):
    global stop
    stop = True
    print('Stopping after the current run is retained.', flush=True)
signal.signal(signal.SIGTERM, stop_between_runs)
signal.signal(signal.SIGINT, stop_between_runs)
report = dict(complete=False, scenario_name=scenario, attempt=attempt, builds=builds, scenario=case, repository=scenarios['repository'],
              scope='Rotate repository-owned native Git import writers after eight publications and a drained decoded group; preserve caller-owned sessions and the initial metadata snapshot. Both builds use the accepted Mnos conversion rotation; ordinary pressure collection enabled.',
              protocol=dict(repetitions=4, order='C1,N1,N2,C2,C3,N3,N4,C4',
                            cpu_affinity=sorted(os.sched_getaffinity(0)),
                            retain_previous=True, stores_retained=True, concurrent_builds_or_tests=False,
                            pressure_observation='Read marker mtime every 50ms in parent thread; no modifications.',
                            pressure_limitations='Observed marker updates, not exact GC counts or proof of nonempty named marking; polling may miss updates.',
                            wal_observation='Stat WAL every 50ms; observed peak is a lower bound. Parent counts emitted stage/start lines to label samples; transitions may lag by a poll.',
                            source_cache='OS-managed local mirror; no explicit dropping or warming'), samples=[])
def save():
    output.write_text(json.dumps(report, indent=2) + '\n')
save()
try:
    for trial in range(1, 5):
        for variant, binary in (binaries if trial % 2 else binaries[::-1]):
            if stop:
                raise RuntimeError('interrupted between runs')
            name = f'{name_prefix}-{variant}-{trial}'
            scratch, log_path = evidence / name, evidence / (name + '.log')
            assert not scratch.exists() and not log_path.exists()
            env = dict(os.environ, MNOS_BENCH_RETAIN_PREVIOUS='1', MNOS_BENCH_DIR=str(scratch),
                       MNOS_BENCH_REPO=scenarios['repository'], MNOS_BENCH_REV=case['from']['commit'],
                       MNOS_BENCH_REV2=case['to']['commit'])
            command = [str(binary), '--ignored', '--nocapture', '--exact', 'import_large_git_tree']
            started, started_unix = time.monotonic(), time.time()
            load_start = os.getloadavg()
            filesystem = os.statvfs(evidence)
            print('Starting', name, flush=True)
            events = []
            wal_samples = []
            ended = threading.Event()
            with log_path.open('x') as log:
                child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT)
                cas = scratch / f'cas-{child.pid}'
                stamp = cas / '.casita-pressure-collection'
                def observe():
                    previous = None
                    while not ended.is_set():
                        try:
                            value = stamp.stat().st_mtime_ns
                        except FileNotFoundError:
                            value = None
                        if value is not None and value != previous:
                            events.append(dict(elapsed_seconds=time.monotonic()-started, mtime_ns=value))
                            previous = value
                        try:
                            wal_bytes = (cas / 'casita.sqlite-wal').stat().st_size
                            current_lines = [line.removeprefix('test import_large_git_tree ... ')
                                             for line in log_path.read_text().splitlines()]
                            starts = sum(line.startswith('git_ingest_start ') for line in current_lines)
                            stages_seen = sum(line.startswith('git_ingest_sample ') for line in current_lines)
                            wal_samples.append(dict(elapsed_seconds=time.monotonic()-started,
                                                    bytes=wal_bytes, starts_seen=starts, stages_seen=stages_seen))
                        except FileNotFoundError:
                            pass
                        ended.wait(.05)
                observer = threading.Thread(target=observe)
                observer.start()
                try:
                    _, status, usage = os.wait4(child.pid, 0)
                    wall = time.monotonic()-started
                    child.returncode = os.waitstatus_to_exitcode(status)
                finally:
                    ended.set()
                    observer.join()
            process = dict(exit_code=child.returncode, wall_seconds=wall, max_rss_bytes=usage.ru_maxrss*1024,
                           user_seconds=usage.ru_utime, system_seconds=usage.ru_stime,
                           input_blocks=usage.ru_inblock, output_blocks=usage.ru_oublock,
                           started_unix_seconds=started_unix,
                           load_start=load_start, load_end=os.getloadavg(),
                           filesystem_start=dict(total_bytes=filesystem.f_blocks*filesystem.f_frsize,
                                                 available_bytes=filesystem.f_bavail*filesystem.f_frsize))
            lines = [line.removeprefix('test import_large_git_tree ... ')
                     for line in log_path.read_text().splitlines()]
            def rows(prefix):
                return [json.loads(line[len(prefix):]) for line in lines if line.startswith(prefix)]
            identities, stages = rows('git_ingest_identity '), rows('git_ingest_sample ')
            inventory = []
            if cas.exists():
                for path in sorted(cas.rglob('*')):
                    if path.is_file():
                        stat = path.stat()
                        inventory.append(dict(path=str(path.relative_to(cas)), bytes=stat.st_size, allocated_bytes=stat.st_blocks*512))
            sample = dict(variant=variant, trial=trial, command=command, process=process, stages=stages,
                          identities=identities, pressure_events=events, wal_samples=wal_samples,
                          observed_peak_wal_bytes=max((row['bytes'] for row in wal_samples), default=0),
                          cas=str(cas), inventory=inventory)
            report['samples'].append(sample)
            save()
            assert child.returncode == 0, process
            assert rows('git_ingest_configuration ') == [{'retain_previous': True}]
            assert len(stages) == 6 and len(identities) == 2
            revisions = [case['from']['commit'], case['to']['commit']]
            assert [identity['revision'] for identity in identities] == revisions
            assert [(stage['revision'], stage['stage']) for stage in stages] == [
                (revision, stage) for revision in revisions for stage in ('import_git', 'git_tree', 'nar')]
            for identity in identities:
                expected = reference[identity['revision']]
                for key in ('revision', 'git_tree', 'root', 'nar_hash', 'nar_bytes'):
                    assert identity[key] == expected[key], (key, identity, expected)
            assert events, 'expected ordinary disk-pressure collection to be active'
            assert wal_samples, 'WAL observation must be present'
            print('Passed', name, wall, 'observed pressure-marker updates', len(events), flush=True)
    assert build_manifest.artifacts(binaries, fixture=True) == builds
    report['complete'] = True
except Exception as error:
    report['error'] = str(error)
    raise
finally:
    save()
