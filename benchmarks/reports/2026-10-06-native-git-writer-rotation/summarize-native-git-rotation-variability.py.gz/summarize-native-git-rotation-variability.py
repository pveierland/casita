"""Keep every pair while exposing CPU and collection-marker timing variation."""
import hashlib
import json
from pathlib import Path
import statistics
r=Path('/tmp/mnos-ingest/evidence')
result={}
for variant in ('full','detached'):
 prefix='native-git-rotation-'+('detached-' if variant=='detached' else '')
 result[variant]={}
 for case in ('near','week','release'):
  p=r/(prefix+'wide-'+case+'.json')
  d=json.loads(p.read_text());assert d['complete'] and len(d['samples'])==8
  pairs=[]
  for trial in range(1,5):
   pair={s['variant']:s for s in d['samples'] if s['trial']==trial}
   a,b=[pair[x] for x in ('control','candidate')]
   cpu=lambda s:s['process']['user_seconds']+s['process']['system_seconds']
   pairs.append(dict(trial=trial,wall_change_percent=(b['process']['wall_seconds']/a['process']['wall_seconds']-1)*100,
    cpu_change_percent=(cpu(b)/cpu(a)-1)*100,
    rss_change_percent=(b['process']['max_rss_bytes']/a['process']['max_rss_bytes']-1)*100,
    write_change_percent=(b['stages'][-1]['resources']['write_bytes']/a['stages'][-1]['resources']['write_bytes']-1)*100,
    control_marker_times=[e['elapsed_seconds'] for e in a['pressure_events']],
    candidate_marker_times=[e['elapsed_seconds'] for e in b['pressure_events']]))
  result[variant][case]=dict(source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),pairs=pairs,
    median_paired_changes={key:statistics.median(row[key] for row in pairs) for key in ('wall_change_percent','cpu_change_percent','rss_change_percent','write_change_percent')})
out=r/'native-git-rotation-variability.json';assert not out.exists()
out.write_text(json.dumps(dict(results=result,limitations=['All pairs are retained, including mismatched marker counts.',
 'Marker receipt times do not measure collection duration; no subtraction or adjusted throughput is inferred.',
 'CPU totals include asynchronous collection, setup, ingestion, conversion, NAR and process shutdown.',
 'Median paired changes differ from the primary ratio of independent medians; both are descriptive estimates, not confidence bounds.']),indent=2)+'\n')
for variant,cases in result.items():
 for case,data in cases.items():print(variant,case,data['median_paired_changes'])
