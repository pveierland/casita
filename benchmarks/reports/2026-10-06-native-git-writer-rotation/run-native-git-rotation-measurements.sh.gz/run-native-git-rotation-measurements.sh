#!/usr/bin/env bash
set -euo pipefail
source /tmp/mnos-ingest/devenv.sh
cd /tmp/mnos-ingest/casita
/nix/store/zw57vzaiyww9x37hdjqv7xc2p5r2q1fy-python3-3.13.13-env/bin/python3 -m benchmarks.suites.git_closure_import --probe-binary /tmp/mnos-ingest/evidence/native-git-rotation-candidate-probe --baseline-binary /tmp/mnos-ingest/evidence/native-git-rotation-control-probe --no-build --counts 509,510,511,1022,1023 --max-buffered-bytes 1024,65536 --file-bytes 1024 --concurrency 3 --backend memory --layout loose --repetitions 5 --output /tmp/mnos-ingest/evidence/native-git-rotation-component.json
for scenario in near week release; do
    /nix/store/zw57vzaiyww9x37hdjqv7xc2p5r2q1fy-python3-3.13.13-env/bin/python3 /tmp/mnos-ingest/measure-native-git-rotation-wide.py "$scenario"
    /nix/store/zw57vzaiyww9x37hdjqv7xc2p5r2q1fy-python3-3.13.13-env/bin/python3 /tmp/mnos-ingest/summarize-native-git-rotation-wide.py "$scenario" > "/tmp/mnos-ingest/evidence/native-git-rotation-wide-$scenario-summary.log"
    /nix/store/zw57vzaiyww9x37hdjqv7xc2p5r2q1fy-python3-3.13.13-env/bin/python3 /tmp/mnos-ingest/summarize-native-git-rotation-io.py "$scenario" > "/tmp/mnos-ingest/evidence/native-git-rotation-wide-$scenario-io-summary.log"
done
