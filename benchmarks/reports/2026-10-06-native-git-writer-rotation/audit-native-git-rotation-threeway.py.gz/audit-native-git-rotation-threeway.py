"""Audit all predeclared three-way runs and retain every paired effect."""
import hashlib
import itertools
import json
from pathlib import Path
import statistics
r=Path('/tmp/mnos-ingest/evidence')
p=r/'native-git-rotation-threeway-week.json'
d=json.loads(p.read_text())
variants=('control','full_guard','data_only')
orders=list(itertools.permutations(variants))
assert d['complete'] and len(d['samples'])==18
assert [(s['variant'],s['trial']) for s in d['samples']]==[(v,t) for t,o in enumerate(orders,1) for v in o]
assert d['protocol']['order']==[list(o) for o in orders]
refs={}
base=Path('/tmp/mnos-ingest/mnos-nix-xp/docs/reports/evidence/git-ingestion')
for name in ('2026-10-06-wider-updates.json','2026-10-06-object-reader-nar-batches.json'):
 for rev,identity in json.loads((base/name).read_text())['identities'].items():
  if rev in refs:
   assert all(refs[rev][k]==identity[k] for k in ('revision','git_tree','root','nar_hash','nar_bytes'))
  refs[rev]=identity
revs=[d['scenario'][phase]['commit'] for phase in ('from','to')]
def metrics(s):
 stages=s['stages'];proc=s['process']
 result=dict(wall_seconds=proc['wall_seconds'],cpu_seconds=proc['user_seconds']+proc['system_seconds'],
  peak_rss_bytes=proc['max_rss_bytes'],final_write_bytes=stages[-1]['resources']['write_bytes'],
  observed_peak_wal_bytes=s['observed_peak_wal_bytes'])
 for phase,offset in [('fresh',0),('update',3)]:
  for index,stage in enumerate(('import_git','git_tree','nar')):
   result[phase+'_'+stage+'_seconds']=stages[offset+index]['wall_seconds']
  result[phase+'_total_seconds']=sum(x['wall_seconds'] for x in stages[offset:offset+3])
  result[phase+'_import_write_bytes']=stages[offset]['resources']['write_bytes']-(stages[offset-1]['resources']['write_bytes'] if offset else 0)
 return result
for s in d['samples']:
 assert s['process']['exit_code']==0
 assert [i['revision'] for i in s['identities']]==revs
 assert [(x['revision'],x['stage']) for x in s['stages']]==[(rev,stage) for rev in revs for stage in ('import_git','git_tree','nar')]
 for identity in s['identities']:
  assert all(identity[k]==refs[identity['revision']][k] for k in ('revision','git_tree','root','nar_hash','nar_bytes'))
 polls=s['wal_samples'];assert polls and s['pressure_events']
 assert 0<=s['process']['wall_seconds']-polls[-1]['elapsed_seconds']<1
 assert s['observed_peak_wal_bytes']==max(x['bytes'] for x in polls)
 assert all(b['elapsed_seconds']>=a['elapsed_seconds'] for a,b in zip(polls,polls[1:]))
 values=[x['resources']['write_bytes'] for x in s['stages']]
 assert values==sorted(values)
medians={}
for v in variants:
 rows=[metrics(s) for s in d['samples'] if s['variant']==v]
 medians[v]={k:statistics.median(x[k] for x in rows) for k in rows[0]}
comparisons={}
for before,after in [('control','full_guard'),('control','data_only'),('full_guard','data_only')]:
 pairs=[]
 for trial in range(1,7):
  rows={s['variant']:s for s in d['samples'] if s['trial']==trial}
  a,b=[metrics(rows[v]) for v in (before,after)]
  pairs.append(dict(trial=trial,changes={k:(b[k]/a[k]-1)*100 for k in a if a[k]},
   before_marker_times=[x['elapsed_seconds'] for x in rows[before]['pressure_events']],
   after_marker_times=[x['elapsed_seconds'] for x in rows[after]['pressure_events']]))
 comparisons[before+'_to_'+after]=dict(pairs=pairs,
  change_percent={k:(medians[after][k]/a-1)*100 for k,a in medians[before].items() if a},
  median_paired_changes={k:statistics.median(x['changes'][k] for x in pairs) for k in pairs[0]['changes']})
run_context=[]
for s in d['samples']:
    proc=s['process']
    marks=[x['elapsed_seconds'] for x in s['pressure_events']]
    run_context.append(dict(variant=s['variant'],trial=s['trial'],wall_seconds=proc['wall_seconds'],
        cpu_seconds=proc['user_seconds']+proc['system_seconds'],load_start=proc['load_start'],load_end=proc['load_end'],
        available_disk_bytes=proc['filesystem_start']['available_bytes'],
        observed_completion_marker_seconds=marks,first_observed_marker_plus_cooldown_seconds=marks[0]+60,
        stages=[dict(stage=x['stage'],revision=x['revision'],wall_seconds=x['wall_seconds']) for x in s['stages']]))
result=dict(source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),complete_runs=18,identities_checked=36,
 medians=medians,comparisons=comparisons,run_context=run_context,
 observed_marker_counts={v:[len(s['pressure_events']) for s in d['samples'] if s['variant']==v] for v in variants},
 limitations=['All6permutations retained; no runs excluded for timing or marker changes.',
 'This follows an adverse initial data-only week matrix; confirmation does not invalidate or replace it.',
 'Marker updates record collection completion; first-observed time plus60s is an approximate eligibility point, not its next start or duration. Unmodified-stage differences alone do not establish a cause.',
 'WAL samples are lower-bound observations; OS caches and ambient workload are unmanaged.'])
out=r/'native-git-rotation-threeway-week-audit.json';assert not out.exists()
out.write_text(json.dumps(result,indent=2)+'\n')
print('18 runs,36 independent identities passed.')
for name,c in comparisons.items():
 print(name,{k:round(c['change_percent'][k],3) for k in ('wall_seconds','cpu_seconds','peak_rss_bytes','final_write_bytes')})
 print('Median paired changes:',{k:round(c['median_paired_changes'][k],3) for k in ('wall_seconds','cpu_seconds','peak_rss_bytes','final_write_bytes')})
print('Observed pressure-marker counts:',result['observed_marker_counts'])
