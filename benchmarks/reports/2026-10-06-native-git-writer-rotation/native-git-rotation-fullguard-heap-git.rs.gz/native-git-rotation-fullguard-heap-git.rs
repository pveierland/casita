//! Native Git objects stored in Casita, and store trees built from them.
//!
//! Git trees and blobs are staged with their exact native bodies (see
//! [`crate::TreeBuilder::git_object`]) under Casita's type-qualified Git
//! namespaces, so a Git object that is stored once is known by its object
//! id afterwards. A Git blob's payload is its raw contents, so the regular
//! files of a tree built from Git objects share their payloads with the
//! blobs. [`Cas::git_tree`] converts a stored Git tree into a store tree
//! (Casita directories) without reading any file contents, applying path
//! exclusions (`export-ignore`) and submodule grafts.

use crate::cancellation::Cancellation;
use std::sync::atomic::{AtomicBool, Ordering};
use crate::error::{CasError, StorageOperation, StorageResult, ValueText};
use crate::ingest::{GitObjectBody, GitOid, StagedObjects};
use crate::object::{CasNode, DescendantCount, HeldObject};
use crate::records::{MAX_RECORD_WRITES, RecordKey, RecordSpace, RecordValue, RecordWrite, SpaceLiteral};
use crate::repository::{Cas, read_payload};
use crate::tree::{Excluded, Exclusions, TreePath};
use bytes::Bytes;
use casita::experimental::{GitTreeMode, git_object_key, parse_git_tree};
use casita::{Directory, Node, ObjectKey, PathComponent, RetainedReader};
use mnos_eval_prim::{byte_views, static_texts, switches, unit_scalars};
use mnos_eval_store::hash::ByteCount;
use mnos_eval_store::tree::EntryName;
use futures::StreamExt;
use rustc_hash::{FxHashMap, FxHashSet};
use std::collections::BTreeMap;

pub use casita::experimental::{GitObjectFormat, GitObjectKind};

switches! {
    /// Whether an object is stored.
    pub enum Presence { Absent, Present }
}

static_texts! {
    /// A file name with special meaning inside Git trees.
    pub GitFileName;
}

/// Per-directory Git attribute files.
pub const GIT_ATTRIBUTES: GitFileName = GitFileName::literal(".gitattributes");

unit_scalars! {
    /// Repository operations kept in flight at once.
    pub Concurrency(usize);
    /// The length in bytes of a field of a record.
    FieldLength(usize);
}

/// Metadata reads in flight while a stored Git tree is loaded.
const READS_AT_ONCE: Concurrency = Concurrency::new(64);
/// Objects staged at once when a store tree is built: Casita merges the
/// durable pin updates of the writes in flight into one.
const STAGED_AT_ONCE: Concurrency = Concurrency::new(64);

/// Bound writer pin growth while amortizing reader admission across publications.
const PUBLICATIONS_PER_WRITER: usize = 8;

switches! {
    /// Whether a conversion reuses (and records) converted subtrees: only
    /// when nothing is excluded or grafted, so a Git tree has one store
    /// tree.
    enum Reuse { Off, On }
}

/// Store directories of converted Git subtrees, keyed by Git tree id: a
/// later revision sharing most subtrees (another nixpkgs commit) converts
/// only what changed. Values are a hint; a directory collected since is
/// converted again.
pub const DIRECTORY_SPACE: SpaceLiteral = SpaceLiteral::literal("mnos-eval.git-directory.v1");
/// Cache every nonempty attribute-free subtree. Small directories dominate
/// nixpkgs, so omitting them makes retained updates repeat most conversion.
const RECORDED_DESCENDANTS: DescendantCount = DescendantCount::new(1);
/// Metadata keys per batched lookup.
const LOOKUPS_AT_ONCE: Concurrency = Concurrency::new(1024);
/// A recorded subtree: the directory digest, then its descendant count
/// (little endian).
const DIGEST_LENGTH: FieldLength = FieldLength::new(32);

/// A native Git object named by format, type and object id.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct GitObjectRef {
    pub format: GitObjectFormat,
    pub kind: GitObjectKind,
    pub oid: GitOid,
}

impl GitObjectRef {
    pub(crate) fn key(&self) -> Result<ObjectKey, CasError> {
        git_object_key(
            self.format,
            self.kind,
            Bytes::copy_from_slice(self.oid.raw()),
        )
        .map_err(|error| CasError::corrupt("Git object id", error))
    }
}

/// How a Git tree becomes a store tree.
#[derive(Clone, Debug, Default)]
pub struct GitTreeOptions {
    /// Paths left out with everything below them (`export-ignore`).
    pub exclusions: Exclusions,
    /// Stored trees placed at submodule (gitlink) paths. Gitlinks without a
    /// graft become empty directories, like `git archive`.
    pub submodules: BTreeMap<TreePath, CasNode>,
}

/// A store tree built from a Git tree.
#[derive(Debug)]
pub struct GitTreeObject {
    pub object: HeldObject,
    /// Every `.gitattributes` regular file the Git tree contains (excluded
    /// ones included), in tree order.
    pub attribute_files: Vec<TreePath>,
}

/// A decoded Git tree entry.
struct Entry {
    mode: GitTreeMode,
    name: EntryName,
    oid: GitOid,
}

/// A stored blob's payload (its raw contents) and size.
#[derive(Clone, Copy)]
struct BlobPayload {
    digest: casita::BlobId,
    size: ByteCount,
}

/// Everything read from the repository to convert one tree.
#[derive(Default)]
struct Loaded {
    trees: FxHashMap<GitOid, Vec<Entry>>,
    blobs: FxHashMap<GitOid, BlobPayload>,
    symlinks: FxHashMap<GitOid, casita::SymlinkTarget>,
    /// Subtrees converted before, still stored (protected by the reader).
    reused: FxHashMap<GitOid, Node>,
}

/// A converted subtree: its Git tree and store directory node.
struct ConvertedTree {
    oid: GitOid,
    node: Node,
}

fn directory_key(oid: &GitOid) -> RecordKey {
    RecordKey::from(oid.raw())
}

fn encode_directory(node: &Node) -> Option<RecordValue> {
    let Node::Directory { digest, size } = node else {
        return None;
    };
    let mut value = digest.as_digest().as_bytes().to_vec();
    value.extend_from_slice(&size.to_le_bytes());
    Some(RecordValue::from(value))
}

byte_views! {
    /// A recorded directory node: its 32-byte digest, then its size
    /// (little-endian 64-bit).
    EncodedDirectory;
}

fn decode_directory(value: EncodedDirectory<'_>) -> Option<Node> {
    let (digest, size) = value.raw().split_at_checked(DIGEST_LENGTH.raw())?;
    let digest = <[u8; 32]>::try_from(digest).ok()?;
    let size = <[u8; 8]>::try_from(size).ok()?;
    Some(Node::Directory {
        digest: casita::DirectoryId::new(casita::Digest::from(digest)),
        size: u64::from_le_bytes(size),
    })
}

/// Subtrees split by whether they can be reused.
struct Reusable {
    found: Vec<ConvertedTree>,
    missing: Vec<GitOid>,
}

/// Which of `candidates` were converted before and are still stored.
async fn reusable(
    reader: &RetainedReader,
    candidates: Vec<GitOid>,
    cancellation: &Cancellation,
) -> Result<Reusable, CasError> {
    let space = RecordSpace::builtin(DIRECTORY_SPACE);
    let mut recorded = Vec::new();
    let mut missing = Vec::new();
    for chunk in candidates.chunks(LOOKUPS_AT_ONCE.raw()) {
        cancellation.check()?;
        let keys: Vec<_> = chunk
            .iter()
            .map(|oid| space.metadata_key(&directory_key(oid)))
            .collect();
        let values = reader.get(&keys).await.during(StorageOperation::Read)?;
        for (oid, value) in chunk.iter().zip(values) {
            match value.as_deref().map(EncodedDirectory::from_raw).and_then(decode_directory) {
                Some(node) => recorded.push(ConvertedTree {
                    oid: oid.clone(),
                    node,
                }),
                None => missing.push(oid.clone()),
            }
        }
    }
    // A recorded directory may have been collected since.
    let checked: Vec<_> = futures::stream::iter(recorded)
        .take_while(|_| std::future::ready(!cancellation.is_cancelled()))
        .map(|tree| async move {
            let Node::Directory { digest, .. } = &tree.node else {
                return Ok((tree, Presence::Absent));
            };
            let stored = reader
                .object(&ObjectKey::directory(*digest))
                .await
                .during(StorageOperation::Read)?;
            Ok::<_, CasError>((tree, Presence::from_raw(stored.is_some())))
        })
        .buffer_unordered(READS_AT_ONCE.raw())
        .collect()
        .await;
    cancellation.check()?;
    let mut found = Vec::new();
    for result in checked {
        let (tree, presence) = result?;
        match presence {
            Presence::Present => found.push(tree),
            Presence::Absent => missing.push(tree.oid),
        }
    }
    Ok(Reusable { found, missing })
}

fn missing(object: &ObjectKey) -> CasError {
    CasError::ObjectMissing {
        object: ValueText::from(object.to_string()),
    }
}

async fn read_body(reader: &RetainedReader, key: &ObjectKey) -> Result<GitObjectBody, CasError> {
    let mut opened = reader
        .open_verified(key)
        .await
        .during(StorageOperation::Read)?
        .ok_or_else(|| missing(key))?;
    let body = read_payload(&mut opened)
        .await
        .map_err(|error| CasError::corrupt(key, error))?;
    Ok(GitObjectBody::from(body.into_vec()))
}

/// The payload metadata or decoded content returned by one [`load`] request.
enum Read {
    Tree {
        oid: GitOid,
        entries: Vec<Entry>,
    },
    Blobs(Vec<(GitOid, BlobPayload)>),
    Symlink {
        oid: GitOid,
        target: casita::SymlinkTarget,
    },
}

/// Objects one level of [`load`] already asked for, by how they are read.
#[derive(Default)]
struct Queued {
    trees: FxHashSet<GitOid>,
    blobs: FxHashSet<GitOid>,
    symlinks: FxHashSet<GitOid>,
}

/// One tree, symlink, or bounded batch of blob records [`load`] still has to read.
enum Wanted {
    Tree(GitOid),
    Blobs(Vec<GitOid>),
    Symlink(GitOid),
}

async fn read_object(
    reader: &RetainedReader,
    format: GitObjectFormat,
    wanted: Wanted,
) -> Result<Read, CasError> {
    let reference = |kind, oid: &GitOid| {
        GitObjectRef {
            format,
            kind,
            oid: oid.clone(),
        }
        .key()
    };
    match wanted {
        Wanted::Tree(oid) => {
            let key = reference(GitObjectKind::Tree, &oid)?;
            let body = read_body(reader, &key).await?;
            let parsed =
                parse_git_tree(format, &body).map_err(|error| CasError::corrupt(&key, error))?;
            let entries = parsed
                .into_iter()
                .map(|entry| Entry {
                    mode: entry.mode,
                    name: EntryName::from(entry.name),
                    oid: GitOid::from(entry.oid),
                })
                .collect();
            Ok(Read::Tree { oid, entries })
        }
        Wanted::Blobs(oids) => {
            let keys = oids
                .iter()
                .map(|oid| reference(GitObjectKind::Blob, oid))
                .collect::<Result<Vec<_>, _>>()?;
            let records = reader
                .object_batch(&keys)
                .await
                .during(StorageOperation::Read)?;
            let blobs = oids
                .into_iter()
                .zip(keys)
                .zip(records)
                .map(|((oid, key), record)| {
                    let record = record.ok_or_else(|| missing(&key))?;
                    Ok((
                        oid,
                        BlobPayload {
                            digest: record.payload(),
                            size: ByteCount::new(record.payload_size()),
                        },
                    ))
                })
                .collect::<Result<Vec<_>, CasError>>()?;
            Ok(Read::Blobs(blobs))
        }
        Wanted::Symlink(oid) => {
            let key = reference(GitObjectKind::Blob, &oid)?;
            let body = read_body(reader, &key).await?;
            let target = casita::SymlinkTarget::try_from(Bytes::from(body.into_vec()))
                .map_err(|error| CasError::corrupt(&key, error))?;
            Ok(Read::Symlink { oid, target })
        }
    }
}

/// Read trees and batched blob records below `root`, one tree level at a
/// time with at most [`READS_AT_ONCE`] requests in flight.
async fn load(
    reader: &RetainedReader,
    format: GitObjectFormat,
    root: &GitOid,
    reuse: Reuse,
    cancellation: &Cancellation,
) -> Result<Loaded, CasError> {
    let mut loaded = Loaded::default();
    let mut level = vec![Wanted::Tree(root.clone())];
    let mut queued = Queued::default();
    while !level.is_empty() {
        cancellation.check()?;
        let stopped = AtomicBool::new(false);
        let mut failure = None;
        let reads = futures::stream::iter(level)
            .take_while(|_| std::future::ready(!stopped.load(Ordering::Relaxed) && !cancellation.is_cancelled()))
            .map(|wanted| read_object(reader, format, wanted))
            .buffer_unordered(READS_AT_ONCE.raw());
        let mut reads = std::pin::pin!(reads);
        let mut next = Vec::new();
        let mut blobs = Vec::new();
        // Subtrees to look up before reading them.
        let mut candidates = Vec::new();
        while let Some(read) = reads.next().await {
            // Stop admitting reads but drain every one already started.
            if cancellation.is_cancelled() || failure.is_some() { continue; }
            let read = match read {
                Ok(read) => read,
                Err(error) => {
                    stopped.store(true, Ordering::Relaxed);
                    failure = Some(error);
                    continue;
                }
            };
            match read {
                Read::Tree { oid, entries } => {
                    for entry in &entries {
                        let oid = &entry.oid;
                        let wanted = match entry.mode {
                            GitTreeMode::Tree
                                if !loaded.trees.contains_key(oid)
                                    && queued.trees.insert(oid.clone()) =>
                            {
                                if reuse == Reuse::On {
                                    candidates.push(oid.clone());
                                    continue;
                                }
                                Wanted::Tree(oid.clone())
                            }
                            GitTreeMode::Blob | GitTreeMode::BlobExecutable
                                if !loaded.blobs.contains_key(oid)
                                    && queued.blobs.insert(oid.clone()) =>
                            {
                                blobs.push(oid.clone());
                                if blobs.len() == LOOKUPS_AT_ONCE.raw() {
                                    next.push(Wanted::Blobs(std::mem::take(&mut blobs)));
                                }
                                continue;
                            }
                            GitTreeMode::Symlink
                                if !loaded.symlinks.contains_key(oid)
                                    && queued.symlinks.insert(oid.clone()) =>
                            {
                                Wanted::Symlink(oid.clone())
                            }
                            _ => continue,
                        };
                        next.push(wanted);
                    }
                    loaded.trees.insert(oid, entries);
                }
                Read::Blobs(blobs) => {
                    loaded.blobs.extend(blobs);
                }
                Read::Symlink { oid, target } => {
                    loaded.symlinks.insert(oid, target);
                }
            }
        }
        drop(reads);
        cancellation.check()?;
        if let Some(error) = failure { return Err(error); }
        if !blobs.is_empty() {
            next.push(Wanted::Blobs(blobs));
        }
        if !candidates.is_empty() {
            let Reusable { found, missing } = reusable(reader, candidates, cancellation).await?;
            for tree in found {
                loaded.reused.insert(tree.oid, tree.node);
            }
            next.extend(missing.into_iter().map(Wanted::Tree));
        }
        level = next;
    }
    Ok(loaded)
}

/// The synchronous conversion of loaded trees into Casita directories.
struct Converter<'a> {
    cancellation: &'a Cancellation,
    loaded: &'a Loaded,
    options: &'a GitTreeOptions,
    /// Directories to stage, children before parents.
    planned: Vec<Directory>,
    attribute_files: Vec<TreePath>,
    /// Regular files the tree refers to.
    files: Vec<FileBlob>,
    reuse: Reuse,
    /// Subtrees converted here worth recording (no `.gitattributes` below,
    /// so a reuse loses nothing).
    converted: Vec<ConvertedTree>,
}

/// A regular file of a converted tree: its payload and the Git blob
/// storing it.
struct FileBlob {
    digest: casita::BlobId,
    oid: GitOid,
}

fn component(name: &EntryName) -> Result<PathComponent, CasError> {
    PathComponent::try_from(Bytes::copy_from_slice(name.raw()))
        .map_err(|error| CasError::corrupt(format_args!("Git tree entry '{name}'"), error))
}

impl Converter<'_> {
    fn directory(&mut self, tree: &GitOid, path: &TreePath) -> Result<Node, CasError> {
        self.cancellation.check()?;
        let loaded = self.loaded;
        let entries = loaded
            .trees
            .get(tree)
            .ok_or_else(|| CasError::corrupt("Git tree conversion", "tree was not loaded"))?;
        let mut directory = Directory::new();
        for entry in entries {
            self.cancellation.check()?;
            let child = path.join(entry.name.clone());
            if entry.name.raw() == GIT_ATTRIBUTES.raw().as_bytes()
                && matches!(entry.mode, GitTreeMode::Blob | GitTreeMode::BlobExecutable)
            {
                self.attribute_files.push(child.clone());
            }
            if self.options.exclusions.excludes(child.components()) == Excluded::Yes {
                continue;
            }
            let node = match entry.mode {
                GitTreeMode::Tree => match loaded.reused.get(&entry.oid) {
                    Some(node) => node.clone(),
                    None => {
                        let attributes_before = self.attribute_files.len();
                        let node = self.directory(&entry.oid, &child)?;
                        if self.reuse == Reuse::On
                            && self.attribute_files.len() == attributes_before
                            && let Node::Directory { size, .. } = &node
                            && DescendantCount::new(*size) >= RECORDED_DESCENDANTS
                        {
                            self.converted.push(ConvertedTree {
                                oid: entry.oid.clone(),
                                node: node.clone(),
                            });
                        }
                        node
                    }
                },
                GitTreeMode::Blob | GitTreeMode::BlobExecutable => {
                    let blob = loaded.blobs.get(&entry.oid).ok_or_else(|| {
                        CasError::corrupt("Git tree conversion", "blob was not loaded")
                    })?;
                    self.files.push(FileBlob {
                        digest: blob.digest,
                        oid: entry.oid.clone(),
                    });
                    Node::File {
                        digest: blob.digest,
                        size: blob.size.raw(),
                        executable: entry.mode == GitTreeMode::BlobExecutable,
                    }
                }
                GitTreeMode::Symlink => Node::Symlink {
                    target: loaded
                        .symlinks
                        .get(&entry.oid)
                        .ok_or_else(|| {
                            CasError::corrupt("Git tree conversion", "symlink was not loaded")
                        })?
                        .clone(),
                },
                GitTreeMode::Gitlink => match self.options.submodules.get(&child) {
                    Some(node) => node.to_casita()?,
                    None => {
                        let empty = Directory::new();
                        let node = Node::Directory {
                            digest: empty.digest(),
                            size: empty.size(),
                        };
                        self.planned.push(empty);
                        node
                    }
                },
            };
            directory
                .add(component(&entry.name)?, node)
                .map_err(|error| CasError::corrupt(format_args!("Git tree '{child}'"), error))?;
        }
        let node = Node::Directory {
            digest: directory.digest(),
            size: directory.size(),
        };
        self.planned.push(directory);
        Ok(node)
    }
}

impl Cas {
    /// Which objects are reusable. Blobs need a stored record; trees,
    /// commits and tags need a recorded validation of their whole closure.
    pub fn git_presence(&self, objects: &[GitObjectRef]) -> Result<Vec<Presence>, CasError> {
        let reader = self.retained_reader()?;
        self.block_on(async {
            let mut presence = Vec::with_capacity(objects.len());
            for chunk in objects.chunks(LOOKUPS_AT_ONCE.raw()) {
                let keys = chunk.iter().map(GitObjectRef::key).collect::<Result<Vec<_>, _>>()?;
                let mut blobs = Vec::new();
                let mut closures = Vec::new();
                for (object, key) in chunk.iter().zip(&keys) {
                    if object.kind == GitObjectKind::Blob {
                        blobs.push(key.clone());
                    } else {
                        closures.push(key.clone());
                    }
                }
                let mut blobs = reader.object_batch(&blobs).await
                    .during(StorageOperation::Query)?.into_iter();
                let mut closures = reader.validated_closures(&closures).await
                    .during(StorageOperation::Query)?.into_iter();
                for object in chunk {
                    let present = if object.kind == GitObjectKind::Blob {
                        blobs.next().expect("one result per blob").is_some()
                    } else {
                        closures.next().expect("one result per closure")
                    };
                    presence.push(Presence::from_raw(present));
                }
            }
            Ok(presence)
        })
    }

    /// The native body of a stored Git object.
    pub fn git_object_body(
        &self,
        object: &GitObjectRef,
    ) -> Result<Option<GitObjectBody>, CasError> {
        let reader = self.retained_reader()?;
        let key = object.key()?;
        self.block_on(async {
            match reader.object(&key).await.during(StorageOperation::Read)? {
                None => Ok(None),
                Some(_) => Ok(Some(read_body(&reader, &key).await?)),
            }
        })
    }

    /// Build a store tree from a stored Git tree: Git blobs become regular
    /// files (executable for mode `100755`), symlink blobs become symlinks,
    /// gitlinks become their graft or an empty directory.
    pub fn git_tree(
        &self,
        format: GitObjectFormat,
        tree: &GitOid,
        options: &GitTreeOptions,
    ) -> Result<GitTreeObject, CasError> {
        self.git_tree_with(format, tree, options, &Cancellation::default())
    }

    /// Convert with cooperative cancellation between bounded read and write
    /// batches. Writes already started settle before this returns.
    pub fn git_tree_cancellable(
        &self,
        format: GitObjectFormat,
        tree: &GitOid,
        options: &GitTreeOptions,
        cancellation: &mnos_eval_io::CancellationToken,
    ) -> Result<GitTreeObject, CasError> {
        self.git_tree_with(format, tree, options, &Cancellation::from(cancellation))
    }

    fn git_tree_with(
        &self,
        format: GitObjectFormat,
        tree: &GitOid,
        options: &GitTreeOptions,
        cancellation: &Cancellation,
    ) -> Result<GitTreeObject, CasError> {
        cancellation.check()?;
        let backend = self.backend();
        let reuse = Reuse::from_raw(options.exclusions == Exclusions::default() && options.submodules.is_empty());
        let (root, hold, attribute_files, converted) = self.block_on(async {
            let reader = backend
                .retained_reader()
                .await
                .during(StorageOperation::Read)?;
            let loaded = load(&reader, format, tree, reuse, cancellation).await?;
            let mut converter = Converter {
                cancellation,
                loaded: &loaded,
                options,
                planned: Vec::new(),
                attribute_files: Vec::new(),
                files: Vec::new(),
                reuse,
                converted: Vec::new(),
            };
            let root = converter.directory(tree, &TreePath::root())?;
            let Converter {
                planned,
                attribute_files,
                mut files,
                converted,
                ..
            } = converter;
            drop(loaded);
            files.sort_unstable_by_key(|file| file.digest);
            files.dedup_by_key(|file| file.digest);
            cancellation.check()?;
            let mut session = backend.mutation_session().await.during(StorageOperation::Ingest)?;
            let mut published = None;
            let mut publications = 0;
            let batch_size = crate::ingest::PUBLISH_BATCH.as_index();
            for files in files.chunks(batch_size) {
                cancellation.check()?;
                // The Git and plain-file records share a payload. Register
                // missing aliases with one metadata read/protection/recheck
                // per batch, without opening or hashing file contents again.
                let keys: Vec<_> = files.iter().map(|file| ObjectKey::blob(file.digest)).collect();
                let present = reader.object_batch(&keys).await.during(StorageOperation::Read)?;
                let missing = files.iter().zip(present)
                    .filter(|(_, record)| record.is_none())
                    .map(|(file, _)| GitObjectRef {
                        format,
                        kind: GitObjectKind::Blob,
                        oid: file.oid.clone(),
                    }.key())
                    .collect::<Result<Vec<_>, _>>()?;
                cancellation.check()?;
                if !missing.is_empty() {
                    if publications == PUBLICATIONS_PER_WRITER {
                        // Protect committed objects before replacing their
                        // writer pin, without repeating mutation-start GC.
                        published = Some(backend.retained_reader().await
                            .during(StorageOperation::Ingest)?.retain_objects());
                        session.rotate().await.during(StorageOperation::Ingest)?;
                        publications = 0;
                    }
                    let staged = session.stage_git_blob_files(&missing).await
                        .during(StorageOperation::Ingest)?;
                    cancellation.check()?;
                    session.publish_unrooted(staged).await.during(StorageOperation::Ingest)?;
                    publications += 1;
                }
            }
            drop(files);
            // Preserve children-before-parents ordering, including across
            // publications, while retaining only one batch of staged objects.
            let mut directories = planned.into_iter().peekable();
            while directories.peek().is_some() {
                cancellation.check()?;
                if publications == PUBLICATIONS_PER_WRITER {
                    // Acquire the next generation while both the writer and
                    // previous generation still protect earlier publications.
                    published = Some(backend.retained_reader().await
                        .during(StorageOperation::Ingest)?.retain_objects());
                    session.rotate().await.during(StorageOperation::Ingest)?;
                    publications = 0;
                }
                let staging = &session;
                // Bound input before buffering: leaving later staging futures
                // paused during publication can retain locks needed to flush.
                let staged = futures::stream::iter(directories.by_ref().take(batch_size))
                    .take_while(|_| std::future::ready(!cancellation.is_cancelled()))
                    .map(|directory| async move {
                        staging.stage_directory(&directory).await.during(StorageOperation::Ingest)
                    })
                    .buffered(STAGED_AT_ONCE.raw())
                    .collect::<Vec<_>>()
                    .await
                    .into_iter()
                    .collect::<Result<Vec<_>, _>>()?;
                cancellation.check()?;
                session.publish_unrooted(staged).await.during(StorageOperation::Ingest)?;
                publications += 1;
            }
            let hold = backend
                .retained_reader()
                .await
                .during(StorageOperation::Ingest)?;
            drop(reader);
            drop(session);
            drop(published);
            Ok::<_, CasError>((root, hold, attribute_files, converted))
        })?;
        let object = HeldObject::new(
            self.clone(),
            self.retain(self.in_runtime(hold))?,
            CasNode::from_casita(&root),
        );
        cancellation.check()?;
        self.record_directories(converted, cancellation)?;
        cancellation.check()?;
        Ok(GitTreeObject {
            object,
            attribute_files,
        })
    }
}

impl Cas {
    /// Record converted subtrees for reuse ([`DIRECTORY_SPACE`]), after
    /// their directories are published.
    fn record_directories(&self, mut converted: Vec<ConvertedTree>, cancellation: &Cancellation) -> Result<(), CasError> {
        cancellation.check()?;
        converted.sort_unstable_by(|left, right| left.oid.cmp(&right.oid));
        converted.dedup_by(|left, right| left.oid == right.oid);
        let space = RecordSpace::builtin(DIRECTORY_SPACE);
        for chunk in converted.chunks(MAX_RECORD_WRITES.raw()) {
            cancellation.check()?;
            let entries: Vec<_> = chunk
                .iter()
                .filter_map(|tree| Some((directory_key(&tree.oid), encode_directory(&tree.node)?)))
                .collect();
            let writes: Vec<_> = entries
                .iter()
                .map(|(key, value)| RecordWrite {
                    space: &space,
                    key,
                    value,
                    retain: None,
                })
                .collect();
            self.put_records(&writes)?;
        }
        Ok(())
    }
}

unit_scalars! {
    /// Native Git objects visited by an import.
    pub ImportedObjects(usize);
}

/// Git objects staged at once by an import.
const IMPORT_STAGED_AT_ONCE: Concurrency = Concurrency::new(64);

/// What [`Cas::import_git`] did.
#[derive(Debug)]
pub struct GitImportSummary {
    /// Native objects decoded and stored; zero when every requested object
    /// was already stored.
    pub objects: ImportedObjects,
    /// Keeps the imported closures from collection until the caller has
    /// retained them otherwise (for example by a record).
    pub held: Option<StagedObjects>,
}

impl Cas {
    /// Import the closures of `objects` (for example one commit's tree)
    /// from the Git object directory of a local repository
    /// (`git rev-parse --git-path objects`, alternates followed) with
    /// Casita's closure importer, and nothing else of the repository.
    /// Stored subtrees are reused without reading the source; when every
    /// requested object is already stored nothing is read at all. Objects
    /// are decoded on Casita's blocking worker and staged concurrently,
    /// so durable pin updates are shared by the objects in flight. The
    /// import roots nothing: the summary's hold protects the closures until
    /// the caller records them.
    pub fn import_git(
        &self,
        objects_dir: &std::path::Path,
        objects: &[GitObjectRef],
    ) -> Result<GitImportSummary, CasError> {
        self.import_git_with(objects_dir, objects, &Cancellation::default())
    }

    /// Import with cooperative cancellation, draining already started writes.
    pub fn import_git_cancellable(
        &self,
        objects_dir: &std::path::Path,
        objects: &[GitObjectRef],
        cancellation: &mnos_eval_io::CancellationToken,
    ) -> Result<GitImportSummary, CasError> {
        self.import_git_with(objects_dir, objects, &Cancellation::from(cancellation))
    }

    fn import_git_with(
        &self,
        objects_dir: &std::path::Path,
        objects: &[GitObjectRef],
        cancellation: &Cancellation,
    ) -> Result<GitImportSummary, CasError> {
        cancellation.check()?;
        if objects.is_empty() {
            return Ok(GitImportSummary {
                objects: ImportedObjects::ZERO,
                held: None,
            });
        }
        let keys = objects
            .iter()
            .map(GitObjectRef::key)
            .collect::<Result<Vec<_>, _>>()?;
        let objects_dir = std::path::absolute(objects_dir)
            .map_err(|error| CasError::corrupt("Git import source", error))?;
        let mut import = casita::import::GitClosureImport::new(objects_dir, keys)
            .with_concurrency(
                std::num::NonZeroUsize::new(IMPORT_STAGED_AT_ONCE.raw())
                    .unwrap_or(std::num::NonZeroUsize::MIN),
            );
        if cancellation.is_enabled() {
            let cancellation = cancellation.clone();
            import = import.with_cancellation_check(move || cancellation.is_cancelled());
        }
        let backend = self.backend();
        let (imported, hold) = self.block_on(async {
            let outcome = backend
                .import(import)
                .await
                .during(StorageOperation::Ingest)?;
            // A reader taken while the import's own protection is alive
            // sees and protects everything it stored.
            let hold = backend
                .retained_reader()
                .await
                .during(StorageOperation::Ingest)?;
            drop(outcome.reader);
            Ok::<_, CasError>((outcome.report.imported_objects, hold))
        })?;
        cancellation.check()?;
        Ok(GitImportSummary {
            objects: ImportedObjects::new(imported),
            held: Some(StagedObjects::new(self.retain(self.in_runtime(hold))?)),
        })
    }
}
