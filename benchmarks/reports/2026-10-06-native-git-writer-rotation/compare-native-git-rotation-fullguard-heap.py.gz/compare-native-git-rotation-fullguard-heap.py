"""Compare live heap for the identical fresh release fixture; not RSS or timing."""
import hashlib
import json
from pathlib import Path

root = Path('/tmp/mnos-ingest/evidence')
profiles = {}
for name, prefix, binary in [
    ('control', 'git-publication-rotation-heap', 'native-git-rotation-mnos-control-probe'),
    ('candidate', 'native-git-rotation-fullguard-heap', 'native-git-rotation-mnos-candidate-probe'),
]:
    summary_path = root / (prefix + '-summary.json')
    analysis_path = root / (prefix + '-analysis.json')
    summary = json.loads(summary_path.read_text())
    analysis = json.loads(analysis_path.read_text())
    assert summary['complete'] and summary['exit_code'] == 0
    assert summary['massif_sha256'] == analysis['sha256']
    with (root / (prefix + '.massif')).open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == analysis['sha256']
    with (root / binary).open('rb') as stream:
        binary_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert summary['build']['sha256'] == binary_sha
    rows = analysis['snapshots']
    assert len(rows) == len(summary['snapshots'])
    identity, = [event['value'] for event in summary['stage_events'] if event['kind'] == 'git_ingest_identity']
    for key in ('revision', 'git_tree', 'root', 'nar_hash', 'nar_bytes'):
        assert identity[key] == summary['expected_identity'][key]
    detailed = [row for row in rows if 'stack_category_bytes' in row]
    peak = max(rows, key=lambda row: row['mem_heap_B'])
    profiles[name] = dict(binary_sha256=binary_sha, summary_sha256=hashlib.sha256(summary_path.read_bytes()).hexdigest(),
        analysis_sha256=hashlib.sha256(analysis_path.read_bytes()).hexdigest(), massif_sha256=analysis['sha256'],
        identity=identity, snapshots=len(rows), payload_heap_peak=peak,
        total_profiled_peak=max(rows, key=lambda row: sum(row[k] for k in ('mem_heap_B', 'mem_heap_extra_B', 'mem_stacks_B'))),
        category_maxima={key: max(row['stack_category_bytes'][key] for row in detailed)
                         for key in detailed[0]['stack_category_bytes']})
assert profiles['control']['identity'] == profiles['candidate']['identity']
a,b = [profiles[name]['payload_heap_peak']['mem_heap_B'] for name in ('control','candidate')]
result = dict(scope='Sampled live system-allocator heap for one fresh release Git import, conversion and NAR pass, with diagnostic advisory-GC deferral.',
    profiles=profiles, payload_heap_peak_change_bytes=b-a, payload_heap_peak_change_percent=(b/a-1)*100,
    limitations=['The control reuses the previously recorded profile of the byte-identical binary; native timing uses newly paired controls.',
        'Profiler slowdown, stack threshold and sampling differ from ordinary execution; no timing, RSS or browser-memory claim.',
        'Live heap excludes untracked mappings, allocator retention and thread stacks.',
        'Category maxima occur at different times and cannot be summed.',
        'Zero stack-attributed bytes do not imply zero allocations; hidden frames remain unresolved.',
        'Original input SQL snapshot remains; wide dependency lists and final selected-root proof are not fixed memory bounds.'])
out=root/'native-git-rotation-fullguard-heap-comparison.json'
assert not out.exists()
out.write_text(json.dumps(result,indent=2)+'\n')
print('Payload heap peak bytes:',a,'->',b,'change %:',result['payload_heap_peak_change_percent'])
for name, row in profiles.items():
    print(name,'peak categories:',row['payload_heap_peak'].get('stack_category_bytes'))
    print(name,'category maxima:',row['category_maxima'])
