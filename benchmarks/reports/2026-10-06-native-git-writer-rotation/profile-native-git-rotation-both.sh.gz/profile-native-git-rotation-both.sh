#!/usr/bin/env bash
set -euo pipefail
source /tmp/mnos-ingest/devenv.sh
for variant in detached fullguard; do
    /nix/store/zw57vzaiyww9x37hdjqv7xc2p5r2q1fy-python3-3.13.13-env/bin/python3 "/tmp/mnos-ingest/profile-native-git-rotation-$variant-heap.py"
    /nix/store/zw57vzaiyww9x37hdjqv7xc2p5r2q1fy-python3-3.13.13-env/bin/python3 "/tmp/mnos-ingest/analyze-native-git-rotation-$variant-heap.py" > "/tmp/mnos-ingest/evidence/native-git-rotation-$variant-heap-analysis.log"
    /nix/store/zw57vzaiyww9x37hdjqv7xc2p5r2q1fy-python3-3.13.13-env/bin/python3 "/tmp/mnos-ingest/compare-native-git-rotation-$variant-heap.py" > "/tmp/mnos-ingest/evidence/native-git-rotation-$variant-heap-comparison.log"
done
