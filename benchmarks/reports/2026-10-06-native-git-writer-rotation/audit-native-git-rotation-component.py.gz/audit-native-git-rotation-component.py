"""Re-audit every retained threshold process, operation and paired identity."""
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, '/tmp/mnos-ingest/casita')
from benchmarks import build_manifest
from benchmarks.suites.git_closure_import import summarize_pairs

variant, = sys.argv[1:]
assert variant in ('full', 'detached')
prefix = 'native-git-rotation-' + ('detached-' if variant == 'detached' else '')
root = Path('/tmp/mnos-ingest/evidence')
source = root / (prefix + 'component.json')
report = json.loads(source.read_text())
assert report['complete'] is True
assert len(report['processes']) == 100 and len(report['samples']) == 400
assert report['configuration']['counts'] == [509, 510, 511, 1022, 1023]
assert report['configuration']['byte_budgets'] == [1024, 65536]
assert report['configuration']['repetitions'] == 5
builds = build_manifest.artifacts([(row['variant'], Path(row['path'])) for row in report['artifacts']], fixture=True)
for got, expected in zip(builds, report['artifacts']):
    for key in ('variant', 'path', 'sha256', 'build'):
        assert got[key] == expected[key]
seen = set()
for process in report['processes']:
    assert process['exit_code'] == 0
    assert 'test result: ok. 1 passed; 0 failed;' in process['stdout']
    key = tuple(process[k] for k in ('variant', 'files', 'budget', 'repetition'))
    assert key not in seen
    seen.add(key)
    rows = [json.loads(line[len('git_closure_sample '):]) for raw in process['stdout'].splitlines()
            if (line := raw.removeprefix('test benchmark_git_closure_import ... ')).startswith('git_closure_sample ')]
    assert [row['operation'] for row in rows] == ['cold','warm','subtree-delta','wide-delta']
    for row in rows:
        count = process['files']
        expected = {'cold': (count+2,0), 'warm': (0,1), 'subtree-delta': (2,1), 'wide-delta': (2,count)}
        assert (row['imported_objects'],row['reused_objects']) == expected[row['operation']]
        assert row['correctness'] == 'exact imported/reused counts and exhaustive closure verification'
        assert row['blob_witnesses'] == 0
        assert row['wall_nanos'] > 0
        if row['operation'] == 'warm':
            assert row['source_bytes'] == 0
        matching = [s for s in report['samples'] if (s['variant'],s['files'],s['max_buffered_bytes'],s['repetition']) == key and s['operation'] == row['operation']]
        sample, = matching
        assert all(sample[k] == v for k,v in row.items())
summary = summarize_pairs(report['samples'])
assert summary == report['paired_summary']
assert len(summary) == 40 and all(row['pairs'] == 5 for row in summary)
result = dict(source=source.name, sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
              processes_checked=100, operations_checked=400, paired_groups=40, pairs_per_group=5,
              all_operations=summary,
              limitations=['Process RSS includes fixture creation and correctness auditing.',
                           'Wide parents add dependency pins independent of publication count.',
                           'Threshold timing checks do not establish native ingestion throughput or fixed global memory bounds.'])
out = root / (prefix + 'component-audit.json')
assert not out.exists()
out.write_text(json.dumps(result,indent=2)+'\n')
print('Verified',source.name,'100 processes, 400 operations, 40 paired groups.')
for row in summary:
    if row['operation'] == 'cold':
        print(row['files'],row['max_buffered_bytes'],round(row['median_paired_reduction_percent'],3))
