"""Live system-allocator stacks for fresh Git ingestion; not a timing comparison."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import threading
import time

sys.path.insert(0, '/tmp/mnos-ingest/casita')
from benchmarks import build_manifest

evidence = pathlib.Path('/tmp/mnos-ingest/evidence')
prefix = evidence / 'git-publication-rotation-heap'
assert not list(evidence.glob(prefix.name + '*')), 'refuse to overwrite evidence'
valgrind = pathlib.Path('/nix/store/hypbg1gkdazj1hndj7qgf1rlab9x88qm-valgrind-3.27.1/bin')
binary = evidence / 'import-git-publication-rotation'
build = build_manifest.artifacts([('profiled', binary)], fixture=True)[0]
scenarios = json.loads((evidence / 'ingestion-scenarios.json').read_text())
revision = scenarios['cases']['release']['from']['commit']
references = json.loads(pathlib.Path('/tmp/mnos-ingest/mnos-nix-xp/docs/reports/evidence/git-ingestion/2026-10-06-wider-updates.json').read_text())['identities']
expected = references[revision]
module = pathlib.Path('/tmp/mnos-ingest/gc-build/mnos-nix-xp/evaluator/crates/mnos-eval-cas/src/git/mod.rs')
current_module = pathlib.Path('/tmp/mnos-ingest/mnos-nix-xp/evaluator/crates/mnos-eval-cas/src/git/mod.rs')
assert module.read_bytes() == current_module.read_bytes()
api = pathlib.Path('/tmp/mnos-ingest/casita/crates/casita/src/repository/mutation.rs')
assert api.read_bytes() == (evidence / 'git-publication-rotation-casita-mutation.rs').read_bytes()
shutil.copy2(api, str(prefix) + '-casita-mutation.rs')
shutil.copy2(__file__, str(prefix) + '-runner.py')
shutil.copy2(module, str(prefix) + '-git.rs')
command = [str(valgrind / 'valgrind'), '--tool=massif', '--time-unit=ms', '--depth=48',
           '--max-snapshots=200', '--detailed-freq=1', '--threshold=0.5', '--peak-inaccuracy=0.5',
           '--massif-out-file=' + str(prefix) + '.massif', '--log-file=' + str(prefix) + '-valgrind.log',
           str(binary), '--ignored', '--nocapture', '--exact', 'import_large_git_tree']
env = dict(os.environ, MNOS_BENCH_DIR=str(prefix) + '-cas',
           MNOS_BENCH_REPO=scenarios['repository'], MNOS_BENCH_REV=revision,
           MNOS_BENCH_RETAIN_PREVIOUS='0')
env.pop('MNOS_BENCH_REV2', None)
report = dict(complete=False, scope='Live heap allocation stacks for one fresh Git ingestion.',
              command=command, build=build, expected_identity=expected,
              module_sha256=hashlib.sha256(module.read_bytes()).hexdigest(),
              allocator='system', tool=subprocess.check_output([str(valgrind / 'valgrind'), '--version'], text=True).strip(),
              protocol=dict(ordinary_advisory_collection='Deferred after first pressure marker by moving only the disposable-store stamp 24 hours ahead; emergency collection unchanged.',
                            reason='Profiler slowdown would otherwise introduce repeated wall-clock-triggered collections absent from native fresh ingestion.',
                            time_alignment='Parent receipt times annotate stages approximately; profiler timestamps and parent timestamps have different startup origins.',
                            concurrent_owned_builds_tests_or_benchmarks=False),
              notes=['Instrumentation elapsed time and RSS are not throughput or production memory comparisons.',
                     'System-allocator live blocks exclude untracked mappings, allocator retention and thread stacks; this is not browser mimalloc.',
                     'This diagnostic defers advisory pressure collection and cannot establish ordinary-collection performance.'],
              stage_events=[], pressure_deferral=None)
report_path = pathlib.Path(str(prefix) + '-summary.json')
def save():
    report_path.write_text(json.dumps(report, indent=2) + '\n')
save()
started = time.monotonic()
ended = threading.Event()
try:
    with pathlib.Path(str(prefix) + '.log').open('x') as log:
        child = subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        report['pid'] = child.pid
        report['started_unix_seconds'] = time.time()
        save()
        def defer():
            stamp = pathlib.Path(env['MNOS_BENCH_DIR']) / f'cas-{child.pid}' / '.casita-pressure-collection'
            while not ended.wait(.01):
                try:
                    before = stamp.stat().st_mtime_ns
                except FileNotFoundError:
                    continue
                after = time.time_ns() + 86400 * 1_000_000_000
                os.utime(stamp, ns=(after, after))
                report['pressure_deferral'] = dict(path=str(stamp), before_ns=before, after_ns=after,
                                                   elapsed_seconds=time.monotonic()-started)
                return
        observer = threading.Thread(target=defer)
        observer.start()
        print('Profiling fresh Git revision', revision, 'pid', child.pid, flush=True)
        try:
            for line in child.stdout:
                log.write(line)
                log.flush()
                line = line.removeprefix('test import_large_git_tree ... ')
                for kind in ('git_ingest_start', 'git_ingest_sample', 'git_ingest_identity'):
                    if line.startswith(kind + ' '):
                        value = json.loads(line[len(kind) + 1:])
                        report['stage_events'].append(dict(kind=kind, parent_elapsed_seconds=time.monotonic()-started, value=value))
                        save()
                        print(kind, value.get('stage', value.get('revision')), flush=True)
            code = child.wait()
        finally:
            ended.set()
            observer.join()
    report['exit_code'] = code
    report['instrumented_elapsed_seconds'] = time.monotonic()-started
    save()
    assert code == 0
    assert 'test result: ok. 1 passed;' in pathlib.Path(str(prefix) + '.log').read_text()
    identities = [e['value'] for e in report['stage_events'] if e['kind'] == 'git_ingest_identity']
    assert len(identities) == 1
    assert all(identities[0][k] == expected[k] for k in ('revision', 'git_tree', 'root', 'nar_hash', 'nar_bytes'))
    stages = [e['value'] for e in report['stage_events'] if e['kind'] == 'git_ingest_sample']
    assert [(s['revision'], s['stage']) for s in stages] == [(revision, s) for s in ('import_git', 'git_tree', 'nar')]
    assert report['pressure_deferral'] is not None
    massif = pathlib.Path(str(prefix) + '.massif')
    snapshots = []
    for section in massif.read_text().split('snapshot=')[1:]:
        fields = dict(snapshot=int(section.splitlines()[0]))
        for line in section.splitlines():
            if '=' in line:
                key, value = line.split('=', 1)
                if key in ('time', 'mem_heap_B', 'mem_heap_extra_B', 'mem_stacks_B'):
                    fields[key] = int(value)
                elif key == 'heap_tree':
                    fields[key] = value
        snapshots.append(fields)
    assert snapshots
    report['snapshots'] = snapshots
    report['peak'] = max(snapshots, key=lambda s: s['mem_heap_B'] + s['mem_heap_extra_B'] + s['mem_stacks_B'])
    report['massif_sha256'] = hashlib.sha256(massif.read_bytes()).hexdigest()
    with pathlib.Path(str(prefix) + '.txt').open('x') as output:
        subprocess.run([str(valgrind / 'ms_print'), '--threshold=0.5', str(massif)], stdout=output, check=True)
    report['complete'] = True
    print('Complete; peak live allocator snapshot:', report['peak'], flush=True)
except Exception as error:
    report['error'] = str(error)
    raise
finally:
    ended.set()
    save()
