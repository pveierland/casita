import json, os, pathlib, shutil, subprocess, sys
sys.path.insert(0, '/tmp/mnos-ingest/casita')
from benchmarks import build_manifest
kind, variant = sys.argv[1:]
p = pathlib.Path('/tmp/mnos-ingest/evidence')
casita = pathlib.Path('/tmp/mnos-ingest/casita')
mnos = pathlib.Path('/tmp/mnos-ingest/gc-build/mnos-nix-xp/evaluator')
root = casita if kind == 'casita' else mnos
prefix = 'native-git-rotation-' + ('' if kind == 'casita' else 'mnos-') + variant
name = 'git_closure_import' if kind == 'casita' else 'import_cost'
fixture = ('crates/casita/tests/git_closure_import.rs' if kind == 'casita' else 'crates/mnos-eval-cas/tests/import_cost.rs')
messages = [json.loads(l) for l in (p / (prefix + '-build.jsonl')).read_text().splitlines() if l.startswith('{')]
assert any(m.get('reason') == 'build-finished' and m['success'] for m in messages)
binary = next(m['executable'] for m in reversed(messages) if m.get('executable') and m.get('target', {}).get('name') == name)
out = p / (prefix + '-probe')
assert not out.exists(), out
shutil.copy2(binary, out)
command = ['cargo', 'test', '--release', '-p', 'casita', '--no-default-features', '--features', 'native,git,experimental'] if kind == 'casita' else ['cargo', 'test', '--release', '-p', 'mnos-eval-cas']
command += ['--test', name, '--no-run', '--message-format=json']
build = build_manifest.write(root, out, command, fixture=root / fixture)
revision, source = build_manifest.source_identity(casita, dict(os.environ))
build.update(casita_source_revision=revision, casita_source_sha256=source)
build_manifest.manifest_path(out).write_text(json.dumps(build, indent=2)+'\n')
for suffix, relative in [('engine.rs', 'crates/casita/src/git/repository/closure_import.rs'), ('adapter.rs', 'crates/casita/src/importers/git_closure.rs')]:
    shutil.copy2(casita / relative, p / (prefix + '-' + suffix))
print(out, build['rustflags_source'], build['sha256'] if 'sha256' in build else 'manifest written')
