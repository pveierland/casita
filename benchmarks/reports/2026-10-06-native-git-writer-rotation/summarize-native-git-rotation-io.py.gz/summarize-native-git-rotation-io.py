"""Add write-amplification evidence to an already completed native audit."""
import json, pathlib, statistics, sys
p = pathlib.Path('/tmp/mnos-ingest/evidence')
case = sys.argv[1]
assert case in ('near', 'week', 'release')
name = f'native-git-rotation-wide-{case}'
raw = json.loads((p / (name + '.json')).read_text())
audit = json.loads((p / (name + '-audit.json')).read_text())
assert raw['complete'] and audit['complete_runs'] == len(raw['samples']) == 8
for sample in raw['samples']:
    values = [stage['resources']['write_bytes'] for stage in sample['stages']]
    assert all(type(value) is int and value >= 0 for value in values)
    assert values == sorted(values)
for variant in ('control', 'candidate'):
    selected = [sample for sample in raw['samples'] if sample['variant'] == variant]
    metrics = audit['medians'][variant]
    metrics['process_output_bytes'] = statistics.median(sample['process']['output_blocks'] * 512 for sample in selected)
    metrics['final_process_write_bytes'] = statistics.median(sample['stages'][-1]['resources']['write_bytes'] for sample in selected)
    for phase, offset in [('fresh', 0), ('update', 3)]:
        metrics[f'{phase}_import_write_bytes'] = statistics.median(
            sample['stages'][offset]['resources']['write_bytes'] -
            (sample['stages'][offset - 1]['resources']['write_bytes'] if offset else 0)
            for sample in selected)
        metrics[f'{phase}_conversion_write_bytes'] = statistics.median(
            sample['stages'][offset + 1]['resources']['write_bytes'] - sample['stages'][offset]['resources']['write_bytes']
            for sample in selected)
for key, value in audit['medians']['control'].items():
    if isinstance(value, (int, float)) and value:
        audit['change_percent'][key] = (audit['medians']['candidate'][key] / value - 1) * 100
for pair in audit['pairs']:
    samples = {sample['variant']: sample for sample in raw['samples'] if sample['trial'] == pair['trial']}
    pair['write_bytes_change_percent'] = (samples['candidate']['stages'][-1]['resources']['write_bytes'] /
                                        samples['control']['stages'][-1]['resources']['write_bytes'] - 1) * 100
    pair['observed_peak_wal_change_percent'] = (samples['candidate']['observed_peak_wal_bytes'] /
                                             samples['control']['observed_peak_wal_bytes'] - 1) * 100
audit['limitations'].append('Process write_bytes is cumulative; Conversion deltas subtract the immediately preceding import-stage counter. Update import deltas subtract the preceding NAR-stage counter; fresh import writes include process/repository startup. rusage output_blocks is also retained independently.')
out = p / (name + '-audit-io.json')
assert not out.exists()
out.write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit['change_percent'], indent=2))
