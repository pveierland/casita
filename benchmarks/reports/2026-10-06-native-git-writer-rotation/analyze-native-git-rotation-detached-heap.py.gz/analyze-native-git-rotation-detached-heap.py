"""Audit Massif trees and summarize non-overlapping allocation-stack categories."""
import hashlib
import json
import pathlib
import re

root = pathlib.Path('/tmp/mnos-ingest/evidence')
path = root / 'native-git-rotation-detached-heap.massif'
profile = json.loads((root / 'native-git-rotation-detached-heap-summary.json').read_text())
assert profile['complete'] and profile['exit_code'] == 0
assert hashlib.sha256(path.read_bytes()).hexdigest() == profile['massif_sha256']
patterns = {
    'converted_directory_nodes_and_vectors': ['mnos_eval_cas::git::Converter'],
    'pin_resource_btree_nodes': ['LeafNode<casita::metadata::pins::PinResource', 'InternalNode<casita::metadata::pins::PinResource'],
    'pin_codec_buffers': ['casita::metadata::pins::codec::Encoder'],
    'payload_fetch_cache': ['casita::blob::pack::fetch::Cache'],
    'turso_temporary_buffers': ['turso_core::io::TempBufferCache'],
    'zstd_contexts': ['ZSTD_customMalloc'],
    'git_loader_typed_allocations': ['mnos_eval_cas::git::Entry', 'mnos_eval_cas::git::BlobPayload', 'mnos_eval_cas::ingest::GitOid'],
    'pack_location_indexes': ['RawTable<(casita::digest::ChunkId, casita::blob::pack::Location)>'],
}
rows = []
for section in path.read_text().split('snapshot=')[1:]:
    lines = section.splitlines()
    row = {'snapshot': int(lines[0])}
    nodes = []
    stack = []
    for line in lines:
        found = re.fullmatch(r'(time|mem_heap_B|mem_heap_extra_B|mem_stacks_B)=(\d+)', line)
        if found:
            row[found[1]] = int(found[2])
        if line.startswith('heap_tree='):
            row['heap_tree'] = line.split('=', 1)[1]
        match = re.fullmatch(r'( *)n(\d+): (\d+)(?: (.*))?', line)
        if match:
            depth = len(match[1])
            while len(stack) > depth:
                stack.pop()
            assert len(stack) == depth
            node = dict(count=int(match[2]), bytes=int(match[3]), frame=match[4] or '', children=[])
            if stack:
                stack[-1]['children'].append(node)
            else:
                assert not nodes
                nodes.append(node)
            stack.append(node)
    if not nodes:
        assert row['heap_tree'] == 'empty'
        rows.append(row)
        continue
    assert nodes[0]['bytes'] == row['mem_heap_B']
    totals = dict.fromkeys(patterns, 0)
    totals['other_or_unresolved'] = 0
    def walk(node, selected=None):
        assert node['count'] == len(node['children'])
        matches = [name for name, values in patterns.items() if any(v in node['frame'] for v in values)]
        if selected is None and matches:
            assert len(matches) == 1, matches
            selected = matches[0]
        if node['children']:
            assert sum(c['bytes'] for c in node['children']) == node['bytes']
            for child in node['children']:
                walk(child, selected)
        else:
            totals[selected or 'other_or_unresolved'] += node['bytes']
    walk(nodes[0])
    assert sum(totals.values()) == row['mem_heap_B']
    row['stack_category_bytes'] = totals
    rows.append(row)
assert len(rows) == profile['snapshots'].__len__()
maxima = {name: max((r for r in rows if 'stack_category_bytes' in r), key=lambda r: r['stack_category_bytes'][name]) for name in patterns}
output = root / 'native-git-rotation-detached-heap-analysis.json'
assert not output.exists()
result = dict(source=str(path), sha256=profile['massif_sha256'], patterns=patterns,
              interpretation='Leaf allocation bytes partitioned by first matching allocation-to-caller stack frame. Recursive caller frames are counted once; these are stack categories, not exact object ownership or all allocations of a subsystem.',
              limits=['Frames hidden by the 0.5% threshold or stack depth remain unresolved.',
                      'Git loader typed allocations omit parser allocations with other types and are a lower bound.',
                      'Parent stage receipt times and profiler timestamps do not share an exact startup origin.',
                      'Diagnostic advisory collection deferral; no throughput or RSS claim.'],
              snapshots=rows,
              category_maxima={name: dict(snapshot=row['snapshot'], time_ms=row['time'], bytes=row['stack_category_bytes'][name]) for name,row in maxima.items()})
output.write_text(json.dumps(result, indent=2) + '\n')
selected = [max(rows, key=lambda row: row['mem_heap_B'])['snapshot'],
            max((row for row in rows if row.get('stack_category_bytes', {}).get('converted_directory_nodes_and_vectors', 0)),
                key=lambda row: row['mem_heap_B'])['snapshot']]
for index in sorted(set(selected)):
    row = next(r for r in rows if r['snapshot'] == index)
    print('Snapshot', index, 'payload heap MiB', round(row['mem_heap_B']/2**20, 2))
    for name,value in row.get('stack_category_bytes',{}).items():
        print(' ',name,round(value/2**20,2))
print('Category maxima', result['category_maxima'])
