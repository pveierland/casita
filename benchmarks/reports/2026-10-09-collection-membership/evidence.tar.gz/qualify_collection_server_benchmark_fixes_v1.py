"""Prove benchmark-only edits preserve the already qualified native executable."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
R=Path('/tmp/mnos-ingest');C=R/'casita';M=R/'mnos-nix-xp';E=R/'evidence'
sys.path.insert(0,str(C));from benchmarks import build_manifest as bm
def sha(p):return bm.digest(p)
def load(p):return json.loads(Path(p).read_text())
def content(p):
 if p.is_symlink():return b'link\0'+os.fsencode(os.readlink(p))
 if p.is_file():return str(p.stat().st_mode&0o111).encode()+b'\0'+p.read_bytes()
 if not p.exists():return b'deleted'
 raise AssertionError(p)
old_path=E/'collection-server-pre-sampler-fix-source-v1.json';old=load(old_path)
build_dir=E/'collection-membership-server-candidate-build-v1';build=load(build_dir/'mnos-eval.build.json');proof=load(build_dir/'result.json')
assert proof['success'] and proof['source_unchanged'] and not any(proof[k] for k in ('errors','forced','remaining','interrupted'))
assert sha(build_dir/'mnos-eval')==proof['executable_sha256']==build['executable_sha256']
assert sha(build_dir/'mnos-eval.build.json')==proof['manifest_sha256']==old['qualified_build_manifest_sha256']
assert old['source_revision']==build['casita_source_revision']=='376cd9be1165bafa8eb946897e6869c198297667'
changed_expected={'benchmarks/suites/_server_ingest_runtime.py','benchmarks/suites/server_ingest.py'}
added_expected={'benchmarks/tests/test_server_ingest_sampling.py','benchmarks/tests/test_server_ingest_paths.py'}
paths=sorted(set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=C).split(b'\0'))-{b''})
current={os.fsdecode(n):hashlib.sha256(content(C/os.fsdecode(n))).hexdigest() for n in paths}
assert current.keys()-old['files'].keys()==added_expected
assert not old['files'].keys()-current.keys()
changed={name for name,h in old['files'].items() if current[name]!=h};assert changed==changed_expected,changed
snapshots=E/'cms2/00-r1-recent-baseline/benchmark-artifacts/driver-sources'
old_state=hashlib.sha256();snapshot_paths=[]
for name,wanted in old['files'].items():
 raw=content(C/name)
 if name in changed:
  snapshot=snapshots/Path(name).name;snapshot_paths.append(snapshot)
  raw=b'0\0'+snapshot.read_bytes()
 assert hashlib.sha256(raw).hexdigest()==wanted,name
 for value in (os.fsencode(name),raw):old_state.update(len(value).to_bytes(8,'little'));old_state.update(value)
assert old_state.hexdigest()==build['casita_source_sha256']
current_revision,current_sha=bm.source_identity(C,os.environ)
assert current_revision=='052bc27a6a41b2baa33f7f9767733e431109e9cd'
assert bm.source_identity(M/'evaluator',os.environ)[1]==build['source_sha256']
# Revalidate the original complete micro/build dependency closure, not just ELF hashes.
protocol=load(build_dir/'protocol.json')
for p,wanted in protocol['input_sha256'].items():assert sha(p)==wanted,p
logs=[E/'collection-server-sampling-tests-red-v1.log',E/'collection-server-sampling-tests-green-v2.log',E/'collection-server-path-tests-red-v1.log',E/'collection-server-path-tests-green-v2.log']
assert 'FAILED (errors=1)' in logs[0].read_text() and 'Ran 8 tests' in logs[1].read_text() and logs[1].read_text().rstrip().endswith('OK')
assert 'FAILED (errors=4)' in logs[2].read_text() and 'Ran 14 tests' in logs[3].read_text() and logs[3].read_text().rstrip().endswith('OK')
inputs={str(p):sha(p) for p in [Path(__file__),old_path,build_dir/'mnos-eval',build_dir/'mnos-eval.build.json',build_dir/'result.json',build_dir/'protocol.json',*snapshot_paths,*logs,*[C/n for n in sorted(changed|added_expected)]]}
report=dict(success=True,scope='Python benchmark corrections only; native ELF retains honest original build provenance',current_revision=current_revision,current_source_sha256=current_sha,build_source_revision=build['casita_source_revision'],build_source_sha256=build['casita_source_sha256'],native_source_unchanged=True,changed_files=sorted(changed),added_files=sorted(added_expected),files=current,input_sha256=inputs,completed_unix=time.time(),review='Independent PM review accepted both scoped fixes; 14 focused tests pass. Original PID91905 state remains unknown; real zombie-race reproduction is direct evidence for sampler bug, not retrospective proof.')
with (E/'collection-server-benchmark-fix-qualification-v1.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('files','input_sha256')}))
