"""Bind one successful inventory build to its unchanged sources and native inputs."""
import json,os,sys
from pathlib import Path

R=Path('/tmp/mnos-ingest');C=R/'casita';M=R/'mnos-nix-xp';E=R/'evidence'
sys.path.insert(0,str(C))
from benchmarks import build_manifest as bm

directory=Path(sys.argv[1]).resolve(strict=True)
assert directory.parent==E
proof=json.loads((directory/'result.json').read_text())
protocol=json.loads((directory/'protocol.json').read_text())
assert proof['success'] and proof['source_unchanged'] and not proof['errors'] and not proof['interrupted']
assert not proof['cleanup']['forced'] and not proof['cleanup']['remaining']
binary=Path(proof['artifact']['path']);cached=Path(proof['artifact']['build_path'])
assert binary.parent==directory and bm.digest(binary)==proof['artifact']['sha256']==bm.digest(cached)
assert (binary.stat().st_dev,binary.stat().st_ino)!=(cached.stat().st_dev,cached.stat().st_ino)
assert binary.stat().st_nlink==1
manifest_path=bm.manifest_path(binary);output=directory/'manifest-proof-v1.json'
assert not manifest_path.exists() and not output.exists()
env=dict(os.environ);env.update(protocol['build_environment'])
assert [list(bm.source_identity(p,env)) for p in (M/'evaluator',C)]==protocol['sources']
assert all(bm.digest(p)==wanted for p,wanted in protocol['input_sha256'].items())
reference_path=E/'tcp-cancellation-reference.json'
reference=json.loads(reference_path.read_text())
for name,value in reference['libraries'].items():
 assert Path(env['MNOS_EVAL_'+name+'_LIBRARY'])==Path(value['build_path'])
 assert bm.digest(value['build_path'])==bm.digest(value['path'])==value['sha256']
manifest=bm.write(C,binary,protocol['command'],environment=env,
                  fixture=Path('crates/casita/src/repository/collection_inventory_tests.rs'))
manifest.update(reference_libraries=reference['libraries'],native_libraries_verified_after_build=True)
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
record=dict(manifest_path=str(manifest_path),manifest_sha256=bm.digest(manifest_path),
            build_proof_sha256=bm.digest(directory/'result.json'),source_matches_build=True,
            independent_inode=True,input_sha256={str(p):bm.digest(p) for p in [Path(__file__),reference_path]})
output.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
