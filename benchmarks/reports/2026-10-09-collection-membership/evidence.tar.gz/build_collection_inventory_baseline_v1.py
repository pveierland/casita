"""Freeze the unchanged collection algorithm with the permanent full inventory fixture."""
import hashlib,json,os,signal,subprocess,sys,time,traceback,shutil
from pathlib import Path
R=Path('/tmp/mnos-ingest');C=R/'casita';M=R/'mnos-nix-xp';E=R/'evidence'
sys.path.insert(0,str(C))
from benchmarks import build_manifest as bm
from benchmarks.suites._server_ingest_process import OwnedFamily,identity
OUT=E/'collection-inventory-baseline-build-v1';OUT.mkdir()
command=['cargo','test','--locked','--offline','--release','-j2','-p','casita','--no-default-features','--features','native,git,experimental,cli','--lib','--no-run','--message-format=json']
env=dict(os.environ);env.update(CARGO_TARGET_DIR=str(R/'portable-target'),CARGO_PROFILE_RELEASE_DEBUG='1',CARGO_PROFILE_RELEASE_LTO='off',RUSTFLAGS='-C link-arg=-fuse-ld=mold');roots=[M/'evaluator',C];sources=[bm.source_identity(p,env) for p in roots]
inputs={str(p):bm.digest(p) for p in [Path(__file__),C/'crates/casita/src/spill.rs',C/'crates/casita/src/repository/collection.rs',C/'crates/casita/src/repository/collection_inventory_tests.rs',C/'benchmarks/suites/collection_inventory.py',R/'collection-membership-batch-plan-v1.txt']}
for name in ('spill.rs','repository/collection.rs','repository/collection_inventory_tests.rs'):
 (OUT/Path(name).name).write_bytes((C/'crates/casita/src'/name).read_bytes())
(OUT/'protocol.json').write_text(json.dumps(dict(command=command,cwd=str(C),build_environment={k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_LTO','RUSTFLAGS')},sources=sources,input_sha256=inputs,started_unix=time.time()),indent=2)+'\n')
family=OwnedFamily();stopped=[];samples=[];errors=[];child=None;cleanup=None
for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,lambda s,f:stopped.append(s))
start=time.monotonic()
try:
 with (OUT/'cargo.jsonl').open('x') as out,(OUT/'stderr.log').open('x') as err:
  child=subprocess.Popen(command,cwd=C,env=env,stdout=out,stderr=err,start_new_session=True)
  while child.poll() is None:
   rss=0
   for pid in family.scan():
    try:
     fields=dict(x.split(':',1) for x in Path(f'/proc/{pid}/status').read_text().splitlines());rss+=int(fields.get('VmRSS','0').split()[0])*1024
    except (FileNotFoundError,ProcessLookupError):pass
   fs=os.statvfs(E);available=fs.f_bavail*fs.f_frsize
   samples.append(dict(seconds=time.monotonic()-start,rss_bytes=rss,available_bytes=available))
   assert not stopped and samples[-1]['seconds']<2400 and rss<8*1024**3 and available>=768*1024**2
   time.sleep(1)
except BaseException:errors.append(traceback.format_exc())
finally:
 if child:
  before=[dict(pid=p,identity=identity(p)) for p in family.scan()]
  forced=family.finish(child.poll,lambda:child.poll() is not None)
  cleanup=dict(before=before,forced=forced,remaining=family.members(),adopted=family.reaped)
unchanged=[bm.source_identity(p,env) for p in roots]==sources and all(bm.digest(p)==h for p,h in inputs.items())
messages=[json.loads(x) for x in (OUT/'cargo.jsonl').read_text().splitlines() if x.startswith('{')]
diagnostics=[r['message'] for r in messages if r.get('reason')=='compiler-message' and r['message']['level']=='error']
artifacts=[r for r in messages if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='casita' and r.get('profile',{}).get('test')]
artifact=None
if child and child.returncode==0 and unchanged and not errors and not stopped and len(artifacts)==1:
 source=Path(artifacts[0]['executable']);target=OUT/'casita-test'
 fs=os.statvfs(E)
 if fs.f_bavail*fs.f_frsize-source.stat().st_size<768*1024**2:
  errors.append('insufficient disk reserve to freeze executable')
 else:
  shutil.copy2(source,target)
  assert bm.digest(target)==bm.digest(source)
  artifact=dict(path=str(target),build_path=str(source),sha256=bm.digest(target),bytes=target.stat().st_size)
record=dict(success=bool(child and child.returncode==0 and artifact and unchanged and not errors and not stopped and cleanup and not cleanup['forced'] and not cleanup['remaining']),
 exit_code=child.returncode if child else None,artifact=artifact,source_unchanged=unchanged,errors=errors,interrupted=stopped,cleanup=cleanup,diagnostics=diagnostics,samples=samples,elapsed_seconds=time.monotonic()-start)
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('samples','diagnostics','cleanup')}),flush=True)
sys.exit(0 if record['success'] else 1)
