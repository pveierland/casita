"""Apply the predeclared paired gates without discarding any scheduled observation."""
import hashlib,json,math,statistics
from pathlib import Path
R=Path('/tmp/mnos-ingest');E=R/'evidence';D=E/'collection-membership-micro-v2'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
protocol=read(D/'protocol.json');result=read(D/'result.json');plan=protocol['plan']
plan_path=R/'collection-membership-qualification-plan-v2.json'
assert plan==read(plan_path)
assert protocol['input_sha256'][str(plan_path)]==sha(plan_path)
assert sha(R/plan['clarification_file'])==plan['clarification_sha256']
assert result['success'] and result['input_unchanged'] and not result['errors'] and not result['interrupted']
assert len(result['runs'])==2*len(plan['micro']['schedule'])==120
inputs={str(p):sha(p) for p in [Path(__file__),D/'protocol.json',D/'result.json']}
for path,wanted in protocol['input_sha256'].items():assert sha(Path(path))==wanted
pairs=[];groups={}
for index,case in enumerate(plan['micro']['schedule']):
 pair=dict(index=index,case=case,observations={})
 for offset,variant in enumerate(case['order']):
  name=f'{index:03d}-{variant}';summary=result['runs'][2*index+offset]
  assert summary['name']==name and summary['success']
  rowpath=D/name/'result.json';row=read(rowpath);path=D/name/'benchmark.json'
  assert row['success'] and row['case']==case and row['pair_index']==index and row['variant']==variant
  assert row['exit_code']==0 and not row['error']
  assert not any(row['cleanup'][k] for k in ('forced','remaining','before','adopted'))
  assert str(path)==row['result']==summary['result']
  assert sha(path)==row['result_sha256']==summary['result_sha256']
  measurement=read(path);assert measurement['complete'] and len(measurement['samples'])==len(measurement['processes'])==1
  sample=measurement['samples'][0]
  assert sample['status']=='ok' and sample['entries']==case['count'] and sample['spill_memory_objects']==case['memory_limit']
  wall=sample['wall_seconds'];rss=sample['max_rss_bytes']
  assert type(wall) in (float,int) and math.isfinite(wall) and wall>0
  assert type(rss) is int and rss>0
  pair['observations'][variant]=dict(wall_seconds=wall,max_rss_bytes=rss,metrics=sample['metrics'])
  for p in (rowpath,path):inputs[str(p)]=sha(p)
 baseline=pair['observations']['baseline'];candidate=pair['observations']['candidate']
 pair['wall_ratio']=candidate['wall_seconds']/baseline['wall_seconds']
 pair['rss_ratio']=candidate['max_rss_bytes']/baseline['max_rss_bytes']
 pairs.append(pair);groups.setdefault((case['count'],case['memory_limit']),[]).append(pair)
assert len(groups)==10
gates=[]
for (count,limit),rows in sorted(groups.items()):
 assert sorted(r['case']['repetition'] for r in rows)==list(range(1,7))
 bw=statistics.median(r['observations']['baseline']['wall_seconds'] for r in rows)
 br=statistics.median(r['observations']['baseline']['max_rss_bytes'] for r in rows)
 wall=statistics.median(r['wall_ratio'] for r in rows);rss=statistics.median(r['rss_ratio'] for r in rows)
 wall_limit=1+max(.05,.001/bw);rss_limit=1+max(.05,8388608/br)
 primary=(count,limit)==(8192,17)
 gates.append(dict(count=count,memory_limit=limit,baseline_median_seconds=bw,
   candidate_median_seconds=statistics.median(r['observations']['candidate']['wall_seconds'] for r in rows),
   baseline_median_rss_bytes=br,median_paired_wall_ratio=wall,median_paired_rss_ratio=rss,
   wall_limit=wall_limit,rss_limit=rss_limit,wall_pass=wall<=wall_limit,rss_pass=rss<=rss_limit,
   primary=primary,primary_pass=wall<=.9 if primary else None))
assert sum(g['primary'] for g in gates)==1
accepted=all(g['wall_pass'] and g['rss_pass'] and (not g['primary'] or g['primary_pass']) for g in gates)
report=dict(qualified=True,qualification_scope="valid complete micro evidence; candidate acceptance is micro_gates_pass",micro_gates_pass=accepted,production_adoption_qualified=False,
 limitation='Microbenchmark only; matched ingestion pressure evidence is still required.',
 gates=gates,pairs=pairs,input_sha256=inputs)
output=E/'collection-membership-micro-analysis-v2.json'
with output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(dict(micro_gates_pass=accepted,gates=gates)),flush=True)
