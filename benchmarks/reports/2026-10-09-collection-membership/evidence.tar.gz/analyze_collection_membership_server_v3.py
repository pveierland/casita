"""Replay all matched pressure trials and apply every predeclared paired gate."""
import collections,hashlib,json,math,statistics
from pathlib import Path
R=Path('/tmp/mnos-ingest');E=R/'evidence';D=E/'cms2'
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(path):return json.loads(Path(path).read_text())
def lines(path):return [json.loads(line) for line in Path(path).read_text().splitlines()]
inputs={str(Path(__file__)):sha(__file__)}
def bind(path):
 inputs[str(path)]=sha(path);return path
protocol=load(bind(D/'protocol.json'));matrix_protocol=protocol;result=load(bind(D/'result.json'))
assert result['success'] and result['input_unchanged'] and not result['interrupted'] and not result['errors']
assert len(result['runs'])==len(protocol['schedule'])==24
for path,wanted in protocol['input_sha256'].items():assert sha(path)==wanted
plan_path=R/'collection-membership-qualification-plan-v2.json'
assert protocol['plan']==load(plan_path)
assert protocol['input_sha256'][str(plan_path)]==sha(plan_path)
assert sha(R/protocol['plan']['clarification_file'])==protocol['plan']['clarification_sha256']
references=load(E/'sustained-server-read-fixtures-v2/fixtures.json')['revisions']
assert str(E/'sustained-server-read-fixtures-v2/fixtures.json') in protocol['input_sha256']
def analyze_case(aggregate,expected,report_path):
    rows=[]
    for case in aggregate['cases']:
        result_path = Path(case['result'])
        assert case['name']=='00-'+expected['mode']
        assert result_path==report_path.with_name(report_path.stem+'-artifacts')/case['name']/'result.json'
        assert sha(result_path) == case['result_sha256']
        result = load(bind(result_path)); run = result_path.parent
        protocol = load(bind(run/'protocol.json'))
        assert aggregate['input_sha256']==protocol['input_sha256']==result['input_sha256']
        for path,wanted in result['input_sha256'].items():assert matrix_protocol['input_sha256'][path]==wanted
        config_path=D/(expected['variant']+'-configuration.json')
        assert result['input_sha256'][str(config_path)]==sha(config_path)
        config=load(config_path);binary=Path(config['server_build'])/'mnos-eval'
        assert result['input_sha256'][str(binary)]==matrix_protocol['builds'][expected['variant']]['executable_sha256']
        manifest=Path(str(binary)+'.build.json')
        assert load(manifest)==matrix_protocol['builds'][expected['variant']]
        assert result['input_sha256'][str(manifest)]==sha(manifest)
        events = lines(bind(run/'events.jsonl'))
        spawn=next(e for e in events if e['event']=='spawn' and e['name']=='server-first')
        assert spawn['command'][0]==str(binary)
        samples = lines(bind(run/'resources.jsonl'))
        assert result['success'] and result['input_unchanged'] and not result['interrupted'] and not result['errors']
        assert not any(result['cleanup'][k] for k in ('forced','remaining','adopted','before'))
        assert [x['exit_code'] for x in result['cleanup']['exits']] == [-15, 0]
        for path, digest in result['input_sha256'].items():
            original = Path(path)
            snapshot = run.parent/'driver-sources'/original.name
            candidate = snapshot if snapshot.exists() else original
            assert sha(candidate) == digest
            bind(candidate)
        verified = [e for e in events if e['event'] == 'import-verified']
        assert [e['index'] for e in verified] == result['completed'] == [0,15,16,31,32,47,48,49]
        overlaps = [e for e in events if e['event'] == 'deferred-read-overlap']
        assert [e['old_index'] for e in overlaps] == [0,15,16,31,32,47,48]
        assert all(e['running_before'] and e['running_after'] and e['new_index']==49 for e in overlaps)
        assert sum(e['event']=='deferred-read' for e in events) == result['read_hash_pairs'] == 28
        target = result['target']; assert target == case['target']
        assert result['mode']==expected['mode'] and result['profile']=='standard'
        submitted=[e for e in events if e['event']=='import-submitted']
        assert [e['index'] for e in submitted]==[0,15,16,31,32,47,48,49]
        for event in submitted:
            assert event['reference']=={k:references[event['index']][k] for k in ('revision','git_tree','nar_hash')}
        for event in events:
            if event['event']=='deferred-read':
                assert event['sha256']==references[event['index']]['reads'][event['path']]['sha256']
        rss=max(s['family_rss_bytes'] for s in samples)
        wal=max((s['files']['casita.sqlite-wal'] or {}).get('bytes',0) for s in samples)
        assert rss==result['sampled_family_rss_max_bytes']>0
        assert wal==result['sampled_physical_wal_max_bytes']>0
        event = next(e for e in events if e['event']=='pressure-target-verified')
        assert all(event[k] == v for k,v in target.items())
        before, after = target['before_stamp'], target['after_stamp']
        assert before['device']==after['device'] and before['inode']==after['inode']
        if result['mode']=='recent':
            assert before==after
        else:
            assert target['started_unix_ns'] < after['mtime_ns'] <= target['finished_unix_ns']
            observed = [e for e in events if e['event']=='pressure-stamp-observed' and e['state'] and e['state']['mtime_ns']==after['mtime_ns']]
            assert observed and all(e['phase']=='target-aged' for e in observed)
        # Replay complete wire pairing independently of the protocol client.
        pending={}; counts=collections.Counter()
        for row in lines(bind(run/'wire.jsonl')):
            if row['direction']=='send':
                msg=row['message']; assert msg['id'] not in pending
                pending[msg['id']]=msg['body']
                body=msg['body']; counts[next(iter(body)) if isinstance(body,dict) else body]+=1
            elif row['direction']=='receive' and 'Response' in row['message']:
                msg=row['message']['Response']; assert msg['id'] in pending
                pending.pop(msg['id'])
                assert not isinstance(msg['body'],dict) or 'Error' not in msg['body']
                if isinstance(msg['body'],dict) and 'Kind' in msg['body']:assert msg['body']=={'Kind':{'kind':'Unforced'}}
        assert not pending and counts['Hello']==1 and counts['Kind']==56
        raw=lines(bind(run/'observer-first.jsonl')); ready=raw[0]
        assert ready['event']=='ready' and raw[-1]==dict(event='closed',samples=len(raw)-2)
        for i, sample in enumerate(raw[1:-1]):
            assert sample['index']==i and all(sample[k]==ready[k] for k in ('owner_pid','owner_start_ticks','device','inode'))
            assert sample['status']=='ok' and sample['sequence']%2==0
            assert sample['backlog_frames']==sample['max_frame']-sample['nbackfills']>=0
        assert len(samples)==result['samples']
        start,end=target['start_sample'],target['end_sample']
        assert start in samples and end in samples
        pid=next(e['pid'] for e in events if e['event']=='spawn' and e['name']=='server-first')
        a=next(x for x in start['members'] if x['pid']==pid)
        b=next(x for x in end['members'] if x['pid']==pid)
        assert a['start_ticks']==b['start_ticks']
        assert start['unix_ns']<=target['started_unix_ns']<=target['finished_unix_ns']<=end['unix_ns']
        assert all(b[k]>=a[k] for k in ('user_ticks','system_ticks'))
        assert b['io']['write_bytes']>=a['io']['write_bytes']
        assert protocol['ticks_per_second']>0
        assert target['filesystem']['total_bytes']>0
        assert (target['filesystem']['total_bytes']-target['filesystem']['free_bytes'])/target['filesystem']['total_bytes']>=.8
        rows.append(dict(mode=result['mode'],wall_seconds=target['elapsed_seconds'],family_rss_bytes=rss,physical_wal_bytes=wal,write_bytes=b['io']['write_bytes']-a['io']['write_bytes'],
            collection_finished_after_start_seconds=(after['mtime_ns']-target['started_unix_ns'])/1e9 if result['mode']=='aged' else None,
            sampled_cpu_seconds=sum(b[k]-a[k] for k in ('user_ticks','system_ticks'))/protocol['ticks_per_second'],
            process_io_delta={k:b['io'][k]-a['io'][k] for k in a['io']},
            sample_enclosure_slack_seconds=[(target['started_unix_ns']-start['unix_ns'])/1e9,(end['unix_ns']-target['finished_unix_ns'])/1e9],
            read_hash_pairs=result['read_hash_pairs'],overlapping_roots=len(overlaps),filesystem=target['filesystem']))
    assert len(rows)==1
    return rows[0]
observations=[]
for index,(summary,case) in enumerate(zip(result['runs'],protocol['schedule'])):
 name=f"{index:02d}-r{case['repetition']}-{case['mode']}-{case['variant']}"
 assert summary['success'] and summary['name']==name and summary['case']==case
 row=load(bind(D/name/'result.json'))
 assert row['success'] and row['exit_code']==0 and not row['error'] and row['case']==case
 assert not any(row['cleanup'][k] for k in ('before','forced','remaining','adopted'))
 path=D/name/'benchmark.json'
 assert str(path)==row['result']==summary['result']
 assert sha(path)==row['result_sha256']==summary['result_sha256']
 aggregate=load(bind(path))
 assert aggregate['success'] and aggregate['complete'] and not aggregate['errors']
 assert aggregate['pressure_case']==case['mode'] and len(aggregate['cases'])==1
 observation=analyze_case(aggregate,case,path)
 observations.append(dict(case=case,metrics=observation))
expected_schedule=[]
for repetition in range(1,7):
 for mode in (['recent','aged'] if repetition%2 else ['aged','recent']):
  for variant in (['baseline','candidate'] if repetition%2 else ['candidate','baseline']):
   expected_schedule.append(dict(repetition=repetition,mode=mode,variant=variant))
assert protocol['schedule']==expected_schedule
metrics=('wall_seconds','sampled_cpu_seconds','family_rss_bytes','physical_wal_bytes','write_bytes')
pairs=[]
for mode in ('recent','aged'):
 for repetition in range(1,7):
  rows=[r for r in observations if r['case']['mode']==mode and r['case']['repetition']==repetition]
  assert len(rows)==2 and {r['case']['variant'] for r in rows}=={'baseline','candidate'}
  variants={r['case']['variant']:r['metrics'] for r in rows};ratios={}
  for metric in metrics:
   a=variants['baseline'][metric];b=variants['candidate'][metric]
   assert isinstance(a,(int,float)) and isinstance(b,(int,float)) and math.isfinite(a) and math.isfinite(b) and a>=0 and b>=0
   ratios[metric]=b/a if a else (1 if b==0 else None)
  pairs.append(dict(mode=mode,repetition=repetition,variants=variants,ratios=ratios))
gates=[]
for mode in ('recent','aged'):
 rows=[r for r in pairs if r['mode']==mode]
 for metric in metrics:
  values=[r['ratios'][metric] for r in rows]
  ratio=statistics.median(values) if all(v is not None for v in values) else None
  limit=.9 if metric=='wall_seconds' and mode=='aged' else (1.1 if metric=='physical_wal_bytes' else 1.05)
  gates.append(dict(mode=mode,metric=metric,median_paired_ratio=ratio,limit=limit,passed=ratio is not None and ratio<=limit,
   baseline_median=statistics.median(r['variants']['baseline'][metric] for r in rows),
   candidate_median=statistics.median(r['variants']['candidate'][metric] for r in rows)))
report=dict(valid_complete_evidence=True,server_gates_pass=all(g['passed'] for g in gates),gates=gates,pairs=pairs,
 input_sha256=inputs,limitations=['CPU uses server utime+stime over enclosing samples and excludes waited-child CPU; process I/O may include reaped children.',
 'RSS is sampled owned-family sum; shared mappings may be counted more than once.',
 'Physical WAL length is sampled by passive filesystem stat, not endpoint size or backlog frames.',
 'No confidence interval claim; all six paired observations are retained.'])
with (E/'collection-membership-server-analysis-v3.json').open('x') as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(dict(server_gates_pass=report['server_gates_pass'],gates=gates)),flush=True)
