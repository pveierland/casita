"""Preserve exact benchmark receipts and source snapshots without copying stores or binaries."""
import gzip, hashlib, io, json, tarfile
from pathlib import Path

R = Path('/tmp/mnos-ingest')
E = R / 'evidence'
OUT = R / 'casita/benchmarks/reports/2026-10-09-collection-membership'
OUT.mkdir(exist_ok=False)
files = set()
for name in ('cms3', 'cms2', 'collection-membership-server-v1',
             'collection-membership-micro-v1', 'collection-membership-micro-v2',
             'collection-inventory-baseline-correctness-v1',
             'collection-inventory-baseline-correctness-v3',
             'collection-inventory-candidate-correctness-v2',
             'collection-inventory-candidate-correctness-v3'):
    root = E / name
    assert root.is_dir(), root
    for path in root.rglob('*'):
        if set(path.relative_to(root).parts) & {'cas', 'config', 'temporary'}:
            continue
        if path.is_file() and not path.is_symlink():
            assert path.stat().st_size < 32 * 1024**2, path
            files.add(path)
for name in ('collection-inventory-baseline-build-v3', 'collection-inventory-candidate-build-v2',
             'sustained-server-default-v2', 'collection-membership-server-candidate-build-v1'):
    for path in (E / name).iterdir():
        if path.is_file() and (path.suffix in ('.json', '.rs') or path.name == 'stderr.log'):
            files.add(path)
for pattern in ('*collection*membership*.py', '*collection*inventory*.py',
                'qualify_collection_server_benchmark_fixes_v1.py',
                'collection-membership-qualification-*.json'):
    files.update(R.glob(pattern))
for name in ('collection-membership-server-analysis-v4.json',
             'collection-membership-micro-analysis-v2.json',
             'collection-server-benchmark-fix-qualification-v1.json',
             'collection-server-pre-sampler-fix-source-v1.json',
             'collection-server-startup-failure-v1.json',
             'collection-inventory-python-final-v1.log',
             'collection-inventory-cli-smoke-final-v1.json',
             'collection-inventory-cli-smoke-final-v1.log'):
    files.add(E / name)
for name in ('collection-server-sampling-tests-red-v1.log',
             'collection-server-sampling-tests-green-v2.log',
             'collection-server-path-tests-red-v1.log',
             'collection-server-path-tests-green-v2.log'):
    files.add(E / name)
assert json.loads((E/'collection-inventory-cli-smoke-final-v1.json').read_text())['complete']
assert json.loads((E/'collection-inventory-candidate-correctness-v3/result.json').read_text())['success']

def digest(data):
    return hashlib.sha256(data).hexdigest()

records = []
archive = OUT / 'evidence.tar.gz'
with archive.open('xb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in sorted(files):
                assert path.is_file() and not path.is_symlink(), path
                data = path.read_bytes()
                relative = str(path.relative_to(R))
                entry = tarfile.TarInfo(relative)
                entry.size = len(data)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(data))
                records.append(dict(path=relative, bytes=len(data), sha256=digest(data)))
manifest = dict(archive='evidence.tar.gz', archive_sha256=digest(archive.read_bytes()),
                artifacts=records, original_root=str(R),
                scope='Exact raw successful and failed benchmark receipts, protocols, build manifests, source snapshots, runners and analyses. CAS stores, executables, SDKs, corpus checkouts and temporary working files remain external; their original input hashes and paths are retained in protocols.')
(OUT/'artifacts.json').write_text(json.dumps(manifest, indent=2)+'\n')
for source, name in (('collection-membership-server-analysis-v4.json', 'server-analysis.json'),
                     ('collection-membership-micro-analysis-v2.json', 'micro-analysis.json')):
    (OUT/name).write_bytes((E/source).read_bytes())
print(json.dumps(dict(files=len(records), raw_bytes=sum(r['bytes'] for r in records),
                      archive_bytes=archive.stat().st_size, archive_sha256=manifest['archive_sha256'])))
