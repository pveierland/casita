"""Run every predeclared matched server pressure case without intervening housekeeping."""
import hashlib,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
R=Path('/tmp/mnos-ingest');C=R/'casita';E=R/'evidence'
sys.path.insert(0,str(C))
from benchmarks import build_manifest as bm
from benchmarks.suites.server_ingest import load_configuration
from benchmarks.suites._server_ingest_process import OwnedFamily,identity

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
def save(p,value):
 with Path(p).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
plan_path=R/'collection-membership-qualification-plan-v2.json';plan=load(plan_path)
assert sha(R/plan['clarification_file'])==plan['clarification_sha256']
micro_path=E/'collection-membership-micro-analysis-v1.json';micro=load(micro_path)
assert micro['qualified'] and micro['micro_gates_pass']
inputs={str(p):sha(p) for p in [Path(__file__),plan_path,R/plan['clarification_file'],micro_path]}
inputs.update(micro['input_sha256'])
mpath=E/'collection-membership-micro-v1/protocol.json'
assert inputs[str(mpath)]==sha(mpath)
inputs.update(load(mpath)['input_sha256'])
assert all(sha(p)==h for p,h in inputs.items())
build_dirs=dict(baseline=E/'sustained-server-default-v2',candidate=E/'collection-membership-server-candidate-build-v1')
builds={}
for variant,directory in build_dirs.items():
 proof=load(directory/'result.json');build=bm.read(directory/'mnos-eval',required=True)
 assert proof['success'] and proof['source_unchanged'] and not proof['interrupted']
 assert not any(proof[k] for k in ('errors','forced','remaining'))
 assert all(row['exit_code']==0 for row in proof['adopted'])
 assert sha(directory/'mnos-eval')==proof['executable_sha256']==build['executable_sha256']
 assert sha(directory/'mnos-eval.build.json')==proof['manifest_sha256']
 for p in [directory/'result.json',directory/'protocol.json',directory/'mnos-eval',directory/'mnos-eval.build.json']:
  inputs[str(p)]=sha(p)
 builds[variant]=build
for field in (*bm.MATCHED_FIELDS,'engine_source_revision','engine_source_sha256','engine_source','reference_libraries','allocator','source_sha256'):
 assert builds['baseline'][field]==builds['candidate'][field],field
assert builds['candidate']['casita_source_sha256']==bm.source_identity(C,os.environ)[1]
assert builds['candidate']['casita_source_sha256']==load(mpath)['variants']['candidate']['build']['source_sha256']
candidate_protocol=load(build_dirs['candidate']/'protocol.json')
for path,wanted in candidate_protocol['input_sha256'].items():
 assert sha(path)==wanted
 assert path not in inputs or inputs[path]==wanted
 inputs[path]=wanted
base_config=load(R/'server-ingest-configuration-v1.json')
inputs[str(R/'server-ingest-configuration-v1.json')]=sha(R/'server-ingest-configuration-v1.json')
schedule=[]
for repetition in range(1,7):
 modes=['recent','aged'] if repetition%2 else ['aged','recent']
 variants=['baseline','candidate'] if repetition%2 else ['candidate','baseline']
 for mode in modes:
  for variant in variants:schedule.append(dict(repetition=repetition,mode=mode,variant=variant))
assert len(schedule)==24 and plan['server']['repetitions']==6 and plan['server']['modes']==['recent','aged']
# Reserve all 24 independent stores plus the registered case's 2GiB launch floor.
fs=os.statvfs(E);reserve=24*350*1024**2+2*1024**3
assert fs.f_bavail*fs.f_frsize>=reserve,'insufficient space for the entire matrix before launch'
OUT=E/'collection-membership-server-v1';OUT.mkdir()
configs={}
for variant in build_dirs:
 config={**base_config,'server_build':str(build_dirs[variant])}
 path=OUT/(variant+'-configuration.json');save(path,config)
 context=load_configuration(path);inputs.update(context['inputs']);configs[variant]=str(path)
python=Path(sys.executable).resolve(strict=True);inputs[str(python)]=sha(python)
env={key:os.environ[key] for key in ('PATH','LD_LIBRARY_PATH') if key in os.environ}
env.update(LANG='C',LC_ALL='C',TZ='UTC',PYTHONHASHSEED='0')
save(OUT/'protocol.json',dict(input_sha256=inputs,plan=plan,schedule=schedule,builds=builds,
 execution_environment=env,initial_reserve_bytes=reserve,started_unix=time.time(),
 scope='matched default production servers; independently prepared stores; all attempts retained'))
stopped=[]
for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,lambda s,f:stopped.append(s))
rows=[];errors=[];start=time.monotonic()
try:
 for index,case in enumerate(schedule):
  assert not stopped
  name=f"{index:02d}-r{case['repetition']}-{case['mode']}-{case['variant']}"
  directory=OUT/name;directory.mkdir();report=directory/'benchmark.json'
  command=[str(python),'-m','benchmarks.suites.server_ingest','--configuration',configs[case['variant']],
    '--mode','pressure','--pressure-case',case['mode'],'--profile','standard','--repetitions','1','--output',str(report)]
  family=OwnedFamily();child=None;failure=None;cleanup=None;case_started=time.monotonic();child_identity=None
  try:
   with (directory/'stdout.log').open('x') as out,(directory/'stderr.log').open('x') as err:
    child=subprocess.Popen(command,cwd=C,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
    child_identity=dict(pid=child.pid,identity=identity(child.pid))
    while child.poll() is None:
     family.scan()
     assert not stopped and time.monotonic()-case_started<2460 and time.monotonic()-start<24*2460
     time.sleep(.25)
  except BaseException:failure=traceback.format_exc()
  finally:
   if child:
    try:
     before=[dict(pid=p,identity=identity(p)) for p in family.scan()]
     forced=family.finish(child.poll,lambda:child.poll() is not None)
     cleanup=dict(before=before,forced=forced,remaining=family.members(),adopted=family.reaped)
    except BaseException:failure=(failure or '')+traceback.format_exc()
  aggregate=None;inner=None
  try:
   aggregate=load(report)
   assert aggregate['success'] and aggregate['complete'] and not aggregate['errors']
   assert aggregate['mode']=='pressure' and aggregate['profile']=='standard'
   assert aggregate['pressure_case']==case['mode'] and aggregate['repetitions']==1 and len(aggregate['cases'])==1
   nested=aggregate['cases'][0];assert nested['name']=='00-'+case['mode'] and nested['success']
   inner_path=report.with_name(report.stem+'-artifacts')/nested['name']/'result.json'
   assert str(inner_path)==nested['result'] and sha(inner_path)==nested['result_sha256']
   inner=load(inner_path)
   assert inner['success'] and inner['input_unchanged'] and not inner['interrupted'] and not inner['errors']
   assert inner['mode']==case['mode'] and inner['profile']=='standard'
   assert not any(inner['cleanup'][k] for k in ('forced','remaining','before','adopted'))
   assert [r['exit_code'] for r in inner['cleanup']['exits']]==[-15,0]
   assert inner['completed']==[0,15,16,31,32,47,48,49] and inner['read_hash_pairs']==28
   assert inner['target']==nested['target'] and inner['target']['index']==49
   for path,wanted in aggregate['input_sha256'].items():assert inputs[path]==wanted==sha(path)
   for path,wanted in inner['input_sha256'].items():assert inputs[path]==wanted==sha(path)
  except BaseException:failure=(failure or '')+traceback.format_exc()
  success=bool(child and child.returncode==0 and not failure and not stopped and cleanup
     and not any(cleanup[k] for k in ('before','forced','remaining','adopted')))
  row=dict(name=name,case=case,command=command,child_identity=child_identity,success=success,
   exit_code=child.returncode if child else None,error=failure,cleanup=cleanup,
   elapsed_seconds=time.monotonic()-case_started,result=str(report),result_sha256=sha(report) if report.exists() else None)
  save(directory/'result.json',row);rows.append(row)
  print(json.dumps(dict(name=name,success=success)),flush=True)
  assert success,name
except BaseException:errors.append(traceback.format_exc())
try:unchanged=all(sha(p)==h for p,h in inputs.items())
except BaseException:unchanged=False;errors.append(traceback.format_exc())
signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
interrupted=bool(stopped or signal.sigpending() & {signal.SIGINT,signal.SIGTERM})
result=dict(success=len(rows)==24 and not errors and unchanged and not interrupted,
 errors=errors,interrupted=interrupted,input_unchanged=unchanged,elapsed_seconds=time.monotonic()-start,
 runs=[dict(name=r['name'],success=r['success'],case=r['case'],result=r['result'],result_sha256=r['result_sha256']) for r in rows])
save(OUT/'result.json',result);print(json.dumps(result),flush=True)
sys.exit(0 if result['success'] else 1)
