"""Build the collection batching candidate with matched production server settings."""
import hashlib,json,os,signal,subprocess,sys,time,traceback,shutil
from pathlib import Path
R=Path('/tmp/mnos-ingest');M=R/'mnos-nix-xp';C=R/'casita';E=R/'evidence'
mode='default'
OUT=E/'collection-membership-server-candidate-build-v1';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(C));from benchmarks import build_manifest as bm
sys.path.insert(0,str(M/'docs/reports/probes/git-ingestion'));from pool_process import OwnedFamily,identity
command=['cargo','build','--locked','--offline','--release','-j2','-p','mnos-eval-server','--bin','mnos-eval','--message-format=json']
if mode=='diagnostic':command+=['--features','diagnostic-allocations']
env=dict(os.environ);roots=[M/'evaluator',C];sources=[bm.source_identity(root,env) for root in roots]
assert sources[0][0]=='d0e5b105640a2fe1a74322db3651ee6af8ecad6b'
assert sources[1][0]=='376cd9be1165bafa8eb946897e6869c198297667'
baseline_dir=E/'sustained-server-default-v2'
baseline=json.loads((baseline_dir/'mnos-eval.build.json').read_text())
baseline_proof=json.loads((baseline_dir/'result.json').read_text())
assert baseline_proof['success'] and baseline_proof['source_unchanged'] and not baseline_proof['interrupted']
assert not baseline_proof['errors'] and not baseline_proof['forced'] and not baseline_proof['remaining']
assert bm.digest(baseline_dir/'mnos-eval.build.json')==baseline_proof['manifest_sha256']
assert bm.digest(baseline_dir/'mnos-eval')==baseline['executable_sha256']==baseline_proof['executable_sha256']
assert sources[0][1]==baseline['source_sha256']
micro=E/'collection-membership-micro-analysis-v2.json'
micro_analysis=json.loads(micro.read_text())
assert micro_analysis['qualified'] and micro_analysis['micro_gates_pass']
closure=dict(micro_analysis['input_sha256'])
micro_protocol_path=E/'collection-membership-micro-v2/protocol.json'
assert str(micro_protocol_path) in closure
assert all(bm.digest(path)==wanted for path,wanted in closure.items())
micro_protocol=json.loads(micro_protocol_path.read_text())
for path,wanted in micro_protocol['input_sha256'].items():
 assert bm.digest(path)==wanted
 assert path not in closure or closure[path]==wanted
 closure[path]=wanted
assert micro_protocol['plan']==json.loads((R/'collection-membership-qualification-plan-v2.json').read_text())
assert bm.digest(R/micro_protocol['plan']['clarification_file'])==micro_protocol['plan']['clarification_sha256']
qualified=E/'collection-inventory-candidate-build-v2'
qualified_manifest=json.loads((qualified/'casita-test.build.json').read_text())
assert sources[1][1]==qualified_manifest['source_sha256']
assert micro_protocol['variants']['candidate']['build']==qualified_manifest
assert str(qualified/'casita-test.build.json') in closure
assert str(E/'collection-inventory-candidate-correctness-v2/result.json') in closure
assert str(E/'collection-inventory-candidate-correctness-v2/protocol.json') in closure
assert json.loads((E/'collection-inventory-candidate-correctness-v2/result.json').read_text())['success']
# The baseline-to-HEAD commit adds only the permanent server benchmark.
assert not subprocess.check_output(['git','diff','--name-only',baseline['casita_source_revision'],'HEAD','--',
                                   'crates','Cargo.toml','Cargo.lock','.cargo'],cwd=C)
changed=set(subprocess.check_output(['git','diff','--name-only','HEAD','--','crates'],cwd=C).decode().splitlines())
assert changed=={'crates/casita/src/repository/collection.rs','crates/casita/src/repository/mod.rs','crates/casita/src/spill.rs'}
for name in ('collection.rs','collection_inventory_tests.rs','collection_inventory_fault_tests.rs'):
 assert bm.digest(C/'crates/casita/src/repository'/name)==bm.digest(qualified/name)
assert bm.digest(C/'crates/casita/src/spill.rs')==bm.digest(qualified/'spill.rs')
(OUT/'casita-tracked.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=C))
metadata_command=['cargo','metadata','--format-version','1','--locked','--offline']
if mode=='diagnostic':metadata_command+=['--features','mnos-eval-server/diagnostic-allocations']
metadata=json.loads(subprocess.check_output(metadata_command,cwd=M/'evaluator',env=env,stdin=subprocess.DEVNULL,timeout=120))
(OUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
engine_source='git+https://github.com/pveierland/turso.git?rev=34e03022ae08d2577903cfb0be734bc674cc14a5#34e03022ae08d2577903cfb0be734bc674cc14a5'
engine_names={'turso','turso_core','turso_ext','turso_macros','turso_parser','turso_sdk_kit','turso_sdk_kit_macros','turso_sync_engine','turso_sync_sdk_kit'}
engine_packages=[p for p in metadata['packages'] if p['name'] in engine_names]
assert {p['name'] for p in engine_packages}==engine_names and len(engine_packages)==9
assert all(p['source']==engine_source for p in engine_packages)
core=next(p for p in engine_packages if p['name']=='turso_core')
engine_root=Path(core['manifest_path']).parent.parent
assert all(Path(p['manifest_path']).is_relative_to(engine_root) for p in engine_packages)
engine_status=subprocess.check_output(['git','status','--porcelain'],cwd=engine_root)
# Cargo's exact empty checkout-completion marker is not engine source.
assert engine_status==b'?? .cargo-ok\n'
marker=engine_root/'.cargo-ok'
assert marker.is_file() and not marker.is_symlink() and marker.read_bytes()==b''
assert not subprocess.check_output(['git','diff','--binary','HEAD'],cwd=engine_root)
engine_identity=bm.source_identity(engine_root,env)
assert engine_identity[0]=='34e03022ae08d2577903cfb0be734bc674cc14a5'
assert (engine_root/'core/storage/wal.rs').read_text().count('checkpoint_threshold: 1000,')==1
roots.append(engine_root);sources.append(engine_identity)
accepted=E/'manifest-probe-production-cli';assert bm.digest(accepted)=='a1f6cb143019c28669e21e697e0696c651ab137402280a706a5434d3b953d4b3'
reference=E/'tcp-cancellation-reference.json';ref=json.loads(reference.read_text())
for name,lib in ref['libraries'].items():
 assert Path(env['MNOS_EVAL_'+name+'_LIBRARY'])==Path(lib['build_path'])
 assert bm.digest(lib['build_path'])==lib['sha256']
for path,expected in ref['input_sha256'].items():assert bm.digest(path)==expected
inputs={str(path):bm.digest(path) for path in [Path(__file__),reference,M/'docs/reports/probes/git-ingestion/pool_process.py',E/'allocation-trace-v16-green/result.json',E/'flight-capture-green-v2/result.json',E/'flight-capture-default-v3/result.json',E/'cache-cancellation-green-v3/result.json',E/'cache-cancellation-green-v3/protocol.json',E/'cache-cancellation-qualified-v1/result.json',C/'benchmarks/build_manifest.py',OUT/'metadata.json',micro,qualified/'result.json',qualified/'casita-test.build.json',baseline_dir/'mnos-eval.build.json',baseline_dir/'result.json',baseline_dir/'mnos-eval',R/'collection-membership-qualification-plan-v2.json']}
inputs.update(closure)
assert json.loads((E/'flight-capture-green-v2/result.json').read_text())['exit_code']==0
assert json.loads((E/'flight-capture-default-v3/result.json').read_text())['exit_code']==0
for path,expected in json.loads((E/'flight-capture-green-v2/protocol.json').read_text())['input_sha256'].items():assert bm.digest(path)==expected
fix=json.loads((E/'cache-cancellation-qualified-v1/result.json').read_text())
assert fix['success'] and set(fix['cases'])=={'cache-cancellation-green-v3','cache-cancellation-integration-v1'}
for path,expected in fix['input_sha256'].items():assert bm.digest(path)==expected
trace=json.loads((E/'allocation-trace-v16-green/result.json').read_text())
assert all(case['build_exit']==0 and case['test_exit']==0 for case in trace['cases'])
for name in ['allocation_profile.rs','import_trace.rs']:assert bm.digest(M/'evaluator/crates/mnos-eval-server/src'/name)==trace['sources'][name]
(OUT/'tracked.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','evaluator'],cwd=M))
for path in ['crates/mnos-eval-server/src/allocation_profile.rs','crates/mnos-eval-io/src/flight/diagnostic.rs','crates/mnos-eval-io/src/flight/diagnostic_tests.rs']:
 (OUT/Path(path).name).write_bytes((M/'evaluator'/path).read_bytes())
def free():
 st=os.statvfs(E);return st.f_bavail*st.f_frsize
assert free()>3*1024**3
protocol=dict(command=command,metadata_command=metadata_command,engine_source=engine_source,engine_packages=engine_packages,source_roots=[str(p) for p in roots],sources=sources,input_sha256=inputs,started_unix=time.time(),timeout_seconds=3600,rss_limit_bytes=8*1024**3,minimum_free_bytes=768*1024**2,guard_policy='After Cargo exit only already-zombie descendants may be reaped; any live descendant, nonzero child exit or forced cleanup fails. No benchmark policy is changed.')
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
family=OwnedFamily();child=None;errors=[];stop=None;forced=False;remaining=[];exit_descendants=[];samples=[];interrupted=False
start=time.monotonic()
def interrupt(sig,frame):
 global interrupted
 interrupted=True
signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
def reap():
 if child is not None:child.poll()
try:
 with (OUT/'cargo.jsonl').open('x') as out,(OUT/'stderr.log').open('x') as err:
  child=subprocess.Popen(command,cwd=M/'evaluator',env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
  next_sample=start
  while child.poll() is None:
   now=time.monotonic()
   if now>=next_sample:
    rss=0
    for pid in family.scan():
     try:
      fields=dict(line.split(':',1) for line in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in line);rss+=int(fields.get('VmRSS','0 kB').split()[0])*1024
     except (FileNotFoundError,ProcessLookupError):pass
    disk=free();samples.append(dict(seconds=now-start,rss_bytes=rss,free_bytes=disk));next_sample=now+1
    if now-start>3600:stop='timeout'
    elif rss>8*1024**3:stop='rss'
    elif disk<768*1024**2:stop='disk'
   if interrupted:stop='interrupted'
   if stop:raise RuntimeError(stop)
   time.sleep(.05)
  exit_descendants=[dict(pid=pid,identity=identity(pid)) for pid in family.scan()]
except BaseException:errors.append(traceback.format_exc())
finally:
 if child is not None:
  try:forced=family.finish(reap,lambda:child.poll() is not None);remaining=family.members()
  except BaseException:errors.append(traceback.format_exc());remaining=family.members()
record=dict(success=False,exit_code=child.returncode if child else None,errors=errors,stop=stop,forced=forced,exit_descendants=exit_descendants,remaining=remaining,adopted=family.reaped,samples=samples,elapsed_seconds=time.monotonic()-start)
try:
 assert child is not None and child.returncode==0 and not any([errors,stop,forced,remaining,interrupted])
 assert all(item['identity'] is None or item['identity'][1]=='Z' for item in exit_descendants)
 assert all(item['exit_code']==0 for item in family.reaped)
 assert [bm.source_identity(root,env) for root in roots]==sources
 assert all(bm.digest(path)==expected for path,expected in inputs.items())
 for lib in ref['libraries'].values():assert bm.digest(lib['build_path'])==lib['sha256']
 assert bm.digest(accepted)=='a1f6cb143019c28669e21e697e0696c651ab137402280a706a5434d3b953d4b3'
 messages=[json.loads(line) for line in (OUT/'cargo.jsonl').read_text().splitlines() if line.startswith('{')]
 assert messages[-1]['reason']=='build-finished' and messages[-1]['success']
 compiled_engine={row['target']['name']:row for row in messages if row.get('reason')=='compiler-artifact' and row['target']['name'] in engine_names}
 assert set(compiled_engine)==engine_names
 assert all(row['package_id']==next(p['id'] for p in engine_packages if p['name']==name) for name,row in compiled_engine.items())
 assert json.loads(subprocess.check_output(metadata_command,cwd=M/'evaluator',env=env,stdin=subprocess.DEVNULL,timeout=120))==metadata
 artifact=next(row for row in reversed(messages) if row.get('executable') and row.get('target',{}).get('name')=='mnos-eval')
 assert free()-Path(artifact['executable']).stat().st_size>=768*1024**2
 binary=OUT/'mnos-eval';shutil.copy2(artifact['executable'],binary)
 assert binary.stat().st_ino!=Path(artifact['executable']).stat().st_ino
 build=bm.write(M/'evaluator',binary,command,environment=env)
 assert build['rustflags_source']=='configuration'
 for field in bm.MATCHED_FIELDS:assert build[field]==baseline[field],('mismatched production setting',field)
 build.update(engine_source_revision=engine_identity[0],engine_source_sha256=engine_identity[1],engine_source=engine_source,resolved_metadata_sha256=bm.digest(OUT/'metadata.json'),casita_source_revision=sources[1][0],casita_source_sha256=sources[1][1],cargo_artifact=artifact,reference_libraries=ref['libraries'],build_protocol_sha256=bm.digest(OUT/'protocol.json'),allocator='Tracked<MiMalloc> allocation-origin diagnostic' if mode=='diagnostic' else 'direct production MiMalloc; startup purge delay100ms')
 for field in ('engine_source_revision','engine_source_sha256','engine_source','reference_libraries','allocator'):
  assert build[field]==baseline[field],('mismatched production dependency',field)
 bm.manifest_path(binary).write_text(json.dumps(build,indent=2)+'\n')
 record.update(success=True,executable=str(binary),executable_sha256=bm.digest(binary),manifest_sha256=bm.digest(bm.manifest_path(binary)),source_unchanged=True)
except BaseException:record['validation_error']=traceback.format_exc()
signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
record['interrupted']=interrupted or bool(signal.sigpending() & {signal.SIGINT,signal.SIGTERM})
if record['interrupted']:record.update(success=False,validation_error='interrupted before final evidence publication')
record['completed_unix_ns']=time.time_ns()
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='samples'}))
raise SystemExit(0 if record['success'] else 1)
