//! Diagnostic lifecycle assertions use real flights and controlled work.
use super::*;
use std::collections::BTreeMap;
use std::sync::mpsc;
use std::time::Duration;
use tracing::field::{Field, Visit};
use tracing_subscriber::Layer;
use tracing_subscriber::layer::{Context, SubscriberExt};

#[derive(Default, Clone, Debug)]
struct Event(BTreeMap<String, String>);
impl Visit for Event {
    fn record_u64(&mut self, field: &Field, value: u64) {
        self.0.insert(field.name().into(), value.to_string());
    }
    fn record_str(&mut self, field: &Field, value: &str) {
        self.0.insert(field.name().into(), value.into());
    }
    fn record_debug(&mut self, field: &Field, value: &dyn std::fmt::Debug) {
        self.0.insert(field.name().into(), format!("{value:?}"));
    }
}
#[derive(Clone)]
struct Capture(
    Arc<Mutex<Vec<Event>>>,
    Option<Arc<dyn Fn(&Event) + Send + Sync>>,
);
impl<S: tracing::Subscriber> Layer<S> for Capture {
    fn on_event(&self, event: &tracing::Event<'_>, _: Context<'_, S>) {
        if event.metadata().target() == "mnos_ingest_flight" {
            let mut value = Event::default();
            event.record(&mut value);
            if let Some(hook) = &self.1 {
                hook(&value);
            }
            self.0.lock().unwrap().push(value);
        }
    }
}
fn captured() -> (tracing::Dispatch, Capture) {
    captured_with_hook(None)
}
fn captured_with_hook(
    hook: Option<Arc<dyn Fn(&Event) + Send + Sync>>,
) -> (tracing::Dispatch, Capture) {
    let capture = Capture(Arc::new(Mutex::new(Vec::new())), hook);
    (
        tracing::Dispatch::new(tracing_subscriber::registry().with(capture.clone())),
        capture,
    )
}
impl Capture {
    fn events(&self) -> Vec<Event> {
        self.0.lock().unwrap().clone()
    }
}

#[test]
fn diagnostic_interest_loss_distinguishes_shared_work_and_final_cancel() {
    let (dispatch, capture) = captured();
    tracing::dispatcher::with_default(&dispatch, || {
        let runtime = IoRuntime::new(&mnos_eval_config::RuntimeConfig::default()).unwrap();
        let flights: Flights<FlightKey, u32> = Flights::new(runtime);
        let (started, running) = mpsc::channel();
        let (release, blocked) = mpsc::channel();
        let first = flights.join_blocking(
            FlightKey::from("shared"),
            FlightOptions::default(),
            move |handle| {
                started.send(handle.cancellation().clone()).unwrap();
                blocked.recv_timeout(Duration::from_secs(5)).unwrap();
                3
            },
        );
        let token = running.recv_timeout(Duration::from_secs(5)).unwrap();
        let second = flights.join_blocking(
            FlightKey::from("shared"),
            FlightOptions::default(),
            |_| unreachable!(),
        );
        drop(first);
        assert!(!token.is_cancelled());
        let shared = capture.events();
        assert!(
            shared
                .iter()
                .any(
                    |event| event.0.get("event").map(String::as_str) == Some("interest_left")
                        && event.0.get("interests").map(String::as_str) == Some("1")
                ),
            "missing shared-interest transition: {shared:?}"
        );
        drop(second);
        assert!(token.is_cancelled());
        let cancelled = capture.events();
        assert!(
            cancelled
                .iter()
                .any(
                    |event| event.0.get("event").map(String::as_str) == Some("cancel_requested")
                        && event.0.get("interests").map(String::as_str) == Some("0")
                ),
            "missing final cancellation: {cancelled:?}"
        );
        assert!(
            !cancelled
                .iter()
                .any(|event| event.0.get("event").map(String::as_str) == Some("work_cleanup"))
        );
        release.send(()).unwrap();
        capture.wait_for(|events| events.iter().any(|event| is(event, "work_cleanup")));
    });
}

impl Capture {
    fn wait_for(&self, predicate: impl Fn(&[Event]) -> bool) -> Vec<Event> {
        let deadline = std::time::Instant::now() + Duration::from_secs(5);
        loop {
            let events = self.events();
            if predicate(&events) {
                return events;
            }
            assert!(
                std::time::Instant::now() < deadline,
                "missing lifecycle events: {events:?}"
            );
            std::thread::sleep(Duration::from_millis(1));
        }
    }
}
fn is(event: &Event, name: &str) -> bool {
    event.0.get("event").map(String::as_str) == Some(name)
}

#[test]
fn diagnostic_interest_identity_survives_worker_return_and_cross_thread_drop() {
    use crate::{IoHub, RequestContext, TenantId};
    let (dispatch, capture) = captured();
    tracing::dispatcher::with_default(&dispatch, || {
        let hub = IoHub::new(&mnos_eval_config::ConcurrencyConfig::default()).unwrap();
        let flights: Flights<FlightKey, u32> = Flights::new(hub.runtime().clone());
        let contexts = [
            (11, WorkClass::Deferred, "deferred"),
            (11, WorkClass::Speculative, "speculative"),
            (22, WorkClass::Interactive, "interactive"),
        ];
        let mut interests = Vec::new();
        for (tenant, class, _) in contexts {
            let flights = flights.clone();
            let (_promotion, urgency) = crate::urgency(WorkClass::Interactive);
            interests.push(
                crate::wait(urgency.scope(hub.imports().run(
                    RequestContext::new(TenantId::from_raw(tenant), class),
                    move || {
                        flights.join(
                            FlightKey::from("identity"),
                            FlightOptions::default(),
                            |_| std::future::pending(),
                        )
                    },
                )))
                .unwrap(),
            );
        }
        // Interest identity outlives its native worker and must not be
        // rediscovered from whichever thread later drops the handle.
        for interest in interests.into_iter().rev() {
            std::thread::spawn(move || drop(interest)).join().unwrap();
        }
        let events =
            capture.wait_for(|events| events.iter().any(|event| is(event, "work_cleanup")));
        let joined: Vec<_> = events
            .iter()
            .filter(|event| is(event, "interest_joined"))
            .collect();
        assert_eq!(joined.len(), contexts.len());
        for (join, (tenant, _, class)) in joined.iter().zip(contexts) {
            assert_eq!(
                join.0.get("interest_id"),
                join.0.get("sequence"),
                "interest identity must be its join sequence"
            );
            assert_eq!(join.0.get("caller_known").map(String::as_str), Some("true"));
            assert_eq!(join.0.get("caller_tenant"), Some(&tenant.to_string()));
            assert_eq!(join.0.get("caller_class").map(String::as_str), Some(class));
            let left = events
                .iter()
                .find(|event| {
                    !is(event, "interest_joined")
                        && event.0.get("interest_id") == join.0.get("interest_id")
                })
                .unwrap();
            for field in ["caller_known", "caller_tenant", "caller_class"] {
                assert_eq!(
                    left.0.get(field),
                    join.0.get(field),
                    "caller changed at drop"
                );
            }
        }
    });
}
fn id(event: &Event) -> u64 {
    event.0["flight_id"].parse().unwrap()
}
fn ordered(events: &[Event], flight: u64) -> Vec<&Event> {
    let mut events: Vec<_> = events.iter().filter(|event| id(event) == flight).collect();
    events.sort_by_key(|event| event.0["sequence"].parse::<u64>().unwrap());
    let mut live = BTreeMap::new();
    for (index, event) in events.iter().enumerate() {
        assert_eq!(event.0["sequence"].parse::<usize>().unwrap(), index + 1);
        assert_eq!(event.0["state_error"], "false");
        assert_eq!(event.0["clock_valid"], "true");
        let interest: u64 = event.0["interest_id"].parse().unwrap();
        let caller = (
            event.0["caller_known"].clone(),
            event.0["caller_tenant"].clone(),
            event.0["caller_class"].clone(),
        );
        if is(event, "interest_joined") {
            assert_eq!(interest, event.0["sequence"].parse::<u64>().unwrap());
            assert!(live.insert(interest, caller).is_none());
        } else if [
            "interest_left",
            "interest_left_retired",
            "threshold_detached",
            "cancel_requested",
        ]
        .iter()
        .any(|name| is(event, name))
        {
            assert_eq!(live.remove(&interest), Some(caller));
        } else {
            assert_eq!(interest, 0);
            assert_eq!(caller, ("false".into(), "0".into(), "none".into()));
        }
        assert_eq!(event.0["interests"].parse::<usize>().unwrap(), live.len());
    }
    events
}

#[test]
fn diagnostic_unknown_interest_origin_is_explicit() {
    let (dispatch, capture) = captured();
    tracing::dispatcher::with_default(&dispatch, || {
        let runtime = IoRuntime::new(&mnos_eval_config::RuntimeConfig::default()).unwrap();
        let flights: Flights<FlightKey, u32> = Flights::new(runtime);
        let interest = flights.join(
            FlightKey::from("unknown"),
            FlightOptions::default(),
            |_| async { 3 },
        );
        assert_eq!(interest.wait(), Ok(3));
        let events = capture.wait_for(|events| {
            events
                .iter()
                .any(|event| is(event, "interest_left_retired"))
        });
        let flight = id(events
            .iter()
            .find(|event| is(event, "interest_joined"))
            .unwrap());
        for event in ordered(&events, flight) {
            assert_eq!(event.0["caller_known"], "false");
            assert_eq!(event.0["caller_tenant"], "0");
            assert_eq!(event.0["caller_class"], "none");
        }
    });
}

#[test]
fn diagnostic_cancel_rejoin_has_distinct_lifetimes_and_cleanup_after_capture_drop() {
    for admitted in [false, true] {
        let (dispatch, capture) = captured();
        tracing::dispatcher::with_default(&dispatch, || {
            let hub = crate::IoHub::new(&mnos_eval_config::ConcurrencyConfig::default()).unwrap();
            let flights: Flights<FlightKey, u32> = Flights::new(hub.runtime().clone());
            let (started, running) = mpsc::channel();
            let (finish, gate) = mpsc::channel();
            let (cleaning, cleanup_started) = mpsc::channel();
            let (release, cleanup_release) = mpsc::channel();
            struct CaptureDrop {
                started: mpsc::Sender<()>,
                release: mpsc::Receiver<()>,
            }
            impl Drop for CaptureDrop {
                fn drop(&mut self) {
                    self.started.send(()).unwrap();
                    self.release.recv_timeout(Duration::from_secs(5)).unwrap();
                }
            }
            let owned = CaptureDrop {
                started: cleaning,
                release: cleanup_release,
            };
            let work = move |handle: FlightHandle| {
                let _owned = owned;
                started.send(handle.cancellation().clone()).unwrap();
                gate.recv_timeout(Duration::from_secs(5)).unwrap();
                3
            };
            let key = FlightKey::from("same-key");
            let first = if admitted {
                flights.join_admitted_blocking(
                    key.clone(),
                    FlightOptions::default(),
                    hub.acquisitions().clone(),
                    move |handle| Some(work(handle)),
                )
            } else {
                flights.join_blocking(key.clone(), FlightOptions::default(), work)
            };
            let token = running.recv_timeout(Duration::from_secs(5)).unwrap();
            drop(first);
            assert!(token.is_cancelled());
            let cancelled = capture.events();
            let old_id = id(cancelled
                .iter()
                .find(|event| is(event, "cancel_requested"))
                .unwrap());
            let next = flights.join(key, FlightOptions::default(), |_| async { 9 });
            assert_eq!(next.wait(), Ok(9));
            finish.send(()).unwrap();
            cleanup_started
                .recv_timeout(Duration::from_secs(5))
                .unwrap();
            assert!(
                !capture
                    .events()
                    .iter()
                    .any(|event| id(event) == old_id && is(event, "work_cleanup"))
            );
            release.send(()).unwrap();
            let events = capture.wait_for(|events| {
                events
                    .iter()
                    .filter(|event| is(event, "work_cleanup"))
                    .count()
                    == 2
            });
            let old = ordered(&events, old_id);
            assert!(is(old.last().unwrap(), "work_cleanup"));
            assert!(old.iter().any(|event| is(event, "outcome_published")));
            let new_id = id(events
                .iter()
                .find(|event| is(event, "interest_joined") && id(event) != old_id)
                .unwrap());
            let new = ordered(&events, new_id);
            assert!(
                new.iter()
                    .any(|event| is(event, "interest_left_retired") && event.0["interests"] == "0")
            );
            assert_eq!(
                new.iter()
                    .filter(|event| is(event, "outcome_published"))
                    .count(),
                1
            );
        });
    }
}

#[test]
fn diagnostic_threshold_detachment_can_be_rejoined_without_cancellation() {
    let (dispatch, capture) = captured();
    tracing::dispatcher::with_default(&dispatch, || {
        let runtime = IoRuntime::new(&mnos_eval_config::RuntimeConfig::default()).unwrap();
        let flights: Flights<FlightKey, u32> = Flights::new(runtime);
        let (started, running) = mpsc::channel();
        let (release, gate) = mpsc::channel();
        let options = FlightOptions {
            finish_threshold: Some(Percent::new(75)),
        };
        let key = FlightKey::from("detached");
        let first = flights.join_blocking(key.clone(), options, move |handle| {
            handle.progress().report(crate::Progress {
                received: mnos_eval_config::ByteSize::new(80),
                expected: Some(mnos_eval_config::ByteSize::new(100)),
            });
            started.send(handle.cancellation().clone()).unwrap();
            gate.recv_timeout(Duration::from_secs(5)).unwrap();
            7
        });
        let token = running.recv_timeout(Duration::from_secs(5)).unwrap();
        drop(first);
        assert!(!token.is_cancelled());
        let second = flights.join_blocking(key, options, |_| unreachable!());
        assert_eq!(second.leadership(), Leadership::Follower);
        release.send(()).unwrap();
        assert_eq!(second.wait(), Ok(7));
        let events =
            capture.wait_for(|events| events.iter().any(|event| is(event, "work_cleanup")));
        let lifetime = ordered(&events, id(&events[0]));
        assert!(
            lifetime
                .iter()
                .any(|event| is(event, "threshold_detached") && event.0["interests"] == "0")
        );
        assert!(!lifetime.iter().any(|event| is(event, "cancel_requested")));
        assert_eq!(
            lifetime
                .iter()
                .filter(|event| is(event, "interest_joined"))
                .count(),
            2
        );
    });
}

#[test]
fn diagnostic_panic_and_never_started_work_have_cleanup_markers() {
    let (dispatch, capture) = captured();
    tracing::dispatcher::with_default(&dispatch, || {
        let runtime = IoRuntime::new(&mnos_eval_config::RuntimeConfig::default()).unwrap();
        let flights: Flights<FlightKey, u32> = Flights::new(runtime);
        let work = flights.join(
            FlightKey::from("panic"),
            FlightOptions::default(),
            |_| async { panic!("controlled worker panic") },
        );
        assert_eq!(work.wait(), Err(FlightAbandoned));
        let events =
            capture.wait_for(|events| events.iter().any(|event| is(event, "work_cleanup")));
        assert!(events.iter().any(|event| is(event, "outcome_abandoned")));
        let state = diagnostic::State::new(diagnostic::Context::capture());
        let unpolled = diagnostic::future(std::future::pending::<()>(), state);
        drop(unpolled);
        let state = diagnostic::State::new(diagnostic::Context::capture());
        let uncalled = diagnostic::blocking(|| panic!("must never execute"), state, "blocking");
        drop(uncalled);
        let events = capture.events();
        assert_eq!(
            events
                .iter()
                .filter(|event| is(event, "work_cleanup") && event.0["started"] == "false")
                .count(),
            2
        );
    });
}

#[test]
fn diagnostic_cleanup_observes_destroyed_captures_including_unpolled_pinned_work() {
    use std::sync::atomic::{AtomicBool, Ordering};
    struct Witness(Arc<AtomicBool>);
    impl Drop for Witness {
        fn drop(&mut self) {
            self.0.store(true, Ordering::SeqCst);
        }
    }
    struct PinnedWork {
        _witness: Witness,
        _pin: std::marker::PhantomPinned,
    }
    impl Future for PinnedWork {
        type Output = ();
        fn poll(
            self: std::pin::Pin<&mut Self>,
            _: &mut std::task::Context<'_>,
        ) -> std::task::Poll<()> {
            std::task::Poll::Ready(())
        }
    }
    for case in ["unpolled", "ready", "uncalled", "returned", "panicked"] {
        let dropped = Arc::new(AtomicBool::new(false));
        let correct = Arc::new(AtomicBool::new(true));
        let hook = {
            let dropped = dropped.clone();
            let correct = correct.clone();
            Arc::new(move |event: &Event| {
                if is(event, "work_cleanup") && !dropped.load(Ordering::SeqCst) {
                    correct.store(false, Ordering::SeqCst);
                }
            }) as Arc<dyn Fn(&Event) + Send + Sync>
        };
        let (dispatch, capture) = captured_with_hook(Some(hook));
        tracing::dispatcher::with_default(&dispatch, || {
            let state = diagnostic::State::new(diagnostic::Context::capture());
            let witness = Witness(dropped.clone());
            match case {
                "unpolled" | "ready" => {
                    let work = PinnedWork {
                        _witness: witness,
                        _pin: std::marker::PhantomPinned,
                    };
                    let mut work = Box::pin(diagnostic::future(work, state));
                    if case == "ready" {
                        let mut cx = std::task::Context::from_waker(std::task::Waker::noop());
                        assert!(work.as_mut().poll(&mut cx).is_ready());
                        assert!(!dropped.load(Ordering::SeqCst));
                        assert!(
                            !capture
                                .events()
                                .iter()
                                .any(|event| is(event, "work_cleanup"))
                        );
                    }
                    drop(work);
                }
                _ => {
                    let work = diagnostic::blocking(
                        move || {
                            let _witness = witness;
                            if case == "panicked" {
                                panic!("controlled wrapped panic");
                            }
                        },
                        state,
                        "blocking",
                    );
                    if case == "uncalled" {
                        drop(work);
                    } else {
                        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(work));
                        assert_eq!(result.is_err(), case == "panicked");
                    }
                }
            }
            assert!(dropped.load(Ordering::SeqCst));
            assert!(
                correct.load(Ordering::SeqCst),
                "cleanup preceded capture destruction in {case}"
            );
            assert_eq!(
                capture
                    .events()
                    .iter()
                    .filter(|event| is(event, "work_cleanup"))
                    .count(),
                1
            );
        });
    }
}

#[test]
fn diagnostic_subscribers_can_inspect_table_without_lock_reentry() {
    let (done, completed) = mpsc::channel();
    let thread = std::thread::spawn(move || {
        let runtime = IoRuntime::new(&mnos_eval_config::RuntimeConfig::default()).unwrap();
        let flights: Flights<FlightKey, u32> = Flights::new(runtime);
        // Weak avoids retaining a live flight through its own subscriber.
        let table = Arc::downgrade(&flights.table);
        let hook = Arc::new(move |_: &Event| {
            if let Some(table) = table.upgrade() {
                // Another thread can briefly own this lock. Blocking acquisition
                // tests same-thread reentry without that false positive.
                drop(table.lock());
            }
        }) as Arc<dyn Fn(&Event) + Send + Sync>;
        let (dispatch, capture) = captured_with_hook(Some(hook));
        tracing::dispatcher::with_default(&dispatch, || {
            let interest = flights.join(
                FlightKey::from("inspect"),
                FlightOptions::default(),
                |_| async { 7 },
            );
            assert_eq!(interest.wait(), Ok(7));
            capture.wait_for(|events| events.iter().any(|event| is(event, "work_cleanup")));
        });
        done.send(()).unwrap();
    });
    completed
        .recv_timeout(Duration::from_secs(5))
        .expect("subscriber reentered a held table lock");
    thread.join().unwrap();
}

#[test]
fn diagnostic_queued_admitted_cancellation_cleans_up_without_starting_work() {
    let (dispatch, capture) = captured();
    tracing::dispatcher::with_default(&dispatch, || {
        let mut config = mnos_eval_config::ConcurrencyConfig::default();
        config.runtime.blocking_threads = mnos_eval_config::ThreadCount::new(1);
        let hub = crate::IoHub::new(&config).unwrap();
        let runtime = hub.runtime();
        let lane = hub.acquisitions().clone();
        let (started, running) = mpsc::channel();
        let (release, gate) = mpsc::channel();
        let occupied = runtime.spawn({
            let lane = lane.clone();
            async move {
                lane.run(crate::RequestContext::default(), move || {
                    started.send(()).unwrap();
                    gate.recv_timeout(Duration::from_secs(5)).unwrap();
                })
                .await
                .unwrap();
            }
        });
        running.recv_timeout(Duration::from_secs(5)).unwrap();
        let flights: Flights<FlightKey, u32> = Flights::new(runtime.clone());
        let interest = flights.join_admitted_blocking(
            FlightKey::from("queued"),
            FlightOptions::default(),
            lane.clone(),
            |_| panic!("cancelled queued work must not execute"),
        );
        let deadline = std::time::Instant::now() + Duration::from_secs(5);
        while crate::workers::testing::queued_classes(&lane).is_empty() {
            assert!(std::time::Instant::now() < deadline);
            std::thread::sleep(Duration::from_millis(1));
        }
        drop(interest);
        let events =
            capture.wait_for(|events| events.iter().any(|event| is(event, "work_cleanup")));
        assert!(events.iter().any(|event| is(event, "outcome_abandoned")));
        assert!(events.iter().any(|event| is(event, "work_cleanup")
            && event.0["started"] == "false"
            && event.0["work_kind"] == "admitted"));
        assert!(!events.iter().any(|event| is(event, "work_started")));
        assert!(crate::workers::testing::queued_classes(&lane).is_empty());
        release.send(()).unwrap();
        runtime.block_on(occupied).unwrap();
    });
}

// Span capture calls into subscribers, not just lifecycle-event delivery.
struct ReentrantSpanSubscriber {
    registry: tracing_subscriber::Registry,
    table: std::sync::Weak<Table<FlightKey, u32>>,
    clone_callback: bool,
    callbacks: Arc<std::sync::atomic::AtomicUsize>,
}
impl ReentrantSpanSubscriber {
    fn inspect(&self) {
        if let Some(table) = self.table.upgrade() {
            drop(table.lock());
            self.callbacks
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        }
    }
}
impl tracing::Subscriber for ReentrantSpanSubscriber {
    fn enabled(&self, metadata: &tracing::Metadata<'_>) -> bool {
        self.registry.enabled(metadata)
    }
    fn new_span(&self, attributes: &tracing::span::Attributes<'_>) -> tracing::span::Id {
        self.registry.new_span(attributes)
    }
    fn record(&self, id: &tracing::span::Id, values: &tracing::span::Record<'_>) {
        self.registry.record(id, values);
    }
    fn record_follows_from(&self, id: &tracing::span::Id, follows: &tracing::span::Id) {
        self.registry.record_follows_from(id, follows);
    }
    fn event(&self, event: &tracing::Event<'_>) {
        self.registry.event(event);
    }
    fn enter(&self, id: &tracing::span::Id) {
        self.registry.enter(id);
    }
    fn exit(&self, id: &tracing::span::Id) {
        self.registry.exit(id);
    }
    fn current_span(&self) -> tracing_core::span::Current {
        if !self.clone_callback {
            self.inspect();
        }
        self.registry.current_span()
    }
    fn clone_span(&self, id: &tracing::span::Id) -> tracing::span::Id {
        if self.clone_callback {
            self.inspect();
        }
        self.registry.clone_span(id)
    }
    fn try_close(&self, id: tracing::span::Id) -> bool {
        self.registry.try_close(id)
    }
}

fn check_span_capture_reentry(path: u8, clone_callback: bool) {
    let (done, completed) = mpsc::channel();
    let thread = std::thread::spawn(move || {
        let hub = crate::IoHub::new(&mnos_eval_config::ConcurrencyConfig::default()).unwrap();
        let flights: Flights<FlightKey, u32> = Flights::new(hub.runtime().clone());
        let callbacks = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let dispatch = tracing::Dispatch::new(ReentrantSpanSubscriber {
            registry: tracing_subscriber::registry(),
            table: Arc::downgrade(&flights.table),
            clone_callback,
            callbacks: callbacks.clone(),
        });
        tracing::dispatcher::with_default(&dispatch, || {
            let span = tracing::info_span!("reentrant_span_capture");
            assert!(!span.is_disabled());
            let _entered = span.enter();
            let (release, gate) = tokio::sync::oneshot::channel();
            let key = FlightKey::from("capture");
            let before = callbacks.load(std::sync::atomic::Ordering::Relaxed);
            let first = match path {
                0 => flights.join(key.clone(), FlightOptions::default(), |_| async move {
                    gate.await.unwrap();
                    7
                }),
                1 => flights.join_blocking(key.clone(), FlightOptions::default(), |_| {
                    gate.blocking_recv().unwrap();
                    7
                }),
                _ => flights.join_admitted_blocking(
                    key.clone(),
                    FlightOptions::default(),
                    hub.acquisitions().clone(),
                    |_| {
                        gate.blocking_recv().unwrap();
                        Some(7)
                    },
                ),
            };
            assert!(callbacks.load(std::sync::atomic::Ordering::Relaxed) > before);
            let before = callbacks.load(std::sync::atomic::Ordering::Relaxed);
            let second = match path {
                0 => flights.join(key, FlightOptions::default(), |_| async { unreachable!() }),
                1 => flights.join_blocking(key, FlightOptions::default(), |_| unreachable!()),
                _ => flights.join_admitted_blocking(
                    key,
                    FlightOptions::default(),
                    hub.acquisitions().clone(),
                    |_| unreachable!(),
                ),
            };
            assert_eq!(second.leadership(), Leadership::Follower);
            assert!(callbacks.load(std::sync::atomic::Ordering::Relaxed) > before);
            release.send(()).unwrap();
            assert_eq!(first.wait(), Ok(7));
            assert_eq!(second.wait(), Ok(7));
        });
        done.send(()).unwrap();
    });
    completed
        .recv_timeout(Duration::from_secs(5))
        .expect("span capture subscriber reentered a held table lock");
    thread.join().unwrap();
}

#[test]
fn diagnostic_span_capture_reentry_async_current() {
    check_span_capture_reentry(0, false);
}
#[test]
fn diagnostic_span_capture_reentry_async_clone() {
    check_span_capture_reentry(0, true);
}
#[test]
fn diagnostic_span_capture_reentry_blocking_current() {
    check_span_capture_reentry(1, false);
}
#[test]
fn diagnostic_span_capture_reentry_blocking_clone() {
    check_span_capture_reentry(1, true);
}
#[test]
fn diagnostic_span_capture_reentry_admitted_current() {
    check_span_capture_reentry(2, false);
}
#[test]
fn diagnostic_span_capture_reentry_admitted_clone() {
    check_span_capture_reentry(2, true);
}
