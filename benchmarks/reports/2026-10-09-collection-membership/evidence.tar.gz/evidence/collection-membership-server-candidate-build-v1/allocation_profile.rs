//! Opt-in diagnostic accounting for Rust allocation origins.
//!
//! Headers are present for the entire lifetime of a diagnostic build. Counters
//! describe requested payload/layout bytes, not allocator usable size or RSS.
//! Snapshots are nontransactional observations of independent atomic fields.
//! Native allocations and direct mappings are not covered. Uninstrumented Rust
//! allocations remain counted in the unattributed bucket.

use std::alloc::{GlobalAlloc, Layout};
use std::cell::{Cell, RefCell};
use std::ptr;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering::Relaxed};

pub const STAGES: [&str; 10] = [
    "unattributed",
    "fetch",
    "add_to_store",
    "get_accessor",
    "archive_unpack",
    "git_import",
    "git_tree",
    "nar",
    "nar_measure",
    "diagnostic",
];
const DEPTH: usize = 64;
static ATTRIBUTION_ERRORS: AtomicU64 = AtomicU64::new(0);

#[derive(Clone, Copy)]
struct Entered {
    id: u64,
    stage: usize,
}

struct Stack {
    entries: [Entered; DEPTH],
    len: usize,
    tainted: bool,
}

impl Stack {
    const fn new() -> Self {
        Self {
            entries: [Entered { id: 0, stage: 0 }; DEPTH],
            len: 0,
            tainted: false,
        }
    }

    fn enter(&mut self, id: u64, stage: usize) -> bool {
        if self.tainted {
            return true;
        }
        if self.len == DEPTH {
            self.tainted = true;
            return false;
        }
        self.entries[self.len] = Entered { id, stage };
        self.len += 1;
        true
    }

    fn exit(&mut self, id: u64) -> bool {
        if self.tainted {
            return true;
        }
        let Some(index) = self.entries[..self.len]
            .iter()
            .rposition(|entry| entry.id == id)
        else {
            self.tainted = true;
            return false;
        };
        self.entries.copy_within(index + 1..self.len, index);
        self.len -= 1;
        true
    }

    fn current(&self) -> usize {
        if self.tainted {
            0
        } else {
            self.entries[..self.len]
                .last()
                .map_or(0, |entry| entry.stage)
        }
    }
}

// Const initialization and no Drop avoid allocator recursion during TLS setup
// and destruction. try_with/try_borrow still handle inaccessible/reentrant TLS.
thread_local! {
    static ENTERED: RefCell<Stack> = const { RefCell::new(Stack::new()) };
    // Separate from the borrowed stack so a failed mutation can invalidate the
    // thread without recursively borrowing the same RefCell.
    static TAINTED: Cell<bool> = const { Cell::new(false) };
}

fn taint_thread() {
    let _ = TAINTED.try_with(|tainted| tainted.set(true));
    ATTRIBUTION_ERRORS.fetch_add(1, Relaxed);
}

pub fn enter_span(id: u64, stage: &str) {
    let category = STAGES
        .iter()
        .position(|candidate| *candidate == stage)
        .unwrap_or(0);
    let ok = ENTERED
        .try_with(|stack| {
            stack
                .try_borrow_mut()
                .is_ok_and(|mut stack| stack.enter(id, category))
        })
        .unwrap_or(false);
    if !ok {
        taint_thread();
    }
}

pub fn exit_span(id: u64) {
    let ok = ENTERED
        .try_with(|stack| stack.try_borrow_mut().is_ok_and(|mut stack| stack.exit(id)))
        .unwrap_or(false);
    if !ok {
        taint_thread();
    }
}

/// Mark collector callbacks without confusing their temporary allocations with
/// the application span they inspect. Registry work outside callbacks may still
/// inherit application attribution. Id zero is reserved for these scopes.
pub struct DiagnosticScope(std::marker::PhantomData<*mut ()>);

impl DiagnosticScope {
    pub fn enter() -> Self {
        enter_span(0, "diagnostic");
        Self(std::marker::PhantomData)
    }
}

impl Drop for DiagnosticScope {
    fn drop(&mut self) {
        exit_span(0);
    }
}

fn current_stage() -> usize {
    if TAINTED.try_with(Cell::get).unwrap_or(true) {
        return 0;
    }
    match ENTERED.try_with(|stack| stack.try_borrow().map(|stack| stack.current()).ok()) {
        Ok(Some(stage)) => stage,
        _ => {
            taint_thread();
            0
        }
    }
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct Counts {
    pub requested_bytes: usize,
    pub layout_bytes: usize,
    pub blocks: usize,
}

#[derive(Debug, Clone, Copy)]
pub struct Snapshot {
    pub stages: [Counts; STAGES.len()],
    pub accounting_error: bool,
    pub attribution_errors: u64,
}

struct Counters {
    requested_bytes: AtomicUsize,
    layout_bytes: AtomicUsize,
    blocks: AtomicUsize,
}

impl Counters {
    const fn new() -> Self {
        Self {
            requested_bytes: AtomicUsize::new(0),
            layout_bytes: AtomicUsize::new(0),
            blocks: AtomicUsize::new(0),
        }
    }

    fn snapshot(&self) -> Counts {
        Counts {
            requested_bytes: self.requested_bytes.load(Relaxed),
            layout_bytes: self.layout_bytes.load(Relaxed),
            blocks: self.blocks.load(Relaxed),
        }
    }
}

pub struct Tracked<A> {
    inner: A,
    counters: [Counters; STAGES.len()],
    accounting_error: AtomicBool,
}

#[repr(C)]
#[derive(Clone, Copy)]
struct Header {
    stage: usize,
}

fn extended(layout: Layout) -> Option<(Layout, usize)> {
    Layout::new::<Header>().extend(layout).ok()
}

impl<A> Tracked<A> {
    pub const fn new(inner: A) -> Self {
        Self {
            inner,
            counters: [const { Counters::new() }; STAGES.len()],
            accounting_error: AtomicBool::new(false),
        }
    }

    pub fn snapshot(&self) -> Snapshot {
        Snapshot {
            stages: std::array::from_fn(|index| self.counters[index].snapshot()),
            accounting_error: self.accounting_error.load(Relaxed),
            attribution_errors: ATTRIBUTION_ERRORS.load(Relaxed),
        }
    }

    fn add(&self, counter: &AtomicUsize, value: usize) {
        if counter
            .fetch_add(value, Relaxed)
            .checked_add(value)
            .is_none()
        {
            self.accounting_error.store(true, Relaxed);
        }
    }

    fn subtract(&self, counter: &AtomicUsize, value: usize) {
        if counter.fetch_sub(value, Relaxed) < value {
            self.accounting_error.store(true, Relaxed);
        }
    }

    fn resize(&self, counter: &AtomicUsize, old: usize, new: usize) {
        if new >= old {
            self.add(counter, new - old);
        } else {
            self.subtract(counter, old - new);
        }
    }
}

impl<A: GlobalAlloc> Tracked<A> {
    unsafe fn allocate(&self, layout: Layout, zeroed: bool) -> *mut u8 {
        let Some((combined, offset)) = extended(layout) else {
            return ptr::null_mut();
        };
        let base = unsafe {
            if zeroed {
                self.inner.alloc_zeroed(combined)
            } else {
                self.inner.alloc(combined)
            }
        };
        if base.is_null() {
            return base;
        }
        let stage = current_stage();
        // stage is produced solely by the private stack and bounded STAGES lookup.
        let counters = unsafe { self.counters.get_unchecked(stage) };
        unsafe {
            base.cast::<Header>().write(Header { stage });
        }
        self.add(&counters.requested_bytes, layout.size());
        self.add(&counters.layout_bytes, combined.size());
        self.add(&counters.blocks, 1);
        unsafe { base.add(offset) }
    }
}

// SAFETY: each payload pointer has a private aligned header preceding it. The
// exact original combined layout is recovered from the caller's original layout.
// All bookkeeping is bounded, nonallocating and never calls application code.
unsafe impl<A: GlobalAlloc> GlobalAlloc for Tracked<A> {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        unsafe { self.allocate(layout, false) }
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        unsafe { self.allocate(layout, true) }
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        // A successfully allocated layout necessarily extended successfully.
        let (combined, offset) = unsafe { extended(layout).unwrap_unchecked() };
        let base = unsafe { ptr.sub(offset) };
        let header = unsafe { base.cast::<Header>().read() };
        let counters = unsafe { self.counters.get_unchecked(header.stage) };
        unsafe {
            self.inner.dealloc(base, combined);
        }
        self.subtract(&counters.requested_bytes, layout.size());
        self.subtract(&counters.layout_bytes, combined.size());
        self.subtract(&counters.blocks, 1);
    }

    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        let Ok(new_layout) = Layout::from_size_align(new_size, layout.align()) else {
            return ptr::null_mut();
        };
        let Some((new_combined, new_offset)) = extended(new_layout) else {
            return ptr::null_mut();
        };
        let (old_combined, offset) = unsafe { extended(layout).unwrap_unchecked() };
        let base = unsafe { ptr.sub(offset) };
        let header = unsafe { base.cast::<Header>().read() };
        let new_base = unsafe { self.inner.realloc(base, old_combined, new_combined.size()) };
        if new_base.is_null() {
            return new_base;
        }
        // Alignment is unchanged, therefore offset is unchanged. The inner
        // realloc preserves the header and min(old_size, new_size) payload bytes.
        let counters = unsafe { self.counters.get_unchecked(header.stage) };
        self.resize(&counters.requested_bytes, layout.size(), new_size);
        self.resize(
            &counters.layout_bytes,
            old_combined.size(),
            new_combined.size(),
        );
        unsafe { new_base.add(new_offset) }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::alloc::System;

    #[test]
    fn accounts_aligned_allocation_and_free() {
        let allocator = Tracked::new(System);
        let layout = Layout::from_size_align(37, 64).unwrap();
        unsafe {
            let ptr = allocator.alloc(layout);
            assert!(!ptr.is_null());
            assert_eq!(ptr.addr() % layout.align(), 0);
            let live = allocator.snapshot();
            allocator.dealloc(ptr, layout);
            assert_eq!(live.stages[0].requested_bytes, 37);
            assert_eq!(live.stages[0].layout_bytes, 101);
            assert_eq!(live.stages[0].blocks, 1);
            assert_eq!(
                allocator.snapshot().stages,
                [Counts::default(); STAGES.len()]
            );
            assert!(!allocator.snapshot().accounting_error);
        }
    }

    #[test]
    fn zeroed_and_reallocated_payloads_preserve_alignment_and_origin() {
        std::thread::spawn(|| {
            let allocator = Tracked::new(System);
            for align in [1, 2, 8, 16, 64, 4096] {
                let original = Layout::from_size_align(37, align).unwrap();
                enter_span(1, "git_tree");
                unsafe {
                    let ptr = allocator.alloc_zeroed(original);
                    assert!(!ptr.is_null());
                    assert_eq!(ptr.addr() % align, 0);
                    assert_eq!(std::slice::from_raw_parts(ptr, 37), &[0; 37]);
                    ptr.write_bytes(0xab, 37);
                    exit_span(1);
                    enter_span(2, "nar");
                    let ptr = allocator.realloc(ptr, original, 8193);
                    assert!(!ptr.is_null());
                    assert_eq!(ptr.addr() % align, 0);
                    assert_eq!(std::slice::from_raw_parts(ptr, 37), &[0xab; 37]);
                    ptr.write_bytes(0xcd, 8193);
                    let grown = Layout::from_size_align(8193, align).unwrap();
                    let ptr = allocator.realloc(ptr, grown, 9);
                    assert!(!ptr.is_null());
                    assert_eq!(ptr.addr() % align, 0);
                    assert_eq!(std::slice::from_raw_parts(ptr, 9), &[0xcd; 9]);
                    let live = allocator.snapshot();
                    assert_eq!(live.stages[6].requested_bytes, 9);
                    assert_eq!(live.stages[6].blocks, 1);
                    assert_eq!(live.stages[7], Counts::default());
                    allocator.dealloc(ptr, Layout::from_size_align(9, align).unwrap());
                    exit_span(2);
                    assert_eq!(
                        allocator.snapshot().stages,
                        [Counts::default(); STAGES.len()]
                    );
                    assert!(!allocator.snapshot().accounting_error);
                }
            }
        })
        .join()
        .unwrap();
    }

    struct Failing {
        fail: AtomicBool,
    }

    unsafe impl GlobalAlloc for Failing {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            if self.fail.load(Relaxed) {
                ptr::null_mut()
            } else {
                unsafe { System.alloc(layout) }
            }
        }

        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            unsafe { System.dealloc(ptr, layout) }
        }

        unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
            if self.fail.load(Relaxed) {
                ptr::null_mut()
            } else {
                unsafe { System.realloc(ptr, layout, size) }
            }
        }
    }

    #[test]
    fn failed_allocations_and_realloc_leave_existing_storage_and_counts_intact() {
        let allocator = Tracked::new(Failing {
            fail: AtomicBool::new(false),
        });
        let layout = Layout::from_size_align(19, 64).unwrap();
        unsafe {
            let ptr = allocator.alloc(layout);
            assert!(!ptr.is_null());
            ptr.write_bytes(0xef, 19);
            let before = allocator.snapshot().stages;
            allocator.inner.fail.store(true, Relaxed);
            assert!(allocator.alloc(layout).is_null());
            assert!(allocator.alloc_zeroed(layout).is_null());
            assert!(allocator.realloc(ptr, layout, 2000).is_null());
            assert_eq!(std::slice::from_raw_parts(ptr, 19), &[0xef; 19]);
            assert_eq!(allocator.snapshot().stages, before);
            allocator.dealloc(ptr, layout);
            assert_eq!(
                allocator.snapshot().stages,
                [Counts::default(); STAGES.len()]
            );
            assert!(!allocator.snapshot().accounting_error);
        }
    }

    #[test]
    fn overflowing_header_layout_is_rejected_before_calling_inner_allocator() {
        struct Never;
        unsafe impl GlobalAlloc for Never {
            unsafe fn alloc(&self, _: Layout) -> *mut u8 {
                panic!("unexpected allocation")
            }
            unsafe fn dealloc(&self, _: *mut u8, _: Layout) {
                panic!("unexpected free")
            }
        }
        let allocator = Tracked::new(Never);
        let huge = Layout::from_size_align(isize::MAX as usize, 1).unwrap();
        unsafe {
            assert!(allocator.alloc(huge).is_null());
            assert!(allocator.alloc_zeroed(huge).is_null());
        }
        assert_eq!(
            allocator.snapshot().stages,
            [Counts::default(); STAGES.len()]
        );
    }

    #[test]
    fn overflowing_reallocation_keeps_original_pointer_usable() {
        let allocator = Tracked::new(System);
        let layout = Layout::from_size_align(19, 1).unwrap();
        unsafe {
            let ptr = allocator.alloc(layout);
            assert!(!ptr.is_null());
            ptr.write_bytes(7, 19);
            let before = allocator.snapshot().stages;
            assert!(
                allocator
                    .realloc(ptr, layout, isize::MAX as usize)
                    .is_null()
            );
            assert_eq!(std::slice::from_raw_parts(ptr, 19), &[7; 19]);
            assert_eq!(allocator.snapshot().stages, before);
            allocator.dealloc(ptr, layout);
        }
    }

    #[test]
    fn free_on_another_thread_charges_creation_stage() {
        struct Allocation(*mut u8);
        // Test transfers exclusive ownership to the freeing thread.
        unsafe impl Send for Allocation {}
        impl Allocation {
            unsafe fn free(self, allocator: &Tracked<System>, layout: Layout) {
                unsafe { allocator.dealloc(self.0, layout) }
            }
        }
        let allocator = std::sync::Arc::new(Tracked::new(System));
        let layout = Layout::from_size_align(71, 256).unwrap();
        let creator = allocator.clone();
        let allocation = std::thread::spawn(move || {
            enter_span(23, "archive_unpack");
            let ptr = unsafe { creator.alloc(layout) };
            assert!(!ptr.is_null());
            exit_span(23);
            Allocation(ptr)
        })
        .join()
        .unwrap();
        assert_eq!(allocator.snapshot().stages[4].requested_bytes, 71);
        let freeing = allocator.clone();
        std::thread::spawn(move || {
            enter_span(24, "nar");
            unsafe {
                allocation.free(&freeing, layout);
            }
            exit_span(24);
        })
        .join()
        .unwrap();
        assert_eq!(
            allocator.snapshot().stages,
            [Counts::default(); STAGES.len()]
        );
        assert!(!allocator.snapshot().accounting_error);
    }

    #[test]
    fn nested_recursive_and_out_of_order_exits_restore_last_remaining_entry() {
        let mut stack = Stack::new();
        assert!(stack.enter(10, 1));
        assert!(stack.enter(20, 2));
        assert!(stack.enter(20, 2));
        assert!(stack.enter(30, 3));
        assert!(stack.exit(20));
        assert_eq!(stack.current(), 3);
        assert!(stack.exit(30));
        assert_eq!(stack.current(), 2);
        assert!(stack.exit(10));
        assert_eq!(stack.current(), 2);
        assert!(stack.exit(20));
        assert_eq!(stack.current(), 0);
    }

    #[test]
    fn overflow_and_unmatched_exit_permanently_disable_attribution() {
        let mut stack = Stack::new();
        for id in 0..DEPTH as u64 {
            assert!(stack.enter(id, 1));
        }
        assert!(!stack.enter(99, 2));
        assert_eq!(stack.current(), 0);
        for id in 0..DEPTH as u64 {
            assert!(stack.exit(id));
        }
        assert!(stack.enter(100, 3));
        assert_eq!(stack.current(), 0);
        let mut stack = Stack::new();
        assert!(stack.enter(1, 1));
        assert!(!stack.exit(2));
        assert_eq!(stack.current(), 0);
        assert!(stack.exit(1));
        assert!(stack.enter(3, 3));
        assert_eq!(stack.current(), 0);
    }

    #[test]
    fn reentrant_span_entry_cannot_leave_stale_attribution() {
        std::thread::spawn(|| {
            enter_span(1, "git_tree");
            ENTERED.with(|stack| {
                let _borrow = stack.borrow_mut();
                enter_span(2, "nar");
                assert_eq!(current_stage(), 0);
            });
            assert_eq!(current_stage(), 0);
            exit_span(2);
            exit_span(1);
        })
        .join()
        .unwrap();
    }

    #[test]
    fn accounting_overflow_and_underflow_are_reported() {
        let allocator = Tracked::new(System);
        let counter = AtomicUsize::new(usize::MAX);
        allocator.add(&counter, 1);
        assert!(allocator.snapshot().accounting_error);
        let allocator = Tracked::new(System);
        allocator.subtract(&counter, 1);
        assert!(allocator.snapshot().accounting_error);
    }

    #[test]
    fn forced_moving_realloc_preserves_header_and_payload() {
        struct Moving;
        unsafe impl GlobalAlloc for Moving {
            unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
                unsafe { System.alloc(layout) }
            }
            unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
                unsafe { System.dealloc(ptr, layout) }
            }
            unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
                let Ok(next) = Layout::from_size_align(size, layout.align()) else {
                    return ptr::null_mut();
                };
                let new = unsafe { System.alloc(next) };
                if !new.is_null() {
                    unsafe {
                        ptr::copy_nonoverlapping(ptr, new, layout.size().min(size));
                        System.dealloc(ptr, layout);
                    }
                }
                new
            }
        }
        std::thread::spawn(|| {
            let allocator = Tracked::new(Moving);
            let layout = Layout::from_size_align(37, 4096).unwrap();
            enter_span(1, "git_tree");
            unsafe {
                let old = allocator.alloc(layout);
                assert!(!old.is_null());
                old.write_bytes(0xab, 37);
                let old_address = old.addr();
                exit_span(1);
                let new = allocator.realloc(old, layout, 9000);
                assert!(!new.is_null());
                assert_ne!(old_address, new.addr());
                assert_eq!(new.addr() % 4096, 0);
                assert_eq!(std::slice::from_raw_parts(new, 37), &[0xab; 37]);
                assert_eq!(allocator.snapshot().stages[6].requested_bytes, 9000);
                allocator.dealloc(new, Layout::from_size_align(9000, 4096).unwrap());
                assert_eq!(
                    allocator.snapshot().stages,
                    [Counts::default(); STAGES.len()]
                );
            }
        })
        .join()
        .unwrap();
    }

    #[test]
    fn allocation_during_a_stack_borrow_is_unattributed_without_recursion() {
        std::thread::spawn(|| {
            let allocator = Tracked::new(System);
            let layout = Layout::from_size_align(37, 64).unwrap();
            enter_span(1, "git_tree");
            ENTERED.with(|stack| {
                let _borrow = stack.borrow_mut();
                unsafe {
                    let ptr = allocator.alloc(layout);
                    assert!(!ptr.is_null());
                    assert_eq!(allocator.snapshot().stages[0].requested_bytes, 37);
                    allocator.dealloc(ptr, layout);
                }
            });
            assert_eq!(current_stage(), 0);
            exit_span(1);
        })
        .join()
        .unwrap();
    }

    #[test]
    fn nested_diagnostic_scopes_restore_application_attribution() {
        std::thread::spawn(|| {
            enter_span(1, "git_tree");
            let outer = DiagnosticScope::enter();
            assert_eq!(current_stage(), 9);
            {
                let _inner = DiagnosticScope::enter();
                assert_eq!(current_stage(), 9);
            }
            assert_eq!(current_stage(), 9);
            drop(outer);
            assert_eq!(current_stage(), 6);
            exit_span(1);
            assert_eq!(current_stage(), 0);
        })
        .join()
        .unwrap();
    }

    #[test]
    fn attribution_remains_usable_during_other_thread_local_destructors() {
        struct AtExit;
        impl Drop for AtExit {
            fn drop(&mut self) {
                // Also exercise the real process global allocator in the
                // diagnostic harness, where it is Tracked<MiMalloc>.
                let payload = std::hint::black_box(Box::new([7u8; 8192]));
                let allocator = Tracked::new(System);
                let layout = Layout::from_size_align(37, 64).unwrap();
                enter_span(2, "nar");
                unsafe {
                    let ptr = allocator.alloc(layout);
                    assert!(!ptr.is_null());
                    assert_eq!(allocator.snapshot().stages[7].requested_bytes, 37);
                    allocator.dealloc(ptr, layout);
                }
                exit_span(2);
                assert_eq!(payload[8191], 7);
            }
        }
        thread_local! { static EXIT: AtExit = const { AtExit }; }
        std::thread::spawn(|| {
            EXIT.with(|_| ());
            enter_span(1, "git_tree");
            exit_span(1);
        })
        .join()
        .unwrap();
    }
}
