//! Diagnostic-only flight transitions and owned-work destruction markers.
//!
//! Capture records under the table lock, emit them after releasing it. Delivery
//! can reorder records; sequence numbers preserve each flight's transition order.
//! Work cleanup means the wrapped future/closure has been destroyed, not that
//! returned values, detached children, runtime storage or native threads are gone.

use std::cell::Cell;
use std::future::Future;
use std::pin::Pin;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::task::{Context as TaskContext, Poll};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

static NEXT_ID: AtomicU64 = AtomicU64::new(1);

thread_local! {
    // Only a synchronous admitted native closure establishes this origin.
    // It is not an async task local or ownership of nested collective work.
    static REQUEST: Cell<Option<crate::RequestContext>> = const { Cell::new(None) };
}

pub(crate) fn with_request<R>(request: crate::RequestContext, work: impl FnOnce() -> R) -> R {
    struct Restore(Option<Option<crate::RequestContext>>);
    impl Drop for Restore {
        fn drop(&mut self) {
            if let Some(previous) = self.0 {
                let _ = REQUEST.try_with(|current| current.set(previous));
            }
        }
    }
    let _restore = Restore(
        REQUEST
            .try_with(|current| current.replace(Some(request)))
            .ok(),
    );
    work()
}

#[cfg(test)]
mod request_tests {
    use super::*;
    use crate::{RequestContext, TenantId};
    use mnos_eval_config::WorkClass;

    #[test]
    fn submitted_request_scope_restores_after_nesting_and_panic() {
        let first = RequestContext::new(TenantId::from_raw(7), WorkClass::Speculative);
        let second = RequestContext::new(TenantId::from_raw(8), WorkClass::Interactive);
        assert_eq!(request(), None);
        with_request(first, || {
            assert_eq!(request(), Some(first));
            with_request(second, || assert_eq!(request(), Some(second)));
            assert_eq!(request(), Some(first));
            let failed = std::panic::catch_unwind(|| with_request(second, || panic!("scope test")));
            assert!(failed.is_err());
            assert_eq!(request(), Some(first));
        });
        assert_eq!(request(), None);
    }

    #[test]
    fn request_origin_does_not_escape_to_uninstrumented_threads() {
        with_request(RequestContext::default(), || {
            assert_eq!(std::thread::spawn(request).join().unwrap(), None);
        });
    }
}

pub(super) fn request() -> Option<crate::RequestContext> {
    REQUEST.try_with(Cell::get).ok().flatten()
}

/// An interest's immutable identity and submitted work origin. The ID is its
/// join sequence within this flight, not a session or a native resource owner.
#[derive(Clone, Copy)]
pub(super) struct Caller {
    id: u64,
    request: Option<crate::RequestContext>,
}

pub(super) struct Context {
    dispatch: tracing::Dispatch,
    span: tracing::Span,
}
impl Context {
    // Called before taking the flight table lock: subscriber methods may reenter.
    pub(super) fn capture() -> Self {
        Self {
            dispatch: tracing::dispatcher::get_default(Clone::clone),
            span: tracing::Span::current(),
        }
    }
}

struct Counts {
    sequence: u64,
    interests: u64,
    error: bool,
}

pub(super) struct State {
    id: u64,
    context: Context,
    start: Instant,
    unix_origin_ns: Option<u64>,
    counts: Mutex<Counts>,
}

impl State {
    pub(super) fn new(context: Context) -> Arc<Self> {
        let id = NEXT_ID.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |id| id.checked_add(1));
        Arc::new(Self {
            id: id.unwrap_or(u64::MAX),
            context,
            start: Instant::now(),
            unix_origin_ns: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .ok()
                .and_then(|duration| u64::try_from(duration.as_nanos()).ok()),
            counts: Mutex::new(Counts {
                sequence: 0,
                interests: 0,
                error: id.is_err(),
            }),
        })
    }

    pub(super) fn joined(self: &Arc<Self>, request: Option<crate::RequestContext>) -> Record {
        let mut record = self.record("interest_joined", 1, "none", false);
        record.caller = Some(Caller {
            id: record.sequence,
            request,
        });
        record
    }
    pub(super) fn left(self: &Arc<Self>, event: &'static str, caller: Caller) -> Record {
        let mut record = self.record(event, -1, "none", false);
        record.caller = Some(caller);
        record
    }
    pub(super) fn event(self: &Arc<Self>, event: &'static str) -> Record {
        self.record(event, 0, "none", false)
    }
    fn record(
        self: &Arc<Self>,
        event: &'static str,
        interest_delta: i8,
        work_kind: &'static str,
        started: bool,
    ) -> Record {
        let mut counts = self
            .counts
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let interests = match interest_delta {
            1 => counts.interests.checked_add(1),
            -1 => counts.interests.checked_sub(1),
            _ => Some(counts.interests),
        };
        match interests {
            Some(value) => counts.interests = value,
            None => counts.error = true,
        }
        match counts.sequence.checked_add(1) {
            Some(value) => counts.sequence = value,
            None => counts.error = true,
        }
        let elapsed_ns = u64::try_from(self.start.elapsed().as_nanos()).unwrap_or(u64::MAX);
        Record {
            state: self.clone(),
            event,
            sequence: counts.sequence,
            interests: counts.interests,
            state_error: counts.error,
            elapsed_ns,
            unix_timestamp_ns: self
                .unix_origin_ns
                .and_then(|origin| origin.checked_add(elapsed_ns)),
            work_kind,
            started,
            caller: None,
        }
    }
}

pub(super) struct Record {
    state: Arc<State>,
    event: &'static str,
    sequence: u64,
    interests: u64,
    state_error: bool,
    elapsed_ns: u64,
    unix_timestamp_ns: Option<u64>,
    work_kind: &'static str,
    started: bool,
    caller: Option<Caller>,
}
impl Record {
    pub(super) fn caller(&self) -> Caller {
        self.caller
            .expect("only a joined record creates an interest")
    }

    pub(super) fn emit(self) {
        let request = self.caller.and_then(|caller| caller.request);
        let class = match request.map(|request| request.class) {
            Some(crate::flight::WorkClass::Interactive) => "interactive",
            Some(crate::flight::WorkClass::Deferred) => "deferred",
            Some(crate::flight::WorkClass::Background) => "background",
            Some(crate::flight::WorkClass::Speculative) => "speculative",
            None => "none",
        };
        tracing::dispatcher::with_default(&self.state.context.dispatch, || {
            self.state.context.span.in_scope(|| {
                tracing::event!(target: "mnos_ingest_flight", tracing::Level::INFO,
                    flight_id = self.state.id,
                    sequence = self.sequence,
                    event = self.event,
                    interests = self.interests,
                    state_error = self.state_error,
                    elapsed_ns = self.elapsed_ns,
                    unix_timestamp_ns = self.unix_timestamp_ns.unwrap_or(0),
                    clock_valid = self.unix_timestamp_ns.is_some(),
                    work_kind = self.work_kind,
                    started = self.started,
                    interest_id = self.caller.map_or(0, |caller| caller.id),
                    caller_known = request.is_some(),
                    caller_tenant = request.map_or(0, |request| request.tenant.raw()),
                    caller_class = class,
                );
            });
        });
    }
}

struct Cleanup {
    state: Arc<State>,
    kind: &'static str,
    started: bool,
}
impl Cleanup {
    fn start(&mut self) {
        if !self.started {
            self.started = true;
            self.state.record("work_started", 0, self.kind, true).emit();
        }
    }
}
impl Drop for Cleanup {
    fn drop(&mut self) {
        self.state
            .record("work_cleanup", 0, self.kind, self.started)
            .emit();
    }
}

// Declaration order matters: destroy the work (and its captures) before emitting
// cleanup, including when a task is aborted without ever being polled.
struct WorkFuture<F> {
    inner: Pin<Box<F>>,
    cleanup: Cleanup,
}
impl<F: Future> Future for WorkFuture<F> {
    type Output = F::Output;
    fn poll(self: Pin<&mut Self>, cx: &mut TaskContext<'_>) -> Poll<Self::Output> {
        let this = self.get_mut();
        this.cleanup.start();
        this.inner.as_mut().poll(cx)
    }
}
pub(super) fn future<F: Future>(inner: F, state: Arc<State>) -> impl Future<Output = F::Output> {
    WorkFuture {
        inner: Box::pin(inner),
        cleanup: Cleanup {
            state,
            kind: "async",
            started: false,
        },
    }
}

struct WorkClosure<F> {
    work: Option<F>,
    cleanup: Cleanup,
}
impl<F> WorkClosure<F> {
    fn run<R>(mut self) -> R
    where
        F: FnOnce() -> R,
    {
        self.cleanup.start();
        self.work
            .take()
            .expect("work closure is consumed exactly once")()
    }
}
pub(super) fn blocking<F: FnOnce() -> R, R>(
    work: F,
    state: Arc<State>,
    kind: &'static str,
) -> impl FnOnce() -> R {
    let work = WorkClosure {
        work: Some(work),
        cleanup: Cleanup {
            state,
            kind,
            started: false,
        },
    };
    move || work.run()
}
