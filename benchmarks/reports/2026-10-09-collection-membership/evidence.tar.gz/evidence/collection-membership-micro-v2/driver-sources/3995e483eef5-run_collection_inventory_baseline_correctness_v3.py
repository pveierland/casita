"""Qualify the frozen inventory baseline; timings here are not performance evidence."""
import hashlib,json,os,re,signal,subprocess,sys,time,traceback
from pathlib import Path
R=Path('/tmp/mnos-ingest');C=R/'casita';E=R/'evidence'
sys.path.insert(0,str(C))
from benchmarks.suites._server_ingest_process import OwnedFamily,identity

def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

build=E/'collection-inventory-baseline-build-v3'
proof=json.loads((build/'result.json').read_text());assert proof['success']
binary=Path(proof['artifact']['path']);assert sha(binary)==proof['artifact']['sha256']
OUT=E/'collection-inventory-baseline-correctness-v3';OUT.mkdir()
cases=[
 ('spill','spill::tests::',False),
 ('inventory','repository::collection_inventory_tests::collection_inventories_match_across_spill_and_frontier_boundaries',True),
 ('faults','repository::collection_inventory_fault_tests::inventory_failures_do_not_prune_or_sweep_and_allow_retry',True),
 ('pins','repository::tests::collection_preserves_pinned_unpublished_payloads_and_individual_chunks',True),
 ('shared-chunks','repository::tests::collection_keeps_chunks_shared_with_a_live_payload',True),
 ('durability','repository::tests::collection_deletes_only_after_the_commits_that_allow_it_are_durable',True),
 ('mark','repository::collection_mark_tests::',False),
]
inputs={str(p):sha(p) for p in [Path(__file__),binary,build/'result.json',build/'protocol.json']}
(OUT/'protocol.json').write_text(json.dumps(dict(cases=cases,input_sha256=inputs,purpose='correctness only'),indent=2)+'\n')
stopped=[]
for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,lambda s,f:stopped.append(s))
results=[];errors=[]
try:
 for name,query,exact in cases:
  command=[str(binary),query,'--test-threads=1','--nocapture']+(['--exact'] if exact else [])
  family=OwnedFamily();child=None;start=time.monotonic();samples=[];failure=None
  try:
   with (OUT/(name+'.stdout')).open('x') as out,(OUT/(name+'.stderr')).open('x') as err:
    child=subprocess.Popen(command,cwd=C,stdout=out,stderr=err,start_new_session=True)
    while child.poll() is None:
     rss=0
     for pid in family.scan():
      try:
       fields=dict(x.split(':',1) for x in Path(f'/proc/{pid}/status').read_text().splitlines())
       rss+=int(fields.get('VmRSS','0').split()[0])*1024
      except (FileNotFoundError,ProcessLookupError):pass
     fs=os.statvfs(E);available=fs.f_bavail*fs.f_frsize
     samples.append(dict(seconds=time.monotonic()-start,rss_bytes=rss,available_bytes=available))
     assert not stopped and time.monotonic()-start<1200 and rss<8*1024**3 and available>=768*1024**2
     time.sleep(.25)
  except BaseException:failure=traceback.format_exc()
  finally:
   if child:
    before=[dict(pid=p,identity=identity(p)) for p in family.scan()]
    forced=family.finish(child.poll,lambda:child.poll() is not None)
    cleanup=dict(before=before,forced=forced,remaining=family.members(),adopted=family.reaped)
   else:cleanup=None
  stdout=(OUT/(name+'.stdout')).read_text()
  summaries=re.findall(r'test result: ok\. (\d+) passed; 0 failed;',stdout)
  success=bool(child and child.returncode==0 and len(summaries)==1 and int(summaries[0])>0
               and (not exact or int(summaries[0])==1) and not failure and not stopped
               and cleanup and not cleanup['forced'] and not cleanup['remaining'])
  row=dict(name=name,command=command,success=success,exit_code=child.returncode if child else None,
           passed=int(summaries[0]) if len(summaries)==1 else None,error=failure,cleanup=cleanup,samples=samples)
  results.append(row)
  (OUT/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
  print(json.dumps({k:v for k,v in row.items() if k not in ('cleanup','samples')}),flush=True)
  assert success,name
except BaseException:errors.append(traceback.format_exc())
unchanged=all(sha(Path(p))==wanted for p,wanted in inputs.items())
record=dict(success=not errors and not stopped and unchanged and len(results)==len(cases),
            errors=errors,interrupted=stopped,input_unchanged=unchanged,cases=[dict(name=r['name'],success=r['success'],passed=r['passed']) for r in results])
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
sys.exit(0 if record['success'] else 1)
