"""Guarded paired runs of the permanent collection-inventory benchmark."""
import hashlib,json,os,signal,subprocess,sys,time,traceback,shutil
from pathlib import Path

R=Path('/tmp/mnos-ingest');C=R/'casita';E=R/'evidence'
sys.path.insert(0,str(C))
from benchmarks import build_manifest as bm
from benchmarks.suites._server_ingest_process import OwnedFamily,identity

def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def save(path,value):
 Path(path).write_text(json.dumps(value,indent=2)+'\n')

# These names will be finalized only after both builds and correctness suites qualify.
build_dirs=dict(baseline=E/'collection-inventory-baseline-build-v3',
                candidate=E/'collection-inventory-candidate-build-v2')
correctness_dirs=dict(baseline=E/'collection-inventory-baseline-correctness-v3',
                      candidate=E/'collection-inventory-candidate-correctness-v2')
plan_path=R/'collection-membership-qualification-plan-v2.json'
plan=json.loads(plan_path.read_text())
assert sha(R/plan['clarification_file'])==plan['clarification_sha256']
inputs={str(p):sha(p) for p in [Path(__file__),plan_path,R/plan['clarification_file']]}
required_cases=[
 ('spill','spill::tests::',False),
 ('inventory','repository::collection_inventory_tests::collection_inventories_match_across_spill_and_frontier_boundaries',True),
 ('faults','repository::collection_inventory_fault_tests::inventory_failures_do_not_prune_or_sweep_and_allow_retry',True),
 ('pins','repository::tests::collection_preserves_pinned_unpublished_payloads_and_individual_chunks',True),
 ('shared-chunks','repository::tests::collection_keeps_chunks_shared_with_a_live_payload',True),
 ('durability','repository::tests::collection_deletes_only_after_the_commits_that_allow_it_are_durable',True),
 ('mark','repository::collection_mark_tests::',False),
]
variants={}
for variant,directory in build_dirs.items():
 proof=json.loads((directory/'result.json').read_text())
 assert proof['success'] and proof['source_unchanged'] and not proof['errors'] and not proof['interrupted']
 assert not proof['cleanup']['forced'] and not proof['cleanup']['remaining']
 correct=correctness_dirs[variant]/'result.json'
 qualified=json.loads(correct.read_text())
 assert qualified['success'] and qualified['input_unchanged'] and not qualified['errors'] and not qualified['interrupted']
 binary=Path(proof['artifact']['path'])
 assert sha(binary)==proof['artifact']['sha256']
 correct_protocol=correct.parent/'protocol.json'
 tested=json.loads(correct_protocol.read_text())
 assert tested['cases']==[list(case) for case in required_cases]
 assert len(qualified['cases'])==len(required_cases)
 assert {row['name'] for row in qualified['cases']}=={case[0] for case in required_cases}
 assert all(row['success'] and type(row['passed']) is int and row['passed']>0 for row in qualified['cases'])
 assert tested['input_sha256'][str(binary)]==proof['artifact']['sha256']
 assert tested['input_sha256'][str(directory/'result.json')]==sha(directory/'result.json')
 assert tested['input_sha256'][str(directory/'protocol.json')]==sha(directory/'protocol.json')
 for path,digest in tested['input_sha256'].items():
  assert sha(path)==digest
  inputs[path]=digest
 inputs[str(correct_protocol)]=sha(correct_protocol)
 for name,query,exact in required_cases:
  row_path=correct.parent/(name+'.json');row=json.loads(row_path.read_text())
  expected_command=[str(binary),query,'--test-threads=1','--nocapture']+(['--exact'] if exact else [])
  assert row['command']==expected_command and row['success'] and row['exit_code']==0 and not row['error']
  assert row['passed']>0 and (not exact or row['passed']==1)
  assert not row['cleanup']['forced'] and not row['cleanup']['remaining']
  assert all(child['exit_code']==0 for child in row['cleanup']['adopted'])
  for path in [row_path,correct.parent/(name+'.stdout'),correct.parent/(name+'.stderr')]:inputs[str(path)]=sha(path)
 manifest=bm.read(binary,required=True)
 manifest_proof=directory/'manifest-proof-v1.json'
 validated=json.loads(manifest_proof.read_text())
 assert validated['source_matches_build']
 assert sha(bm.manifest_path(binary))==validated['manifest_sha256']
 assert sha(directory/'result.json')==validated['build_proof_sha256']
 for reference in manifest['reference_libraries'].values():
  assert sha(reference['path'])==reference['sha256']
  inputs[reference['path']]=reference['sha256']
 for path in [binary,bm.manifest_path(binary),directory/'result.json',directory/'protocol.json',
              manifest_proof,correct,directory/'collection_inventory_tests.rs']:
  inputs[str(path)]=sha(path)
 assert sha(directory/'collection_inventory_tests.rs')==manifest['fixture_sha256']
 variants[variant]=dict(binary=str(binary),build=manifest)

baseline=variants['baseline']['build'];candidate=variants['candidate']['build']
for field in ('features','default_features','rustc_version','rustflags_source','rustflags','target',
              'profile','cargo_config_sha256','build_environment','lockfile_sha256',
              'fixture_sha256','reference_libraries'):
 assert baseline[field]==candidate[field],('build mismatch',field)
assert candidate['source_sha256']==bm.source_identity(C,os.environ)[1]
for path in [C/'benchmarks/suites/collection_inventory.py',C/'benchmarks/suites/repository.py',
             C/'benchmarks/suites/metadata_collection.py',C/'benchmarks/suites/pack/catalog.py',
             C/'benchmarks/cli.py',C/'benchmarks/manifest.json',C/'benchmarks/build_manifest.py',
             C/'benchmarks/suites/_server_ingest_process.py']:
 inputs[str(path)]=sha(path)

execution_env={key:os.environ[key] for key in ('PATH','HOME','LD_LIBRARY_PATH','CARGO_HOME','RUSTUP_HOME') if key in os.environ}
execution_env.update(LANG='C',LC_ALL='C',TZ='UTC',PYTHONHASHSEED='0',RUST_TEST_THREADS='1',RUST_BACKTRACE='0')
for name,reference in candidate['reference_libraries'].items():
 key='MNOS_EVAL_'+name+'_LIBRARY'
 assert sha(os.environ[key])==reference['sha256']
 execution_env[key]=os.environ[key]
timer=Path(os.environ.get('CASITA_BENCH_TIME') or shutil.which('time',path=execution_env['PATH'])).resolve(strict=True)
execution_env['CASITA_BENCH_TIME']=str(timer)
python=Path(sys.executable).resolve(strict=True);shell=Path('/bin/sh').resolve(strict=True)
for path in [python,timer,shell]:inputs[str(path)]=sha(path)
OUT=E/'collection-membership-micro-v2';OUT.mkdir()
temporary=OUT/'temporary';temporary.mkdir();execution_env['TMPDIR']=str(temporary)
save(OUT/'protocol.json',dict(input_sha256=inputs,variants=variants,plan=plan,
                            started_unix=time.time(),execution_environment=execution_env,python=str(python),timer=str(timer),shell=str(shell),resource_limits=dict(seconds_per_case=600,
                            family_rss_bytes=2*1024**3,minimum_available_bytes=768*1024**2,
                            diagnostic_bytes=32*1024**2)))
sources=OUT/'driver-sources';sources.mkdir()
for path in inputs:
 p=Path(path)
 if p.suffix in ('.py','.rs'):
  # Include the source path to disambiguate identically named baseline/candidate fixtures.
  (sources/(hashlib.sha256(path.encode()).hexdigest()[:12]+'-'+p.name)).write_bytes(p.read_bytes())

stopped=[]
for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,lambda s,f:stopped.append(s))
records=[];errors=[];started=time.monotonic()
try:
 for pair_index,case in enumerate(plan['micro']['schedule']):
  for variant in case['order']:
   assert not stopped and time.monotonic()-started<7200
   name=f'{pair_index:03d}-{variant}';directory=OUT/name;directory.mkdir()
   output=directory/'benchmark.json'
   command=[str(python),'-m','benchmarks.suites.collection_inventory','--profile','standard',
            '--counts',str(case['count']),'--memory-limits',str(case['memory_limit']),
            '--repetitions','1','--no-build','--probe-binary',variants[variant]['binary'],'--output',str(output)]
   family=OwnedFamily();child=None;samples=[];failure=None;start=time.monotonic()
   try:
    with (directory/'stdout.log').open('x') as out,(directory/'stderr.log').open('x') as err:
     child=subprocess.Popen(command,cwd=C,env=execution_env,stdout=out,stderr=err,start_new_session=True)
     while child.poll() is None:
      rss=0
      for pid in family.scan():
       try:
        fields=dict(x.split(':',1) for x in Path(f'/proc/{pid}/status').read_text().splitlines())
        rss+=int(fields.get('VmRSS','0').split()[0])*1024
       except (FileNotFoundError,ProcessLookupError):pass
      fs=os.statvfs(E);available=fs.f_bavail*fs.f_frsize
      diagnostics=sum(p.stat().st_size for p in directory.iterdir() if p.is_file())
      samples.append(dict(seconds=time.monotonic()-start,rss_bytes=rss,available_bytes=available,diagnostic_bytes=diagnostics))
      assert not stopped and samples[-1]['seconds']<600 and rss<2*1024**3
      assert available>=768*1024**2 and diagnostics<32*1024**2
      time.sleep(.25)
   except BaseException:failure=traceback.format_exc()
   finally:
    cleanup=None
    if child:
     try:
      before=[dict(pid=p,identity=identity(p)) for p in family.scan()]
      forced=family.finish(child.poll,lambda:child.poll() is not None)
      cleanup=dict(before=before,forced=forced,remaining=family.members(),adopted=family.reaped)
     except BaseException:failure=(failure or '')+traceback.format_exc()
   result=None
   try:
    if output.exists():result=json.loads(output.read_text())
   except BaseException:failure=(failure or '')+traceback.format_exc()
   valid=False
   try:
    assert result and result.get('complete') is True and len(result['samples'])==1 and len(result['processes'])==1
    assert result['configuration']['counts']==[case['count']]
    assert result['configuration']['memory_limits']=={str(case['count']):[case['memory_limit']]}
    assert result['configuration']['repetitions']==1
    assert result['artifacts']==[dict(path=variants[variant]['binary'],sha256=variants[variant]['build']['executable_sha256'])]
    sample=result['samples'][0];process=result['processes'][0]
    assert sample['entries']==process['count']==case['count']
    assert sample['spill_memory_objects']==process['memory_limit']==case['memory_limit']
    assert sample['repetition']==process['repetition']==1 and sample['status']=='ok' and process['exit_code']==0
    assert sample['max_rss_bytes']==process['max_rss_bytes']
    assert type(sample['max_rss_bytes']) is int and sample['max_rss_bytes']>0
    valid=True
   except BaseException:failure=(failure or '')+traceback.format_exc()
   success=bool(child and child.returncode==0 and not failure and not stopped and cleanup
                and not any(cleanup[k] for k in ('forced','remaining','before','adopted')) and valid and result and result.get('complete')
                and len(result['samples'])==1 and len(result['processes'])==1
                and result['samples'][0]['status']=='ok')
   row=dict(name=name,pair_index=pair_index,variant=variant,case=case,success=success,
            command=command,exit_code=child.returncode if child else None,error=failure,
            cleanup=cleanup,samples=samples,result=str(output),result_sha256=sha(output) if output.exists() else None)
   save(directory/'result.json',row);records.append(row)
   print(json.dumps(dict(name=name,success=success,count=case['count'],memory_limit=case['memory_limit'])),flush=True)
   assert success,name
except BaseException:errors.append(traceback.format_exc())
try:unchanged=all(sha(path)==wanted for path,wanted in inputs.items())
except BaseException:
 unchanged=False;errors.append(traceback.format_exc())
signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
interrupted=bool(stopped or signal.sigpending() & {signal.SIGINT,signal.SIGTERM})
record=dict(success=not errors and not interrupted and unchanged and len(records)==2*len(plan['micro']['schedule']),
            errors=errors,interrupted=interrupted,signals=stopped,input_unchanged=unchanged,elapsed_seconds=time.monotonic()-started,
            runs=[dict(name=r['name'],success=r['success'],result=r['result'],result_sha256=r['result_sha256']) for r in records])
save(OUT/'result.json',record)
print(json.dumps(dict(success=record['success'],runs=len(records),errors=errors)),flush=True)
sys.exit(0 if record['success'] else 1)
