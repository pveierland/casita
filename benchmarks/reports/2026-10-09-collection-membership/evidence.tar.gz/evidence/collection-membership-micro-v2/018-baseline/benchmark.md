# Collection inventory

Memory metadata and chunked payloads; one live directory, shared edges and five orphan objects.
Timing includes collection lock acquisition, logical marking and full physical planning.
Setup, plan disposal, a separate collecting pass and exhaustive retained-data audits are outside timing.
Process RSS includes setup and audits. These are local measurements, not a controlled revision comparison.

Complete: True

| Files | Memory keys | Repetition | ms | Spill files |
|---:|---:|---:|---:|---:|
| 257 | 4240 | 1 | 1.586 | 0 |
