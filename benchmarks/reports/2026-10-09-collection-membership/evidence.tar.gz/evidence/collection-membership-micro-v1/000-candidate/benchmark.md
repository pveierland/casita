# Collection inventory

Memory metadata and chunked payloads; one live directory, shared edges and five orphan objects.
Timing includes collection lock acquisition, logical marking and full physical planning.
Setup, plan disposal, a separate collecting pass and exhaustive retained-data audits are outside timing.
Process RSS includes setup and audits. These are local measurements, not a controlled revision comparison.

Complete: False

| Files | Memory keys | Repetition | ms | Spill files |
|---:|---:|---:|---:|---:|

Error: inventory probe failed (101): 
thread 'repository::collection_inventory_tests::benchmark_collection_inventory' (68114) panicked at crates/casita/src/repository/collection_inventory_tests.rs:76:10:
called `Result::unwrap()` on an `Err` value: LimitExceeded("mutation has 8198 objects, limit is 4096")
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace

