"""Replay the matched cooldown controls; a single pair is attribution only."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/mnos-ingest/evidence/sp1')
OUT = Path('/tmp/mnos-ingest/evidence/server-pressure-analysis-v1.json')

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def load(path):
    return json.loads(path.read_text())

def lines(path):
    return [json.loads(x) for x in path.read_text().splitlines()]

inputs = {str(Path(__file__)): sha(__file__)}
def bind(path):
    inputs[str(path)] = sha(path)
    return path

aggregate = load(bind(ROOT/'server-ingest-pressure.json'))
ledger = load(bind(ROOT/'execution.json'))
assert aggregate['success'] and aggregate['complete'] and ledger['complete']
assert [x['name'] for x in aggregate['cases']] == ['00-recent', '00-aged']
rows = []
for case in aggregate['cases']:
    result_path = Path(case['result'])
    assert sha(result_path) == case['result_sha256']
    result = load(bind(result_path)); run = result_path.parent
    protocol = load(bind(run/'protocol.json'))
    events = lines(bind(run/'events.jsonl'))
    samples = lines(bind(run/'resources.jsonl'))
    assert result['success'] and result['input_unchanged'] and not result['interrupted'] and not result['errors']
    assert not any(result['cleanup'][k] for k in ('forced','remaining','adopted','before'))
    assert [x['exit_code'] for x in result['cleanup']['exits']] == [-15, 0]
    for path, digest in result['input_sha256'].items():
        original = Path(path)
        snapshot = run.parent/'driver-sources'/original.name
        candidate = snapshot if snapshot.exists() else original
        assert sha(candidate) == digest
        bind(candidate)
    verified = [e for e in events if e['event'] == 'import-verified']
    assert [e['index'] for e in verified] == result['completed'] == [0,15,16,31,32,47,48,49]
    overlaps = [e for e in events if e['event'] == 'deferred-read-overlap']
    assert [e['old_index'] for e in overlaps] == [0,15,16,31,32,47,48]
    assert all(e['running_before'] and e['running_after'] and e['new_index']==49 for e in overlaps)
    assert sum(e['event']=='deferred-read' for e in events) == result['read_hash_pairs'] == 28
    target = result['target']; assert target == case['target']
    event = next(e for e in events if e['event']=='pressure-target-verified')
    assert all(event[k] == v for k,v in target.items())
    before, after = target['before_stamp'], target['after_stamp']
    assert before['device']==after['device'] and before['inode']==after['inode']
    if result['mode']=='recent':
        assert before==after
    else:
        assert target['started_unix_ns'] < after['mtime_ns'] <= target['finished_unix_ns']
        observed = [e for e in events if e['event']=='pressure-stamp-observed' and e['state'] and e['state']['mtime_ns']==after['mtime_ns']]
        assert observed and all(e['phase']=='target-aged' for e in observed)
    # Replay complete wire pairing independently of the protocol client.
    pending={}; counts=collections.Counter()
    for row in lines(bind(run/'wire.jsonl')):
        if row['direction']=='send':
            msg=row['message']; assert msg['id'] not in pending
            pending[msg['id']]=msg['body']
            body=msg['body']; counts[next(iter(body)) if isinstance(body,dict) else body]+=1
        elif row['direction']=='receive' and 'Response' in row['message']:
            msg=row['message']['Response']; assert msg['id'] in pending
            pending.pop(msg['id'])
            assert not isinstance(msg['body'],dict) or 'Error' not in msg['body']
    assert not pending and counts['Hello']==1 and counts['Kind']==56
    raw=lines(bind(run/'observer-first.jsonl')); ready=raw[0]
    assert ready['event']=='ready' and raw[-1]==dict(event='closed',samples=len(raw)-2)
    for i, sample in enumerate(raw[1:-1]):
        assert sample['index']==i and all(sample[k]==ready[k] for k in ('owner_pid','owner_start_ticks','device','inode'))
        assert sample['status']=='ok' and sample['sequence']%2==0
        assert sample['backlog_frames']==sample['max_frame']-sample['nbackfills']>=0
    assert len(samples)==result['samples']
    start,end=target['start_sample'],target['end_sample']
    assert start in samples and end in samples
    pid=next(e['pid'] for e in events if e['event']=='spawn' and e['name']=='server-first')
    a=next(x for x in start['members'] if x['pid']==pid)
    b=next(x for x in end['members'] if x['pid']==pid)
    assert a['start_ticks']==b['start_ticks']
    rows.append(dict(mode=result['mode'],seconds=target['elapsed_seconds'],
        collection_finished_after_start_seconds=(after['mtime_ns']-target['started_unix_ns'])/1e9 if result['mode']=='aged' else None,
        sampled_cpu_seconds=sum(b[k]-a[k] for k in ('user_ticks','system_ticks'))/protocol['ticks_per_second'],
        process_io_delta={k:b['io'][k]-a['io'][k] for k in a['io']},
        sample_enclosure_slack_seconds=[(target['started_unix_ns']-start['unix_ns'])/1e9,(end['unix_ns']-target['finished_unix_ns'])/1e9],
        read_hash_pairs=result['read_hash_pairs'],overlapping_roots=len(overlaps),filesystem=target['filesystem']))
report=dict(success=True,scope='one controlled attribution pair; not optimization adoption or repeated performance qualification',
    rows=rows,ratio=rows[1]['seconds']/rows[0]['seconds'],added_seconds=rows[1]['seconds']-rows[0]['seconds'],
    limitations=['Process-wide sampled counters include enclosing slack and may include reaped children.',
                 'rchar/wchar are syscall byte counts, not physical storage traffic.',
                 'Collection internal phase attribution is still required.'],input_sha256=inputs)
with OUT.open('x') as f:
    json.dump(report,f,indent=2); f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k!='input_sha256'},indent=2))
